"""
Auto-role service for FermixBot
Автоматическая выдача ролей при присоединении
"""
import discord
import logging

logger = logging.getLogger(__name__)


class AutoRoleService:
    """Сервис автоматической выдачи ролей"""
    
    def __init__(self, db, bot):
        self.db = db
        self.bot = bot
    
    async def add_autorole(self, guild_id: int, role_id: int) -> bool:
        """Добавить роль в список автовыдачи"""
        try:
            self.db.execute(
                "INSERT OR IGNORE INTO auto_roles (guild_id, role_id) VALUES (?, ?)",
                (guild_id, role_id)
            )
            logger.info(f"✅ Роль {role_id} добавлена в автовыдачу для сервера {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка добавления роли в автовыдачу: {e}")
            return False
    
    async def remove_autorole(self, guild_id: int, role_id: int) -> bool:
        """Удалить роль из списка автовыдачи"""
        try:
            self.db.execute(
                "DELETE FROM auto_roles WHERE guild_id = ? AND role_id = ?",
                (guild_id, role_id)
            )
            logger.info(f"✅ Роль {role_id} удалена из автовыдачи для сервера {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка удаления роли из автовыдачи: {e}")
            return False
    
    async def get_autoroles(self, guild_id: int) -> list:
        """Получить список ролей для автовыдачи"""
        try:
            results = self.db.fetch_all(
                "SELECT role_id FROM auto_roles WHERE guild_id = ?",
                (guild_id,)
            )
            return [r[0] for r in results]
        except Exception as e:
            logger.error(f"❌ Ошибка получения списка автоматических ролей: {e}")
            return []
    
    async def assign_roles_to_member(self, member: discord.Member):
        """Выдать все автоматические роли новому участнику"""
        try:
            role_ids = await self.get_autoroles(member.guild.id)
            
            if not role_ids:
                return
            
            roles = []
            for role_id in role_ids:
                role = member.guild.get_role(role_id)
                if role:
                    roles.append(role)
            
            if roles:
                await member.add_roles(*roles, reason="Автоматическая выдача ролей при присоединении")
                logger.info(f"✅ {member.name} получил {len(roles)} автоматических ролей")
                
                # Логировать действие
                if hasattr(self.bot, 'log_service'):
                    details = {
                        "Пользователь": member.mention,
                        "Роли": ", ".join([r.mention for r in roles]),
                        "Причина": "Автоматическая выдача при присоединении"
                    }
                    await self.bot.log_service.log_action(
                        member.guild.id,
                        self.bot.user.id,
                        "AUTO_ROLE_ASSIGNED",
                        member.id,
                        None,
                        details
                    )
        except Exception as e:
            logger.error(f"❌ Ошибка автоматической выдачи ролей для {member.name}: {e}")
