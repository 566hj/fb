"""
Database service for FermixBot
Handles all database operations
"""
import sqlite3
import logging
from typing import Optional, List, Tuple, Any, Dict
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


class Database:
    """Database manager for SQLite"""
    
    def __init__(self, db_path: str = "data/bot.db"):
        self.db_path = db_path
        Path(self.db_path).parent.mkdir(exist_ok=True)
        self._init_db()
    
    def _init_db(self):
        """Initialize database with all required tables"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute("PRAGMA foreign_keys = ON")
                
                # Mutes table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS mutes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        guild_id INTEGER NOT NULL,
                        reason TEXT,
                        muted_by INTEGER NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        expires_at TIMESTAMP,
                        is_active BOOLEAN DEFAULT 1
                    )
                """)
                
                # Guild settings table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS guild_settings (
                        guild_id INTEGER PRIMARY KEY,
                        mute_role_id INTEGER,
                        log_channel_id INTEGER,
                        level_channel_id INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                try:
                    cursor.execute("SELECT level_channel_id FROM guild_settings LIMIT 1")
                except sqlite3.OperationalError:
                    logger.info("🔄 Добавление колонки level_channel_id в guild_settings")
                    cursor.execute("ALTER TABLE guild_settings ADD COLUMN level_channel_id INTEGER")

                # Warnings table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS warnings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        guild_id INTEGER NOT NULL,
                        reason TEXT NOT NULL,
                        warned_by INTEGER NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Action logs table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS action_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        action_type TEXT NOT NULL,
                        target_id INTEGER,
                        reason TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Whitelist table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS whitelist (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        role_id INTEGER,
                        user_id INTEGER,
                        reason TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by INTEGER NOT NULL
                    )
                """)
                
                # Dangerous roles table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS dangerous_roles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        role_id INTEGER NOT NULL,
                        reason TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by INTEGER NOT NULL,
                        UNIQUE(guild_id, role_id)
                    )
                """)
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS moderator_roles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        role_id INTEGER NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by INTEGER NOT NULL,
                        UNIQUE(guild_id, role_id)
                    )
                """)
                
                # Backups table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS backups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        backup_name TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        size INTEGER,
                        UNIQUE(guild_id, backup_name)
                    )
                """)
                
                # Recovery logs table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS recovery_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        action_type TEXT NOT NULL,
                        details TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Настройки тикетов
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS ticket_settings (
                        guild_id INTEGER PRIMARY KEY,
                        category_id INTEGER,
                        support_role_id INTEGER,
                        transcript_channel_id INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Add transcript_channel_id column if it doesn't exist
                try:
                    cursor.execute("SELECT transcript_channel_id FROM ticket_settings LIMIT 1")
                except sqlite3.OperationalError:
                    logger.info("🔄 Добавление колонки transcript_channel_id в ticket_settings")
                    cursor.execute("ALTER TABLE ticket_settings ADD COLUMN transcript_channel_id INTEGER")

                # Тикеты
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS tickets (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        channel_id INTEGER NOT NULL,
                        ticket_type TEXT NOT NULL,
                        status TEXT DEFAULT 'open',
                        claimed_by INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        closed_at TIMESTAMP,
                        closed_by INTEGER,
                        transcript TEXT
                    )
                """)
                
                # Сообщения тикетов (для транскриптов)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS ticket_messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ticket_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        message_content TEXT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                    )
                """)
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS user_levels (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        xp INTEGER DEFAULT 0,
                        level INTEGER DEFAULT 0,
                        last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(guild_id, user_id)
                    )
                """)
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS level_roles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        role_id INTEGER NOT NULL,
                        required_level INTEGER NOT NULL,
                        UNIQUE(guild_id, role_id)
                    )
                """)
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS leveling_settings (
                        guild_id INTEGER PRIMARY KEY,
                        level_channel_id INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS auto_roles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id INTEGER NOT NULL,
                        role_id INTEGER NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(guild_id, role_id)
                    )
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_tickets_user 
                    ON tickets(user_id, status)
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_tickets_guild 
                    ON tickets(guild_id, status)
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_mutes_guild_user 
                    ON mutes(guild_id, user_id, is_active)
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_warnings_guild_user 
                    ON warnings(guild_id, user_id)
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_action_logs_guild 
                    ON action_logs(guild_id, created_at)
                """)

                conn.commit()
            
            logger.info("✅ База данных инициализирована")
        except Exception as e:
            logger.error(f"❌ Ошибка инициализации БД: {e}", exc_info=True)
            raise
    
    def execute(self, query: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a query and commit"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                conn.commit()
                return cursor
        except Exception as e:
            logger.error(f"❌ Ошибка выполнения запроса: {e}\nQuery: {query}\nParams: {params}")
            raise
    
    def fetch_one(self, query: str, params: tuple = ()) -> Optional[Tuple]:
        """Fetch one result"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                return cursor.fetchone()
        except Exception as e:
            logger.error(f"❌ Ошибка выборки данных: {e}\nQuery: {query}\nParams: {params}")
            return None
    
    def fetch_all(self, query: str, params: tuple = ()) -> List[Tuple]:
        """Fetch all results"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(query, params)
                return cursor.fetchall()
        except Exception as e:
            logger.error(f"❌ Ошибка выборки данных: {e}\nQuery: {query}\nParams: {params}")
            return []
    
    def log_action(self, guild_id: int, user_id: int, action_type: str, 
                   target_id: int = None, reason: str = None) -> bool:
        """Log an action to the database"""
        try:
            self.execute(
                """INSERT INTO action_logs (guild_id, user_id, action_type, target_id, reason) 
                   VALUES (?, ?, ?, ?, ?)""",
                (guild_id, user_id, action_type, target_id, reason)
            )
            logger.debug(f"📝 Действие логировано: {action_type} от {user_id} для {target_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка логирования действия: {e}")
            return False
    
    def get_log_channel(self, guild_id: int) -> Optional[int]:
        """Получить ID канала логов для сервера"""
        try:
            result = self.fetch_one(
                "SELECT log_channel_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            return result[0] if result and result[0] else None
        except Exception as e:
            logger.error(f"❌ Ошибка получения канала логов: {e}")
            return None
    
    def set_log_channel(self, guild_id: int, channel_id: int) -> bool:
        """Установить канал логов для сервера"""
        try:
            # Проверяем существование записи
            existing = self.fetch_one(
                "SELECT guild_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if existing:
                # Обновляем существующую запись
                self.execute(
                    "UPDATE guild_settings SET log_channel_id = ? WHERE guild_id = ?",
                    (channel_id, guild_id)
                )
            else:
                # Создаем новую запись
                self.execute(
                    "INSERT INTO guild_settings (guild_id, log_channel_id) VALUES (?, ?)",
                    (guild_id, channel_id)
                )
            
            logger.info(f"✅ Канал логов установлен для guild {guild_id}: {channel_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка установки канала логов: {e}")
            return False
    
    def update_ticket_setting(self, guild_id: int, field: str, value: Any) -> bool:
        """Обновить одно поле настроек тикетов без перезаписи других"""
        try:
            # Проверяем существование записи
            existing = self.fetch_one(
                "SELECT guild_id FROM ticket_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if existing:
                # Обновляем только нужное поле
                self.execute(
                    f"UPDATE ticket_settings SET {field} = ? WHERE guild_id = ?",
                    (value, guild_id)
                )
            else:
                # Создаем новую запись
                self.execute(
                    f"INSERT INTO ticket_settings (guild_id, {field}) VALUES (?, ?)",
                    (guild_id, value)
                )
            
            logger.debug(f"✅ Обновлено поле {field} для guild {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка обновления настроек тикетов: {e}")
            return False
    
    def get_ticket_settings(self, guild_id: int) -> Optional[Dict[str, Any]]:
        """Получить все настройки тикетов для сервера"""
        try:
            result = self.fetch_one(
                """SELECT category_id, support_role_id, transcript_channel_id 
                   FROM ticket_settings WHERE guild_id = ?""",
                (guild_id,)
            )
            
            if result:
                return {
                    'category_id': result[0],
                    'support_role_id': result[1],
                    'transcript_channel_id': result[2]
                }
            return None
        except Exception as e:
            logger.error(f"❌ Ошибка получения настроек тикетов: {e}")
            return None
    
    def get_level_channel(self, guild_id: int) -> Optional[int]:
        """Получить ID канала уведомлений об уровнях для сервера"""
        try:
            result = self.fetch_one(
                "SELECT level_channel_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            return result[0] if result and result[0] else None
        except Exception as e:
            logger.error(f"❌ Ошибка получения канала уровней: {e}")
            return None
    
    def set_level_channel(self, guild_id: int, channel_id: int) -> bool:
        """Установить канал уведомлений об уровнях для сервера"""
        try:
            # Проверяем существование записи
            existing = self.fetch_one(
                "SELECT guild_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if existing:
                # Обновляем существующую запись
                self.execute(
                    "UPDATE guild_settings SET level_channel_id = ? WHERE guild_id = ?",
                    (channel_id, guild_id)
                )
            else:
                # Создаем новую запись
                self.execute(
                    "INSERT INTO guild_settings (guild_id, level_channel_id) VALUES (?, ?)",
                    (guild_id, channel_id)
                )
            
            logger.info(f"✅ Канал уведомлений об уровнях установлен для guild {guild_id}: {channel_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка установки канала уровней: {e}")
            return False
