"""
Mute service for FermixBot
Handles mute operations and auto-unmute
"""
import discord
import logging
import asyncio
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from services.database import Database

logger = logging.getLogger(__name__)


class MuteService:
    """Handles muting and unmuting users"""
    
    def __init__(self, db: Database, bot):
        self.db = db
        self.bot = bot
        self._mute_tasks: Dict[tuple, asyncio.Task] = {}
    
    async def mute_user(self, user_id: int, guild_id: int, duration: int, 
                       reason: str, moderator_id: int) -> bool:
        """Mute a user"""
        try:
            expires_at = None
            if duration > 0:
                expires_at = datetime.now() + timedelta(minutes=duration)
            
            self.db.execute(
                """INSERT INTO mutes (user_id, guild_id, reason, muted_by, expires_at, is_active) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (user_id, guild_id, reason, moderator_id, expires_at, True)
            )
            
            self.db.log_action(guild_id, moderator_id, "MUTE", user_id, f"{reason} ({duration}min)")
            
            # Schedule auto-unmute
            if duration > 0:
                task = asyncio.create_task(self._schedule_unmute(user_id, guild_id, duration))
                self._mute_tasks[(user_id, guild_id)] = task
            
            duration_text = f"{duration} минут" if duration > 0 else "постоянный"
            logger.info(f"🔇 Пользователь {user_id} добавлен в мут на {duration_text}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при добавлении в мут: {e}")
            return False
    
    async def unmute_user(self, user_id: int, guild_id: int) -> bool:
        """Unmute a user"""
        try:
            self.db.execute(
                "UPDATE mutes SET is_active = 0 WHERE user_id = ? AND guild_id = ? AND is_active = 1",
                (user_id, guild_id)
            )
            
            # Cancel auto-unmute task if exists
            task_key = (user_id, guild_id)
            if task_key in self._mute_tasks:
                self._mute_tasks[task_key].cancel()
                del self._mute_tasks[task_key]
            
            logger.info(f"🔊 Мут снят с пользователя {user_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при снятии мута: {e}")
            return False
    
    async def _schedule_unmute(self, user_id: int, guild_id: int, duration: int):
        """Schedule automatic unmute"""
        try:
            await asyncio.sleep(duration * 60)  # Convert minutes to seconds
            await self.unmute_user(user_id, guild_id)
            logger.info(f"⏱️ Автоматический размут пользователя {user_id}")
        except asyncio.CancelledError:
            logger.debug(f"⏱️ Автоматический размут отменен для пользователя {user_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка в автоматическом размуте: {e}")
    
    async def get_active_mute(self, user_id: int, guild_id: int) -> Optional[Dict[str, Any]]:
        """Get active mute for user"""
        try:
            result = self.db.fetch_one(
                """SELECT * FROM mutes 
                   WHERE user_id = ? AND guild_id = ? AND is_active = 1 
                   ORDER BY created_at DESC LIMIT 1""",
                (user_id, guild_id)
            )
            
            if result:
                return {
                    'id': result[0],
                    'user_id': result[1],
                    'guild_id': result[2],
                    'reason': result[3],
                    'muted_by': result[4],
                    'created_at': result[5],
                    'expires_at': result[6],
                    'is_active': bool(result[7])
                }
            return None
        except Exception as e:
            logger.error(f"❌ Ошибка при получении информации о муте: {e}")
            return None
    
    async def restore_active_mutes(self):
        """Restore active mutes on bot startup"""
        try:
            results = self.db.fetch_all(
                "SELECT user_id, guild_id, expires_at FROM mutes WHERE is_active = 1 AND expires_at IS NOT NULL"
            )
            
            restored_count = 0
            for result in results:
                user_id, guild_id, expires_at_str = result
                try:
                    if expires_at_str:
                        expires_at = datetime.fromisoformat(expires_at_str)
                        time_left = (expires_at - datetime.now()).total_seconds()
                        
                        if time_left > 0:
                            minutes_left = max(1, int(time_left / 60))
                            task = asyncio.create_task(self._schedule_unmute(user_id, guild_id, minutes_left))
                            self._mute_tasks[(user_id, guild_id)] = task
                            restored_count += 1
                        else:
                            await self.unmute_user(user_id, guild_id)
                except Exception as e:
                    logger.error(f"❌ Ошибка восстановления мута: {e}")
            
            logger.info(f"✅ Восстановлено {restored_count} активных мутов")
        except Exception as e:
            logger.error(f"❌ Ошибка при восстановлении мутов: {e}")
