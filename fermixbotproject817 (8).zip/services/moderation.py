"""
Moderation service for FermixBot
Handles warnings and moderation data
"""
import logging
from typing import List, Optional, Dict, Any
from services.database import Database

logger = logging.getLogger(__name__)


class ModerationService:
    """Handles moderation operations"""
    
    def __init__(self, db: Database):
        self.db = db
    
    async def warn_user(self, user_id: int, guild_id: int, reason: str, moderator_id: int) -> bool:
        """Warn a user"""
        try:
            self.db.execute(
                "INSERT INTO warnings (user_id, guild_id, reason, warned_by) VALUES (?, ?, ?, ?)",
                (user_id, guild_id, reason, moderator_id)
            )
            self.db.log_action(guild_id, moderator_id, "WARN", user_id, reason)
            logger.info(f"✅ Пользователю {user_id} выдано предупреждение: {reason}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при выдаче предупреждения: {e}")
            return False
    
    async def get_warnings(self, user_id: int, guild_id: int) -> List[Dict[str, Any]]:
        """Get user warnings"""
        try:
            results = self.db.fetch_all(
                "SELECT * FROM warnings WHERE user_id = ? AND guild_id = ? ORDER BY created_at DESC",
                (user_id, guild_id)
            )
            logger.debug(f"📋 Получено {len(results)} предупреждений для пользователя {user_id}")
            return [
                {
                    'id': r[0],
                    'user_id': r[1],
                    'guild_id': r[2],
                    'reason': r[3],
                    'warned_by': r[4],
                    'created_at': r[5]
                }
                for r in results
            ]
        except Exception as e:
            logger.error(f"❌ Ошибка при получении предупреждений: {e}")
            return []
    
    async def clear_warnings(self, user_id: int, guild_id: int) -> bool:
        """Clear user warnings"""
        try:
            self.db.execute(
                "DELETE FROM warnings WHERE user_id = ? AND guild_id = ?",
                (user_id, guild_id)
            )
            logger.info(f"✅ Все предупреждения очищены для пользователя {user_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при очистке предупреждений: {e}")
            return False
    
    async def set_mute_role(self, guild_id: int, role_id: int) -> bool:
        """Set mute role for guild"""
        try:
            self.db.execute(
                "INSERT OR REPLACE INTO guild_settings (guild_id, mute_role_id) VALUES (?, ?)",
                (guild_id, role_id)
            )
            logger.info(f"✅ Роль мута {role_id} установлена для сервера {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при установке роли мута: {e}")
            return False
    
    async def get_mute_role(self, guild_id: int) -> Optional[int]:
        """Get mute role for guild"""
        try:
            result = self.db.fetch_one(
                "SELECT mute_role_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            return result[0] if result else None
        except Exception as e:
            logger.error(f"❌ Ошибка при получении роли мута: {e}")
            return None
    
    async def set_log_channel(self, guild_id: int, channel_id: int) -> bool:
        """Set log channel for guild"""
        try:
            self.db.execute(
                "INSERT OR REPLACE INTO guild_settings (guild_id, log_channel_id) VALUES (?, ?)",
                (guild_id, channel_id)
            )
            logger.info(f"✅ Канал логов {channel_id} установлен для сервера {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при установке канала логов: {e}")
            return False
    
    async def get_log_channel(self, guild_id: int) -> Optional[int]:
        """Get log channel for guild"""
        try:
            result = self.db.fetch_one(
                "SELECT log_channel_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            return result[0] if result else None
        except Exception as e:
            logger.error(f"❌ Ошибка при получении канала логов: {e}")
            return None
