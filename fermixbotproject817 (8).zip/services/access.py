"""
Access service for FermixBot
Handles permission management and access control
"""
import discord
import logging
from typing import Optional, List, Dict, Any
from services.database import Database

logger = logging.getLogger(__name__)


class AccessService:
    """Manages access control and permissions"""
    
    def __init__(self, db: Database):
        self.db = db
    
    async def check_moderator_permissions(self, user: discord.Member, guild: discord.Guild) -> bool:
        """Check if user has moderator permissions"""
        try:
            if user.guild_permissions.administrator or user.guild_permissions.manage_guild:
                return True
            
            moderator_roles = [
                role for role in user.roles 
                if any(perm in [p[0] for p in role.permissions] 
                       for perm in ['manage_messages', 'kick_members', 'ban_members'])
            ]
            
            return len(moderator_roles) > 0
        except Exception as e:
            logger.error(f"❌ Error checking permissions: {e}")
            return False
    
    async def is_owner_or_admin(self, user: discord.Member, guild: discord.Guild) -> bool:
        """Check if user is guild owner or admin"""
        try:
            return user.guild_permissions.administrator or user == guild.owner
        except Exception as e:
            logger.error(f"❌ Error checking admin status: {e}")
            return False
    
    async def get_moderators(self, guild_id: int) -> List[int]:
        """Get list of moderators for guild"""
        try:
            # In future, this could be expanded with a moderators table
            return []
        except Exception as e:
            logger.error(f"❌ Failed to get moderators: {e}")
            return []
    
    async def add_moderator_role(self, guild_id: int, role_id: int) -> bool:
        """Add a moderator role (for future use with moderators table)"""
        try:
            logger.info(f"✅ Added moderator role {role_id} to guild {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to add moderator role: {e}")
            return False
    
    async def check_bot_permissions(self, guild: discord.Guild) -> Dict[str, bool]:
        """Check if bot has required permissions"""
        try:
            bot_member = guild.get_member(self.bot.user.id) if hasattr(self, 'bot') else None
            
            required_perms = {
                'manage_roles': False,
                'manage_channels': False,
                'manage_messages': False,
                'ban_members': False,
                'kick_members': False,
                'mute_members': False
            }
            
            if bot_member:
                for perm, _ in required_perms.items():
                    required_perms[perm] = getattr(bot_member.guild_permissions, perm, False)
            
            return required_perms
        except Exception as e:
            logger.error(f"❌ Error checking bot permissions: {e}")
            return {}
