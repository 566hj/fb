"""
Security service for FermixBot
Handles Anti-Nuke, Anti-Raid, and Anti-Spam protection
Защита от опасных прав и ролей с вайтлистом
"""
import discord
import logging
import asyncio
from typing import Dict, Optional, Tuple, Set, List
from datetime import datetime, timedelta
from collections import defaultdict
from services.database import Database

logger = logging.getLogger(__name__)


class SecurityService:
    """Comprehensive security and protection service"""
    
    DANGEROUS_PERMISSIONS = {
        discord.Permissions.administrator.flag,
        discord.Permissions.ban_members.flag,
        discord.Permissions.kick_members.flag,
        discord.Permissions.manage_guild.flag,
        discord.Permissions.manage_roles.flag,
        discord.Permissions.manage_channels.flag,
        discord.Permissions.manage_webhooks.flag,
        discord.Permissions.manage_messages.flag,
        discord.Permissions.manage_emojis.flag,
        discord.Permissions.manage_emojis_and_stickers.flag,
    }
    
    def __init__(self, db: Database, bot: discord.ext.commands.Bot = None):
        self.db = db
        self.bot = bot
        
        # Anti-Spam tracking: {(guild_id, user_id): [timestamps]}
        self._spam_tracker: Dict[Tuple[int, int], list] = defaultdict(list)
        
        # Anti-Raid tracking: {guild_id: [join_timestamps]}
        self._raid_tracker: Dict[int, list] = defaultdict(list)
        
        # Anti-Nuke tracking: {(guild_id, user_id): {action: count}}
        self._nuke_tracker: Dict[Tuple[int, int], Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        
        self._dangerous_roles: Dict[int, Set[int]] = defaultdict(set)
        self._protected_roles: Dict[int, Set[int]] = defaultdict(set)
        
        self._whitelist: Dict[int, Dict[str, Set[int]]] = defaultdict(lambda: {"users": set(), "roles": set()})
        
        # Configuration
        self.SPAM_THRESHOLD = 5  # messages
        self.SPAM_TIMEFRAME = 5  # seconds
        self.RAID_THRESHOLD = 5  # joins
        self.RAID_TIMEFRAME = 10  # seconds
        self.NUKE_ROLE_CREATIONS = 3
        self.NUKE_CHANNEL_CREATIONS = 5
        self.NUKE_CHANNEL_DELETES = 3
        self.NUKE_ROLE_DELETES = 2
        self.NUKE_TIMEFRAME = 60  # seconds
    
    async def check_spam(self, guild_id: int, user_id: int, current_time: datetime = None) -> bool:
        """Check if user is spamming"""
        try:
            if current_time is None:
                current_time = datetime.now()
            
            tracker_key = (guild_id, user_id)
            timestamps = self._spam_tracker[tracker_key]
            
            # Add current message timestamp
            timestamps.append(current_time)
            
            # Remove old timestamps outside timeframe
            cutoff = current_time - timedelta(seconds=self.SPAM_TIMEFRAME)
            self._spam_tracker[tracker_key] = [ts for ts in timestamps if ts > cutoff]
            
            # Check if spam threshold exceeded
            if len(self._spam_tracker[tracker_key]) >= self.SPAM_THRESHOLD:
                logger.warning(f"📧 Спам обнаружен: пользователь {user_id} отправил {len(self._spam_tracker[tracker_key])} сообщений за {self.SPAM_TIMEFRAME}с")
                self.db.log_action(guild_id, user_id, "SPAM_DETECTED", user_id, 
                                  f"{len(self._spam_tracker[tracker_key])} сообщений за {self.SPAM_TIMEFRAME}с")
                return True
            
            return False
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке спама: {e}")
            return False
    
    async def check_raid(self, guild_id: int, current_time: datetime = None) -> bool:
        """Check if guild is under raid"""
        try:
            if current_time is None:
                current_time = datetime.now()
            
            timestamps = self._raid_tracker[guild_id]
            timestamps.append(current_time)
            
            # Remove old timestamps
            cutoff = current_time - timedelta(seconds=self.RAID_TIMEFRAME)
            self._raid_tracker[guild_id] = [ts for ts in timestamps if ts > cutoff]
            
            # Check if raid threshold exceeded
            if len(self._raid_tracker[guild_id]) >= self.RAID_THRESHOLD:
                logger.warning(f"🔨 Рейд обнаружен: {len(self._raid_tracker[guild_id])} присоединений за {self.RAID_TIMEFRAME}с")
                self.db.log_action(guild_id, 0, "RAID_DETECTED", None, 
                                  f"{len(self._raid_tracker[guild_id])} присоединений за {self.RAID_TIMEFRAME}с")
                return True
            
            return False
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке рейда: {e}")
            return False
    
    async def check_nuke(self, guild_id: int, user_id: int, action_type: str) -> bool:
        """Check if user is attempting nuke (mass delete/create)"""
        try:
            tracker_key = (guild_id, user_id)
            self._nuke_tracker[tracker_key][action_type] += 1
            
            action_count = self._nuke_tracker[tracker_key][action_type]
            
            # Check thresholds for different actions
            nuke_detected = False
            reason = ""
            
            if action_type == "ROLE_CREATE" and action_count >= self.NUKE_ROLE_CREATIONS:
                nuke_detected = True
                reason = f"{action_count} создания ролей"
            elif action_type == "CHANNEL_CREATE" and action_count >= self.NUKE_CHANNEL_CREATIONS:
                nuke_detected = True
                reason = f"{action_count} создания каналов"
            elif action_type == "CHANNEL_DELETE" and action_count >= self.NUKE_CHANNEL_DELETES:
                nuke_detected = True
                reason = f"{action_count} удаления каналов"
            elif action_type == "ROLE_DELETE" and action_count >= self.NUKE_ROLE_DELETES:
                nuke_detected = True
                reason = f"{action_count} удаления ролей"
            
            if nuke_detected:
                logger.warning(f"💣 Попытка нука обнаружена: пользователь {user_id} - {reason}")
                self.db.log_action(guild_id, user_id, "NUKE_DETECTED", user_id, reason)
                
                # Reset counter
                self._nuke_tracker[tracker_key][action_type] = 0
                return True
            
            return False
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке нука: {e}")
            return False
    
    async def check_dangerous_permissions(self, guild_id: int, user_id: int, 
                                         permissions: discord.Permissions) -> Tuple[bool, str]:
        """
        Check if user is trying to grant dangerous permissions
        Проверка опасных прав
        """
        try:
            if await self.is_user_whitelisted(guild_id, user_id):
                return False, ""
            
            dangerous = []
            for perm, value in permissions:
                perm_flag = getattr(discord.Permissions, perm, None)
                if perm_flag and perm_flag.flag in self.DANGEROUS_PERMISSIONS and value:
                    dangerous.append(perm)
            
            if dangerous:
                reason = f"Попытка выдать опасные права: {', '.join(dangerous)}"
                logger.warning(f"⚠️ Опасные права обнаружены: пользователь {user_id} пытается выдать {', '.join(dangerous)}")
                self.db.log_action(guild_id, user_id, "DANGEROUS_PERMISSIONS_ATTEMPTED", user_id, reason)
                return True, reason
            
            return False, ""
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке опасных прав: {e}")
            return False, ""
    
    async def check_role_dangerous(self, role: discord.Role) -> Tuple[bool, str]:
        """Check if role has dangerous permissions"""
        try:
            dangerous_perms = []
            for perm, value in role.permissions:
                perm_flag = getattr(discord.Permissions, perm, None)
                if perm_flag and perm_flag.flag in self.DANGEROUS_PERMISSIONS and value:
                    dangerous_perms.append(perm)
            
            if dangerous_perms:
                reason = f"Роль имеет опасные права: {', '.join(dangerous_perms)}"
                return True, reason
            
            return False, ""
        except Exception as e:
            logger.error(f"❌ Ошибка при проверке роли: {e}")
            return False, ""
    
    def mark_dangerous_role(self, guild_id: int, role_id: int, reason: str = "Опасная роль", created_by: int = None):
        """Mark role as dangerous"""
        try:
            self._dangerous_roles[guild_id].add(role_id)
            self.db.execute(
                """INSERT OR IGNORE INTO dangerous_roles (guild_id, role_id, reason, created_by)
                   VALUES (?, ?, ?, ?)""",
                (guild_id, role_id, reason, created_by or 0)
            )
            logger.warning(f"🚩 Роль {role_id} отмечена как опасная на сервере {guild_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка при отметке опасной роли: {e}")
    
    def unmark_dangerous_role(self, guild_id: int, role_id: int):
        """Remove role from dangerous list"""
        try:
            if role_id in self._dangerous_roles[guild_id]:
                self._dangerous_roles[guild_id].remove(role_id)
            self.db.execute(
                "DELETE FROM dangerous_roles WHERE guild_id = ? AND role_id = ?",
                (guild_id, role_id)
            )
            logger.info(f"✅ Роль {role_id} удалена из списка опасных на сервере {guild_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении роли из опасных: {e}")
    
    async def add_to_whitelist(self, guild_id: int, target_id: int, target_type: str, reason: str = "", created_by: int = None):
        """Add user or role to whitelist"""
        try:
            self.db.execute(
                """INSERT INTO whitelist (guild_id, role_id, user_id, reason, created_by)
                   VALUES (?, ?, ?, ?, ?)""",
                (guild_id, target_id if target_type == "role" else None, 
                 target_id if target_type == "user" else None, reason, created_by or 0)
            )
            if target_type == "user":
                self._whitelist[guild_id]["users"].add(target_id)
            else:
                self._whitelist[guild_id]["roles"].add(target_id)
            logger.info(f"✅ {target_type.upper()} {target_id} добавлен в вайтлист на сервере {guild_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка при добавлении в вайтлист: {e}")
    
    async def remove_from_whitelist(self, guild_id: int, target_id: int, target_type: str):
        """Remove user or role from whitelist"""
        try:
            if target_type == "user":
                self.db.execute(
                    "DELETE FROM whitelist WHERE guild_id = ? AND user_id = ?",
                    (guild_id, target_id)
                )
                self._whitelist[guild_id]["users"].discard(target_id)
            else:
                self.db.execute(
                    "DELETE FROM whitelist WHERE guild_id = ? AND role_id = ?",
                    (guild_id, target_id)
                )
                self._whitelist[guild_id]["roles"].discard(target_id)
            logger.info(f"✅ {target_type.upper()} {target_id} удален из вайтлиста на сервере {guild_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении из вайтлиста: {e}")
    
    async def is_user_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """Check if user is whitelisted"""
        return user_id in self._whitelist[guild_id]["users"]
    
    async def is_role_whitelisted(self, guild_id: int, role_id: int) -> bool:
        """Check if role is whitelisted"""
        return role_id in self._whitelist[guild_id]["roles"]
    
    async def get_whitelist(self, guild_id: int) -> Dict[str, List]:
        """Get full whitelist for guild"""
        try:
            users = self.db.fetch_all(
                "SELECT user_id, reason FROM whitelist WHERE guild_id = ? AND user_id IS NOT NULL",
                (guild_id,)
            )
            roles = self.db.fetch_all(
                "SELECT role_id, reason FROM whitelist WHERE guild_id = ? AND role_id IS NOT NULL",
                (guild_id,)
            )
            return {"users": users, "roles": roles}
        except Exception as e:
            logger.error(f"❌ Ошибка при получении вайтлиста: {e}")
            return {"users": [], "roles": []}
    
    async def get_dangerous_roles(self, guild_id: int) -> List[Tuple]:
        """Get dangerous roles for guild"""
        try:
            return self.db.fetch_all(
                "SELECT role_id, reason FROM dangerous_roles WHERE guild_id = ?",
                (guild_id,)
            )
        except Exception as e:
            logger.error(f"❌ Ошибка при получении опасных ролей: {e}")
            return []
    
    def protect_role(self, guild_id: int, role_id: int):
        """Protect role from modification"""
        self._protected_roles[guild_id].add(role_id)
        logger.info(f"🛡️ Роль {role_id} защищена от изменений на сервере {guild_id}")
    
    def is_role_dangerous(self, guild_id: int, role_id: int) -> bool:
        """Check if role is marked as dangerous"""
        return role_id in self._dangerous_roles.get(guild_id, set())
    
    def is_role_protected(self, guild_id: int, role_id: int) -> bool:
        """Check if role is protected"""
        return role_id in self._protected_roles.get(guild_id, set())
    
    async def get_security_stats(self, guild_id: int) -> Dict:
        """Get security statistics for guild"""
        try:
            logs = self.db.fetch_all(
                """SELECT action_type, COUNT(*) FROM action_logs 
                   WHERE guild_id = ? AND created_at > datetime('now', '-24 hours')
                   GROUP BY action_type""",
                (guild_id,)
            )
            
            stats = {
                'spam_incidents': 0,
                'raid_incidents': 0,
                'nuke_incidents': 0,
                'total_infractions': 0
            }
            
            for log_type, count in logs:
                if log_type == "SPAM_DETECTED":
                    stats['spam_incidents'] = count
                elif log_type == "RAID_DETECTED":
                    stats['raid_incidents'] = count
                elif log_type == "NUKE_DETECTED":
                    stats['nuke_incidents'] = count
                
                stats['total_infractions'] += count
            
            return stats
        except Exception as e:
            logger.error(f"❌ Ошибка при получении статистики безопасности: {e}")
            return {}
    
    def reset_user_tracking(self, guild_id: int, user_id: int):
        """Reset tracking for a specific user"""
        try:
            tracker_key = (guild_id, user_id)
            if tracker_key in self._spam_tracker:
                del self._spam_tracker[tracker_key]
            if tracker_key in self._nuke_tracker:
                del self._nuke_tracker[tracker_key]
            logger.info(f"🔄 Отслеживание сброшено для пользователя {user_id} на сервере {guild_id}")
        except Exception as e:
            logger.error(f"❌ Ошибка при сбросе отслеживания: {e}")
