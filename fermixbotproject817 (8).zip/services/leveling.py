"""
Leveling service for FermixBot
Управление системой уровней и опыта
"""
import discord
import logging
import asyncio
import random
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class LevelingService:
    """Сервис для системы уровней"""
    
    def __init__(self, db, bot):
        self.db = db
        self.bot = bot
        self.cooldowns = {}  # {user_id: last_xp_time}
        self.xp_cooldown = 60  # Секунды между начислением XP
        
        # XP требования для каждого уровня (0-50)
        self.level_requirements = self._calculate_level_requirements()
    
    def _calculate_level_requirements(self):
        """Рассчитать требования XP для каждого уровня 0-50"""
        requirements = {0: 0}
        base_xp = 100
        multiplier = 1.15
        
        for level in range(1, 51):
            xp_needed = int(base_xp * (multiplier ** (level - 1)))
            requirements[level] = requirements[level - 1] + xp_needed
        
        logger.info(f"✅ Создано {len(requirements)} уровней (0-50)")
        return requirements
    
    def get_level_from_xp(self, xp: int) -> int:
        """Получить уровень по количеству XP"""
        for level in range(50, -1, -1):
            if xp >= self.level_requirements[level]:
                return level
        return 0
    
    def get_xp_for_next_level(self, current_xp: int) -> tuple:
        """Получить XP до следующего уровня (current_level, current_xp, next_level_xp)"""
        current_level = self.get_level_from_xp(current_xp)
        
        if current_level >= 50:
            return (50, current_xp, self.level_requirements[50])
        
        next_level_xp = self.level_requirements[current_level + 1]
        current_level_xp = self.level_requirements[current_level]
        
        return (current_level, current_xp - current_level_xp, next_level_xp - current_level_xp)
    
    async def add_xp(self, member: discord.Member, xp_amount: int = None) -> tuple:
        """
        Добавить XP участнику
        Returns: (old_level, new_level, new_xp) или None если кулдаун
        """
        # Проверка кулдауна
        now = datetime.now()
        if member.id in self.cooldowns:
            last_time = self.cooldowns[member.id]
            if (now - last_time).seconds < self.xp_cooldown:
                return None
        
        # Обновить кулдаун
        self.cooldowns[member.id] = now
        
        # Случайное количество XP если не указано
        if xp_amount is None:
            xp_amount = random.randint(15, 25)
        
        # Получить текущий XP
        result = self.db.fetch_one(
            "SELECT xp FROM user_levels WHERE guild_id = ? AND user_id = ?",
            (member.guild.id, member.id)
        )
        
        old_xp = result[0] if result else 0
        new_xp = old_xp + xp_amount
        
        # Рассчитать уровни
        old_level = self.get_level_from_xp(old_xp)
        new_level = self.get_level_from_xp(new_xp)
        
        # Обновить в БД
        if result:
            self.db.execute(
                "UPDATE user_levels SET xp = ?, level = ?, last_message_at = CURRENT_TIMESTAMP WHERE guild_id = ? AND user_id = ?",
                (new_xp, new_level, member.guild.id, member.id)
            )
        else:
            self.db.execute(
                "INSERT INTO user_levels (guild_id, user_id, xp, level) VALUES (?, ?, ?, ?)",
                (member.guild.id, member.id, new_xp, new_level)
            )
        
        logger.debug(f"💎 {member.name} получил {xp_amount} XP (Уровень {old_level} -> {new_level})")
        
        return (old_level, new_level, new_xp)
    
    async def check_level_up(self, member: discord.Member, old_level: int, new_level: int):
        """Проверить повышение уровня и выдать награды"""
        if new_level <= old_level:
            return
        
        # Отправить сообщение о повышении уровня
        try:
            # Найти канал для сообщений
            settings = self.db.fetch_one(
                "SELECT level_channel_id FROM leveling_settings WHERE guild_id = ?",
                (member.guild.id,)
            )
            
            channel = None
            if settings and settings[0]:
                channel = member.guild.get_channel(settings[0])
            
            # Создать embed
            embed = discord.Embed(
                title="🎉 Повышение уровня!",
                description=f"{member.mention} достиг **уровня {new_level}**!",
                color=discord.Color.gold()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            
            # Отправить в канал или в последний канал где писал пользователь
            if channel:
                await channel.send(embed=embed)
        except Exception as e:
            logger.error(f"❌ Ошибка отправки уведомления о повышении: {e}")
        
        # Проверить и выдать роли за уровень
        await self._check_level_roles(member, new_level)
    
    async def _check_level_roles(self, member: discord.Member, level: int):
        """Проверить и выдать роли за достижение уровня"""
        try:
            # Получить роли за уровни
            roles = self.db.fetch_all(
                "SELECT role_id, required_level FROM level_roles WHERE guild_id = ? AND required_level <= ? ORDER BY required_level DESC",
                (member.guild.id, level)
            )
            
            if not roles:
                return
            
            # Выдать роли
            for role_id, required_level in roles:
                role = member.guild.get_role(role_id)
                if role and role not in member.roles:
                    await member.add_roles(role, reason=f"Достигнут уровень {required_level}")
                    logger.info(f"🎖️ {member.name} получил роль {role.name} за уровень {required_level}")
        except Exception as e:
            logger.error(f"❌ Ошибка выдачи ролей за уровень: {e}")
    
    def get_user_stats(self, guild_id: int, user_id: int) -> dict:
        """Получить статистику пользователя"""
        result = self.db.fetch_one(
            "SELECT xp, level FROM user_levels WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        )
        
        if not result:
            return {"xp": 0, "level": 0, "rank": None}
        
        xp, level = result
        
        # Получить ранг
        rank = self.db.fetch_one(
            """SELECT COUNT(*) + 1 FROM user_levels 
               WHERE guild_id = ? AND (level > ? OR (level = ? AND xp > ?))""",
            (guild_id, level, level, xp)
        )[0]
        
        return {"xp": xp, "level": level, "rank": rank}
    
    def get_leaderboard(self, guild_id: int, limit: int = 10) -> list:
        """Получить таблицу лидеров"""
        results = self.db.fetch_all(
            """SELECT user_id, xp, level FROM user_levels 
               WHERE guild_id = ? 
               ORDER BY level DESC, xp DESC 
               LIMIT ?""",
            (guild_id, limit)
        )
        
        return [{"user_id": r[0], "xp": r[1], "level": r[2]} for r in results]
    
    def add_level_role(self, guild_id: int, role_id: int, level: int) -> bool:
        """Добавить роль за уровень"""
        try:
            self.db.execute(
                "INSERT OR REPLACE INTO level_roles (guild_id, role_id, required_level) VALUES (?, ?, ?)",
                (guild_id, role_id, level)
            )
            logger.info(f"✅ Роль {role_id} добавлена за уровень {level}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка добавления роли за уровень: {e}")
            return False
    
    def remove_level_role(self, guild_id: int, role_id: int) -> bool:
        """Удалить роль за уровень"""
        try:
            self.db.execute(
                "DELETE FROM level_roles WHERE guild_id = ? AND role_id = ?",
                (guild_id, role_id)
            )
            logger.info(f"✅ Роль {role_id} удалена из наград за уровень")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка удаления роли за уровень: {e}")
            return False
    
    def set_level_channel(self, guild_id: int, channel_id: int) -> bool:
        """Установить канал для уведомлений о повышении уровня"""
        try:
            self.db.execute(
                "INSERT OR REPLACE INTO leveling_settings (guild_id, level_channel_id) VALUES (?, ?)",
                (guild_id, channel_id)
            )
            logger.info(f"✅ Канал уведомлений установлен: {channel_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка установки канала: {e}")
            return False
