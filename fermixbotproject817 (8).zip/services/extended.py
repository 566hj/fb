"""
Extended service for FermixBot
Handles extended moderation features like temporary bans, role management
"""
import discord
import logging
import asyncio
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from services.database import Database

logger = logging.getLogger(__name__)


class ExtendedService:
    """Handles extended moderation operations"""
    
    def __init__(self, db: Database):
        self.db = db
        self._ban_tasks: Dict[tuple, asyncio.Task] = {}
    
    async def temp_ban_user(self, user_id: int, guild_id: int, duration: int, 
                            reason: str, moderator_id: int) -> bool:
        """Temporary ban a user"""
        try:
            expires_at = datetime.now() + timedelta(minutes=duration)
            
            self.db.execute(
                """INSERT INTO action_logs (guild_id, user_id, action_type, reason, created_at) 
                   VALUES (?, ?, ?, ?, ?)""",
                (guild_id, user_id, "TEMP_BAN", reason, expires_at)
            )
            
            self.db.log_action(guild_id, moderator_id, "TEMP_BAN", user_id, f"{reason} ({duration}min)")
            
            if duration > 0:
                task = asyncio.create_task(self._schedule_unban(user_id, guild_id, duration))
                self._ban_tasks[(user_id, guild_id)] = task
            
            logger.info(f"✅ Temp-banned user {user_id} for {duration} minutes")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to temp-ban user: {e}")
            return False
    
    async def _schedule_unban(self, user_id: int, guild_id: int, duration: int):
        """Schedule automatic unban"""
        try:
            await asyncio.sleep(duration * 60)
            logger.info(f"✅ Auto-unban scheduled for user {user_id}")
        except asyncio.CancelledError:
            logger.info(f"Auto-unban cancelled for user {user_id}")
        except Exception as e:
            logger.error(f"❌ Error in auto-unban: {e}")
    
    async def get_user_infractions(self, user_id: int, guild_id: int) -> List[Dict[str, Any]]:
        """Get all infractions for a user"""
        try:
            results = self.db.fetch_all(
                """SELECT * FROM action_logs 
                   WHERE user_id = ? AND guild_id = ? 
                   ORDER BY created_at DESC LIMIT 50""",
                (user_id, guild_id)
            )
            
            return [
                {
                    'id': r[0],
                    'guild_id': r[1],
                    'user_id': r[2],
                    'action_type': r[3],
                    'target_id': r[4],
                    'reason': r[5],
                    'created_at': r[6]
                }
                for r in results
            ]
        except Exception as e:
            logger.error(f"❌ Failed to get infractions: {e}")
            return []
    
    async def clear_infractions(self, user_id: int, guild_id: int) -> bool:
        """Clear all infractions for a user"""
        try:
            self.db.execute(
                "DELETE FROM action_logs WHERE user_id = ? AND guild_id = ?",
                (user_id, guild_id)
            )
            logger.info(f"✅ Cleared infractions for user {user_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to clear infractions: {e}")
            return False
