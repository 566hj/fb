"""
Backup and Recovery Service for FermixBot
Handles server backups and automatic restoration
Сохранение и восстановление сервера при атаках
"""
import discord
import logging
import json
from typing import Dict, Optional, List
from datetime import datetime
from pathlib import Path
from services.database import Database

logger = logging.getLogger(__name__)


class BackupService:
    """Server backup and restoration service"""
    
    def __init__(self, db: Database, bot: discord.ext.commands.Bot = None):
        self.db = db
        self.bot = bot
        self.backups_dir = Path("data/backups")
        self.backups_dir.mkdir(parents=True, exist_ok=True)
    
    async def create_backup(self, guild: discord.Guild, name: str = None) -> bool:
        """Create a complete server backup"""
        try:
            if not name:
                name = f"backup_{guild.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            backup_data = {
                "guild_id": guild.id,
                "guild_name": guild.name,
                "created_at": datetime.now().isoformat(),
                "roles": [],
                "channels": [],
                "user_roles": [],
                "emojis": []
            }
            
            # Backup roles
            logger.info(f"💾 Сохранение ролей сервера {guild.name}...")
            for role in guild.roles:
                if role == guild.default_role:
                    continue
                
                backup_data["roles"].append({
                    "name": role.name,
                    "color": role.color.value,
                    "hoist": role.hoist,
                    "mentionable": role.mentionable,
                    "permissions": role.permissions.value,
                    "position": role.position
                })
            
            # Backup channels
            logger.info(f"💾 Сохранение каналов сервера {guild.name}...")
            for channel in guild.channels:
                channel_data = {
                    "name": channel.name,
                    "type": str(channel.type),
                    "position": channel.position,
                    "category_id": channel.category.id if channel.category else None,
                    "category_name": channel.category.name if channel.category else None,
                    "topic": getattr(channel, "topic", None),
                    "slowmode_delay": getattr(channel, "slowmode_delay", 0),
                    "nsfw": getattr(channel, "nsfw", False),
                    "bitrate": getattr(channel, "bitrate", None),
                    "user_limit": getattr(channel, "user_limit", None),
                    "overwrites": []
                }
                
                # Save channel permissions
                for target, overwrite in channel.overwrites.items():
                    overwrite_data = {
                        "target_id": target.id,
                        "target_name": target.name,
                        "target_type": "role" if isinstance(target, discord.Role) else "user",
                        "allow": overwrite.pair()[0].value,
                        "deny": overwrite.pair()[1].value
                    }
                    channel_data["overwrites"].append(overwrite_data)
                
                backup_data["channels"].append(channel_data)
            
            # Backup user roles
            logger.info(f"💾 Сохранение ролей пользователей на сервере {guild.name}...")
            for member in guild.members:
                if member.roles:
                    backup_data["user_roles"].append({
                        "user_id": member.id,
                        "roles": [r.name for r in member.roles if r != guild.default_role]
                    })
            
            # Backup emojis
            logger.info(f"💾 Сохранение эмодзи сервера {guild.name}...")
            for emoji in guild.emojis:
                backup_data["emojis"].append({
                    "name": emoji.name,
                    "url": str(emoji.url),
                    "animated": emoji.animated,
                    "roles": [r.id for r in emoji.roles] if emoji.roles else []
                })
            
            # Save to file
            backup_path = self.backups_dir / f"{name}.json"
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"✅ Резервная копия создана: {name}")
            self.db.execute(
                """INSERT INTO backups (guild_id, backup_name, created_at, size)
                   VALUES (?, ?, ?, ?)""",
                (guild.id, name, datetime.now(), backup_path.stat().st_size)
            )
            
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при создании резервной копии: {e}")
            return False
    
    async def restore_backup(self, guild: discord.Guild, backup_name: str) -> bool:
        """Restore a server from backup"""
        try:
            backup_path = self.backups_dir / f"{backup_name}.json"
            
            if not backup_path.exists():
                logger.error(f"❌ Резервная копия не найдена: {backup_name}")
                return False
            
            logger.info(f"🔄 Восстановление сервера {guild.name} из {backup_name}...")
            
            with open(backup_path, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            logger.info(f"🗑️ Удаление существующих ролей на сервере {guild.name}...")
            for role in guild.roles:
                if role == guild.default_role or role.managed:
                    continue
                try:
                    await role.delete(reason="Восстановление из резервной копии")
                    logger.debug(f"   ✅ Удалена роль: {role.name}")
                except Exception as e:
                    logger.warning(f"   ⚠️ Не удалось удалить роль {role.name}: {e}")
            
            logger.info(f"🗑️ Удаление существующих каналов на сервере {guild.name}...")
            for channel in guild.channels:
                try:
                    await channel.delete(reason="Восстановление из резервной копии")
                    logger.debug(f"   ✅ Удалён канал: {channel.name}")
                except Exception as e:
                    logger.warning(f"   ⚠️ Не удалось удалить канал {channel.name}: {e}")
            
            logger.info(f"📋 Восстановление ролей на сервере {guild.name}...")
            role_mapping = {}  # Map old names to new role objects
            sorted_roles = sorted(backup_data["roles"], key=lambda r: r["position"], reverse=True)
            
            for role_data in sorted_roles:
                try:
                    new_role = await guild.create_role(
                        name=role_data["name"],
                        color=discord.Color(role_data["color"]),
                        hoist=role_data["hoist"],
                        mentionable=role_data["mentionable"],
                        permissions=discord.Permissions(role_data["permissions"]),
                        reason="Восстановление из резервной копии"
                    )
                    role_mapping[role_data["name"]] = new_role
                    logger.debug(f"   ✅ Создана роль: {role_data['name']} (позиция {role_data['position']})")
                except Exception as e:
                    logger.warning(f"   ⚠️ Ошибка создания роли {role_data['name']}: {e}")
            
            logger.info(f"📂 Восстановление категорий на сервере {guild.name}...")
            category_mapping = {}  # Map old category names to new category objects
            categories = [ch for ch in backup_data["channels"] if ch["type"] == "ChannelType.category"]
            sorted_categories = sorted(categories, key=lambda c: c["position"])
            
            for category_data in sorted_categories:
                try:
                    overwrites = {}
                    for overwrite_data in category_data.get("overwrites", []):
                        if overwrite_data["target_type"] == "role":
                            target = role_mapping.get(overwrite_data["target_name"])
                            if not target:
                                target = discord.utils.get(guild.roles, name=overwrite_data["target_name"])
                        else:
                            target = guild.get_member(overwrite_data["target_id"])
                        
                        if target:
                            allow = discord.Permissions(overwrite_data["allow"])
                            deny = discord.Permissions(overwrite_data["deny"])
                            overwrites[target] = discord.PermissionOverwrite.from_pair(allow, deny)
                    
                    new_category = await guild.create_category(
                        name=category_data["name"],
                        overwrites=overwrites,
                        reason="Восстановление из резервной копии"
                    )
                    category_mapping[category_data["name"]] = new_category
                    logger.debug(f"   ✅ Создана категория: {category_data['name']}")
                except Exception as e:
                    logger.warning(f"   ⚠️ Ошибка создания категории {category_data['name']}: {e}", exc_info=True)
            
            logger.info(f"📝 Восстановление каналов на сервере {guild.name}...")
            regular_channels = [ch for ch in backup_data["channels"] if ch["type"] != "ChannelType.category"]
            sorted_channels = sorted(regular_channels, key=lambda c: c["position"])
            
            for channel_data in sorted_channels:
                try:
                    # Get category if exists
                    category = None
                    if channel_data.get("category_name"):
                        category = category_mapping.get(channel_data["category_name"])
                    
                    overwrites = {}
                    for overwrite_data in channel_data.get("overwrites", []):
                        if overwrite_data["target_type"] == "role":
                            target = role_mapping.get(overwrite_data["target_name"])
                            if not target:
                                target = discord.utils.get(guild.roles, name=overwrite_data["target_name"])
                        else:
                            target = guild.get_member(overwrite_data["target_id"])
                        
                        if target:
                            allow = discord.Permissions(overwrite_data["allow"])
                            deny = discord.Permissions(overwrite_data["deny"])
                            overwrites[target] = discord.PermissionOverwrite.from_pair(allow, deny)
                    
                    # Create channel based on type
                    if "text" in channel_data["type"].lower():
                        new_channel = await guild.create_text_channel(
                            name=channel_data["name"],
                            topic=channel_data.get("topic"),
                            slowmode_delay=channel_data.get("slowmode_delay", 0),
                            nsfw=channel_data.get("nsfw", False),
                            category=category,
                            overwrites=overwrites,
                            reason="Восстановление из резервной копии"
                        )
                        logger.debug(f"   ✅ Создан текстовый канал: {channel_data['name']}")
                    elif "voice" in channel_data["type"].lower():
                        new_channel = await guild.create_voice_channel(
                            name=channel_data["name"],
                            bitrate=channel_data.get("bitrate", 64000),
                            user_limit=channel_data.get("user_limit", 0),
                            category=category,
                            overwrites=overwrites,
                            reason="Восстановление из резервной копии"
                        )
                        logger.debug(f"   ✅ Создан голосовой канал: {channel_data['name']}")
                    elif "forum" in channel_data["type"].lower():
                        new_channel = await guild.create_forum(
                            name=channel_data["name"],
                            topic=channel_data.get("topic"),
                            category=category,
                            overwrites=overwrites,
                            reason="Восстановление из резервной копии"
                        )
                        logger.debug(f"   ✅ Создан форум: {channel_data['name']}")
                    elif "stage" in channel_data["type"].lower():
                        new_channel = await guild.create_stage_channel(
                            name=channel_data["name"],
                            category=category,
                            overwrites=overwrites,
                            reason="Восстановление из резервной копии"
                        )
                        logger.debug(f"   ✅ Создана трибуна: {channel_data['name']}")
                
                except Exception as e:
                    logger.warning(f"   ⚠️ Ошибка создания канала {channel_data.get('name', 'неизвестно')}: {e}", exc_info=True)
            
            logger.info(f"✅ Восстановление завершено для {guild.name}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при восстановлении резервной копии: {e}", exc_info=True)
            return False
    
    async def get_backups(self, guild_id: int) -> List[Dict]:
        """Get all backups for a guild (from filesystem)"""
        try:
            backups = []
            
            # Scan backup directory for files
            for backup_file in self.backups_dir.glob("*.json"):
                try:
                    # Read backup to get guild_id
                    with open(backup_file, 'r', encoding='utf-8') as f:
                        backup_data = json.load(f)
                    
                    # Check if backup belongs to this guild
                    if backup_data.get("guild_id") == guild_id:
                        file_stats = backup_file.stat()
                        backups.append({
                            "name": backup_file.stem,  # filename without .json
                            "created_at": backup_data.get("created_at", datetime.fromtimestamp(file_stats.st_ctime).isoformat()),
                            "size": file_stats.st_size
                        })
                except Exception as e:
                    logger.warning(f"⚠️ Не удалось прочитать бэкап {backup_file.name}: {e}")
                    continue
            
            # Sort by creation date (newest first)
            backups.sort(key=lambda x: x["created_at"], reverse=True)
            
            return backups
        except Exception as e:
            logger.error(f"❌ Ошибка при получении резервных копий: {e}")
            return []
    
    async def delete_backup(self, backup_name: str) -> bool:
        """Delete a backup"""
        try:
            backup_path = self.backups_dir / f"{backup_name}.json"
            if backup_path.exists():
                backup_path.unlink()
            
            self.db.execute(
                "DELETE FROM backups WHERE backup_name = ?",
                (backup_name,)
            )
            logger.info(f"✅ Резервная копия удалена: {backup_name}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении резервной копии: {e}")
            return False
