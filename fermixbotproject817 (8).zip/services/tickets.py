"""
Сервис тикетов поддержки для FermixBot
Полная система тикетов с типами, транскриптами и общением через ЛС
"""
import discord
from discord.ext import commands
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from services.database import Database
from io import BytesIO

logger = logging.getLogger(__name__)


class TicketType:
    """Типы тикетов"""
    TECH_SUPPORT = "tech_support"
    DONATION_SUPPORT = "donation_support"
    APPEAL = "appeal"
    GAME_REPORT = "game_report"
    DISCORD_REPORT = "discord_report"
    ADMIN_REPORT = "admin_report"
    EVENT_SUGGESTION = "event_suggestion"
    GENERAL_SUGGESTION = "general_suggestion"
    
    @classmethod
    def get_display_name(cls, ticket_type: str) -> str:
        """Получить отображаемое имя типа тикета"""
        names = {
            cls.TECH_SUPPORT: "🔧 Техническая поддержка",
            cls.DONATION_SUPPORT: "💳 Поддержка по донатам",
            cls.APPEAL: "📜 Апелляция",
            cls.GAME_REPORT: "🎮 Жалоба на нарушение в игре",
            cls.DISCORD_REPORT: "💬 Жалоба на нарушение в Discord",
            cls.ADMIN_REPORT: "⚠️ Жалоба на администрацию",
            cls.EVENT_SUGGESTION: "🎉 Предложение ивента",
            cls.GENERAL_SUGGESTION: "💡 Предложение по улучшению"
        }
        return names.get(ticket_type, "❓ Неизвестный тип")
    
    @classmethod
    def get_emoji(cls, ticket_type: str) -> str:
        """Получить эмодзи для типа тикета"""
        emojis = {
            cls.TECH_SUPPORT: "🔧",
            cls.DONATION_SUPPORT: "💳",
            cls.APPEAL: "📜",
            cls.GAME_REPORT: "🎮",
            cls.DISCORD_REPORT: "💬",
            cls.ADMIN_REPORT: "⚠️",
            cls.EVENT_SUGGESTION: "🎉",
            cls.GENERAL_SUGGESTION: "💡"
        }
        return emojis.get(ticket_type, "❓")


class TicketService:
    """Сервис управления тикетами"""
    
    def __init__(self, bot: discord.ext.commands.Bot, db: Database):
        self.bot = bot
        self.db = db
        
        # Кэш открытых тикетов {channel_id: ticket_data}
        self.active_tickets = {}
    
    async def create_ticket(self, guild_id: int, user_id: int, ticket_type: str, 
                          initial_message: str = None, ticket_data: Dict[str, str] = None) -> Optional[Dict[str, Any]]:
        """Создать новый тикет"""
        try:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return None
            
            user = guild.get_member(user_id)
            if not user:
                return None
            
            # Получить категорию для тикетов
            ticket_settings = self.db.fetch_one(
                "SELECT category_id, support_role_id, transcript_channel_id FROM ticket_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if not ticket_settings or not ticket_settings[0]:
                logger.error(f"❌ Категория тикетов не настроена для сервера {guild_id}")
                return None
            
            category_id = ticket_settings[0]
            category = guild.get_channel(category_id)
            
            if not category or not isinstance(category, discord.CategoryChannel):
                logger.error(f"❌ Категория тикетов {category_id} не найдена")
                return None
            
            
            # Создать канал тикета
            ticket_number = self.db.fetch_one(
                "SELECT COUNT(*) FROM tickets WHERE guild_id = ?",
                (guild_id,)
            )[0] + 1
            
            channel_name = f"ticket-{ticket_number:04d}"
            
            # Получить роль поддержки
            support_role = None
            if ticket_settings[1]:
                support_role = guild.get_role(ticket_settings[1])
            
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
            }
            
            if support_role:
                overwrites[support_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            
            ticket_channel = await category.create_text_channel(
                name=channel_name,
                overwrites=overwrites,
                reason=f"Тикет создан пользователем {user}"
            )
            
            # Сохранить в БД
            cursor = self.db.execute(
                """INSERT INTO tickets 
                   (guild_id, user_id, channel_id, ticket_type, status, created_at) 
                   VALUES (?, ?, ?, ?, 'open', datetime('now'))""",
                (guild_id, user_id, ticket_channel.id, ticket_type)
            )
            
            ticket_id = cursor.lastrowid
            
            # Создать welcome embed
            embed = discord.Embed(
                title=f"{TicketType.get_emoji(ticket_type)} Тикет #{ticket_number:04d}",
                description=f"**Тип:** {TicketType.get_display_name(ticket_type)}\n"
                           f"**Создатель:** {user.mention}\n"
                           f"**Статус:** 🟢 Открыт",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            if initial_message:
                embed.add_field(
                    name="📝 Описание проблемы",
                    value=initial_message[:1024],
                    inline=False
                )
            
            if ticket_data:
                if 'steam_id' in ticket_data and ticket_data['steam_id']:
                    embed.add_field(name="🎮 Steam ID", value=ticket_data['steam_id'], inline=True)
                
                if 'demo_link' in ticket_data and ticket_data['demo_link']:
                    embed.add_field(name="📹 Демка", value=ticket_data['demo_link'], inline=True)
                
                if 'reported_user' in ticket_data and ticket_data['reported_user']:
                    embed.add_field(name="👤 Нарушитель", value=ticket_data['reported_user'], inline=True)
                
                if 'admin_name' in ticket_data and ticket_data['admin_name']:
                    embed.add_field(name="⚠️ Администратор", value=ticket_data['admin_name'], inline=True)
                
                if 'evidence' in ticket_data and ticket_data['evidence']:
                    embed.add_field(name="📸 Доказательства", value=ticket_data['evidence'], inline=False)
            
            embed.add_field(
                name="ℹ️ Информация",
                value="Общение происходит через ЛС с ботом.\n"
                      "Отправьте боту сообщение в личку, и оно появится здесь.\n"
                      "Все ответы от поддержки будут приходить сюда.",
                inline=False
            )
            
            embed.set_footer(text=f"ID Тикета: {ticket_id}")
            
            view = TicketControlView(self, ticket_id)
            
            welcome_msg = await ticket_channel.send(
                content=(f"{support_role.mention}" if support_role else ""),
                embed=embed,
                view=view
            )
            
            # Сохранить в кэш
            self.active_tickets[ticket_channel.id] = {
                'id': ticket_id,
                'guild_id': guild_id,
                'user_id': user_id,
                'channel_id': ticket_channel.id,
                'ticket_type': ticket_type,
                'status': 'open',
                'claimed_by': None,
                'created_at': datetime.now()
            }
            
            # Сохранить сообщение в транскрипт
            if initial_message:
                self.db.execute(
                    """INSERT INTO ticket_messages 
                       (ticket_id, user_id, message_content, timestamp) 
                       VALUES (?, ?, ?, datetime('now'))""",
                    (ticket_id, user_id, initial_message)
                )
            
            logger.info(f"✅ Тикет #{ticket_number:04d} создан для {user} на сервере {guild}")
            
            # Отправить в ЛС пользователю
            try:
                dm_embed = discord.Embed(
                    title="✅ Тикет создан",
                    description=f"Ваш тикет #{ticket_number:04d} был создан.\n"
                               f"Тип: {TicketType.get_display_name(ticket_type)}",
                    color=discord.Color.green()
                )
                dm_embed.add_field(
                    name="📬 Общение",
                    value="Отправьте мне сообщение в этом чате, и оно будет переслано в ваш тикет.\n"
                          "Если у вас несколько открытых тикетов, я предложу выбрать нужный.",
                    inline=False
                )
                
                await user.send(embed=dm_embed)
            except:
                pass
            
            return {
                'ticket_id': ticket_id,
                'channel_id': ticket_channel.id,
                'ticket_number': ticket_number
            }
            
        except Exception as e:
            logger.error(f"❌ Ошибка при создании тикета: {e}")
            return None
    
    async def claim_ticket(self, ticket_id: int, staff_member: discord.Member) -> bool:
        """Взять тикет на разбор"""
        try:
            ticket = self.db.fetch_one(
                "SELECT channel_id, user_id, status FROM tickets WHERE id = ?",
                (ticket_id,)
            )
            
            if not ticket:
                return False
            
            if ticket[2] != 'open':
                return False
            
            # Обновить в БД
            self.db.execute(
                "UPDATE tickets SET claimed_by = ? WHERE id = ?",
                (staff_member.id, ticket_id)
            )
            
            # Обновить в кэше
            if ticket[0] in self.active_tickets:
                self.active_tickets[ticket[0]]['claimed_by'] = staff_member.id
            
            # Отправить сообщение в канал
            channel = staff_member.guild.get_channel(ticket[0])
            if channel:
                embed = discord.Embed(
                    title="👤 Тикет взят на разбор",
                    description=f"Сотрудник {staff_member.mention} взял этот тикет на разбор.",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                await channel.send(embed=embed)
                
                # Уведомить пользователя в ЛС
                user = staff_member.guild.get_member(ticket[1])
                if user:
                    try:
                        dm_embed = discord.Embed(
                            title="👤 Ваш тикет взят на разбор",
                            description=f"Сотрудник поддержки начал разбор вашего тикета.",
                            color=discord.Color.blue()
                        )
                        await user.send(embed=dm_embed)
                    except:
                        pass
            
            logger.info(f"✅ Тикет {ticket_id} взят на разбор сотрудником {staff_member}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при взятии тикета: {e}")
            return False
    
    async def unclaim_ticket(self, ticket_id: int, staff_member: discord.Member) -> bool:
        """Отказаться от разбора тикета"""
        try:
            ticket = self.db.fetch_one(
                "SELECT channel_id, user_id, status, claimed_by FROM tickets WHERE id = ?",
                (ticket_id,)
            )
            
            if not ticket:
                return False
            
            if ticket[2] != 'open':
                return False
            
            if ticket[3] != staff_member.id:
                return False
            
            # Обновить в БД
            self.db.execute(
                "UPDATE tickets SET claimed_by = NULL WHERE id = ?",
                (ticket_id,)
            )
            
            # Обновить в кэше
            if ticket[0] in self.active_tickets:
                self.active_tickets[ticket[0]]['claimed_by'] = None
            
            # Отправить сообщение в канал
            channel = staff_member.guild.get_channel(ticket[0])
            if channel:
                embed = discord.Embed(
                    title="❌ Сотрудник отказался от разбора",
                    description=f"Сотрудник {staff_member.mention} отказался от разбора этого тикета.\n"
                               f"Тикет снова свободен для взятия.",
                    color=discord.Color.orange(),
                    timestamp=datetime.now()
                )
                await channel.send(embed=embed)
                
                # Уведомить пользователя в ЛС
                user = staff_member.guild.get_member(ticket[1])
                if user:
                    try:
                        dm_embed = discord.Embed(
                            title="⏸️ Ваш тикет снова в очереди",
                            description=f"Сотрудник отказался от разбора. Скоро вашим тикетом займется другой сотрудник.",
                            color=discord.Color.orange()
                        )
                        await user.send(embed=dm_embed)
                    except:
                        pass
            
            logger.info(f"✅ Сотрудник {staff_member} отказался от тикета {ticket_id}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при отказе от тикета: {e}")
            return False
    
    async def transfer_ticket(self, ticket_id: int, from_staff: discord.Member, to_staff: discord.Member) -> bool:
        """Передать тикет другому сотруднику"""
        try:
            ticket = self.db.fetch_one(
                "SELECT channel_id, user_id, status, claimed_by FROM tickets WHERE id = ?",
                (ticket_id,)
            )
            
            if not ticket:
                return False
            
            if ticket[2] != 'open':
                return False
            
            if ticket[3] != from_staff.id:
                return False
            
            # Обновить в БД
            self.db.execute(
                "UPDATE tickets SET claimed_by = ? WHERE id = ?",
                (to_staff.id, ticket_id)
            )
            
            # Обновить в кэше
            if ticket[0] in self.active_tickets:
                self.active_tickets[ticket[0]]['claimed_by'] = to_staff.id
            
            # Отправить сообщение в канал
            channel = from_staff.guild.get_channel(ticket[0])
            if channel:
                embed = discord.Embed(
                    title="🔄 Тикет передан",
                    description=f"Тикет передан от {from_staff.mention} к {to_staff.mention}",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                await channel.send(embed=embed)
                
                # Уведомить пользователя в ЛС
                user = from_staff.guild.get_member(ticket[1])
                if user:
                    try:
                        dm_embed = discord.Embed(
                            title="🔄 Ваш тикет передан",
                            description=f"Ваш тикет теперь разбирает другой сотрудник поддержки.",
                            color=discord.Color.blue()
                        )
                        await user.send(embed=dm_embed)
                    except:
                        pass
            
            logger.info(f"✅ Тикет {ticket_id} передан от {from_staff} к {to_staff}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при передаче тикета: {e}")
            return False
    
    async def close_ticket(self, ticket_id: int, closed_by: discord.Member, reason: str = None) -> bool:
        """Закрыть тикет и создать транскрипт"""
        try:
            ticket = self.db.fetch_one(
                "SELECT channel_id, user_id, guild_id, ticket_type FROM tickets WHERE id = ?",
                (ticket_id,)
            )
            
            if not ticket:
                return False
            
            channel = self.bot.get_channel(ticket[0])
            if not channel:
                return False
            
            guild = self.bot.get_guild(ticket[2])
            user = guild.get_member(ticket[1]) if guild else None
            
            transcript_text, transcript_file = await self._create_transcript(ticket_id, channel)
            
            # Сохранить транскрипт в БД
            self.db.execute(
                "UPDATE tickets SET status = 'closed', closed_by = ?, closed_at = datetime('now'), transcript = ? WHERE id = ?",
                (closed_by.id, transcript_text, ticket_id)
            )
            
            # Удалить из кэша
            if channel.id in self.active_tickets:
                del self.active_tickets[channel.id]
            
            transcript_channel_id = self.db.fetch_one(
                "SELECT transcript_channel_id FROM ticket_settings WHERE guild_id = ?",
                (guild.id,)
            )
            
            if transcript_channel_id and transcript_channel_id[0]:
                transcript_channel = guild.get_channel(transcript_channel_id[0])
                if transcript_channel:
                    ticket_number = self.db.fetch_one(
                        "SELECT COUNT(*) FROM tickets WHERE guild_id = ? AND id <= ?",
                        (guild.id, ticket_id)
                    )[0]
                    
                    transcript_embed = discord.Embed(
                        title=f"📋 Транскрипт тикета #{ticket_number:04d}",
                        description=f"**Пользователь:** <@{ticket[1]}>\n"
                                   f"**Тип:** {TicketType.get_display_name(ticket[3])}\n"
                                   f"**Закрыл:** {closed_by.mention}\n"
                                   f"**Причина:** {reason if reason else 'Не указана'}",
                        color=discord.Color.red(),
                        timestamp=datetime.now()
                    )
                    
                    await transcript_channel.send(
                        embed=transcript_embed,
                        file=transcript_file
                    )
            
            # Отправить транскрипт в ЛС пользователю
            if user:
                try:
                    embed = discord.Embed(
                        title="📋 Ваш тикет закрыт",
                        description=f"Тикет был закрыт сотрудником {closed_by.mention}",
                        color=discord.Color.red(),
                        timestamp=datetime.now()
                    )
                    
                    if reason:
                        embed.add_field(name="📝 Причина", value=reason, inline=False)
                    
                    embed.add_field(
                        name="📄 Транскрипт",
                        value="Транскрипт вашего тикета прикреплен ниже.",
                        inline=False
                    )
                    
                    # Создать новый файл для пользователя
                    user_file = discord.File(
                        fp=BytesIO(transcript_text.encode('utf-8')),
                        filename=f"ticket-{ticket_id}-transcript.txt"
                    )
                    
                    await user.send(embed=embed, file=user_file)
                except Exception as e:
                    logger.warning(f"⚠️ Не удалось отправить транскрипт пользователю: {e}")
            
            # Удалить канал
            try:
                await channel.delete(reason=f"Тикет закрыт: {reason if reason else 'Нет причины'}")
            except:
                pass
            
            # Залогировать
            if hasattr(self.bot, 'log_service'):
                details = {
                    "Тикет ID": str(ticket_id),
                    "Пользователь": f"<@{ticket[1]}>",
                    "Тип": TicketType.get_display_name(ticket[3]),
                    "Закрыл": closed_by.mention
                }
                
                if reason:
                    details["Причина"] = reason
                
                await self.bot.log_service.log_action(
                    guild.id,
                    closed_by.id,
                    "TICKET_CLOSED",
                    ticket[1],
                    reason,
                    details
                )
            
            logger.info(f"✅ Тикет {ticket_id} закрыт сотрудником {closed_by}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при закрытии тикета: {e}")
            return False
    
    async def _create_transcript(self, ticket_id: int, channel: discord.TextChannel) -> tuple[str, discord.File]:
        """Создать транскрипт тикета"""
        try:
            transcript_lines = []
            transcript_lines.append(f"{'=' * 80}")
            transcript_lines.append(f"ТРАНСКРИПТ ТИКЕТА #{ticket_id}")
            transcript_lines.append(f"Канал: #{channel.name}")
            transcript_lines.append(f"Сервер: {channel.guild.name}")
            transcript_lines.append(f"Дата закрытия: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}")
            transcript_lines.append(f"{'=' * 80}")
            transcript_lines.append("")
            
            # Получить все сообщения
            messages = []
            async for message in channel.history(limit=None, oldest_first=True):
                messages.append(message)
            
            for message in messages:
                timestamp = message.created_at.strftime('%d.%m.%Y %H:%M:%S')
                author = f"{message.author.display_name} ({message.author.id})"
                
                transcript_lines.append(f"[{timestamp}] {author}:")
                
                if message.content:
                    # Разбить длинные сообщения на строки
                    for line in message.content.split('\n'):
                        transcript_lines.append(f"  {line}")
                
                if message.embeds:
                    for embed in message.embeds:
                        transcript_lines.append(f"  [Embed]")
                        if embed.title:
                            transcript_lines.append(f"    Заголовок: {embed.title}")
                        if embed.description:
                            transcript_lines.append(f"    Описание: {embed.description[:200]}...")
                
                if message.attachments:
                    for attachment in message.attachments:
                        transcript_lines.append(f"  📎 Вложение: {attachment.filename} ({attachment.url})")
                
                transcript_lines.append("")
            
            transcript_lines.append(f"{'=' * 80}")
            transcript_lines.append(f"КОНЕЦ ТРАНСКРИПТА")
            transcript_lines.append(f"Всего сообщений: {len(messages)}")
            transcript_lines.append(f"{'=' * 80}")
            
            transcript_text = "\n".join(transcript_lines)
            
            # Создать файл
            transcript_file = discord.File(
                fp=BytesIO(transcript_text.encode('utf-8')),
                filename=f"ticket-{ticket_id}-transcript.txt"
            )
            
            return transcript_text, transcript_file
            
        except Exception as e:
            logger.error(f"❌ Ошибка при создании транскрипта: {e}")
            error_text = f"Ошибка при создании транскрипта: {e}"
            error_file = discord.File(
                fp=BytesIO(error_text.encode('utf-8')),
                filename=f"ticket-{ticket_id}-error.txt"
            )
            return error_text, error_file
    
    async def handle_ticket_message(self, message: discord.Message) -> bool:
        """Обработать сообщение в канале тикета и переслать пользователю"""
        try:
            # Проверить, что это канал тикета
            if message.channel.id not in self.active_tickets:
                return False
            
            # Игнорировать сообщения бота
            if message.author.bot:
                return False
            
            ticket_data = self.active_tickets[message.channel.id]
            
            # Получить пользователя
            guild = self.bot.get_guild(ticket_data['guild_id'])
            if not guild:
                return False
            
            user = guild.get_member(ticket_data['user_id'])
            if not user:
                return False
            
            # Создать embed для пересылки
            embed = discord.Embed(
                description=message.content if message.content else "*Без текста*",
                color=discord.Color.green(),
                timestamp=message.created_at
            )
            embed.set_author(
                name=f"💬 Поддержка: {message.author.display_name}",
                icon_url=message.author.display_avatar.url
            )
            # Добавляем информацию о тикете
            ticket_emoji = TicketType.get_emoji(ticket_data['ticket_type'])
            ticket_name = TicketType.get_display_name(ticket_data['ticket_type'])
            embed.set_footer(text=f"{ticket_emoji} Тикет #{ticket_data['id']:04d} • {ticket_name}")
            
            # Отправить пользователю в ЛС
            try:
                await user.send(embed=embed)
                
                # Отправить вложения
                for attachment in message.attachments:
                    await user.send(f"📎 {attachment.url}")
                
                # Подтвердить отправку
                try:
                    await message.add_reaction("✅")
                except:
                    pass
                
                # Сохранить в транскрипт
                self.db.execute(
                    """INSERT INTO ticket_messages 
                       (ticket_id, user_id, message_content, timestamp) 
                       VALUES (?, ?, ?, datetime('now'))""",
                    (ticket_data['id'], message.author.id, message.content)
                )
                
                return True
                
            except discord.Forbidden:
                # Не может отправить ЛС
                await message.channel.send(
                    f"⚠️ Не удается отправить сообщение пользователю {user.mention}. "
                    f"Возможно, у него закрыты личные сообщения."
                )
                return False
                
        except Exception as e:
            logger.error(f"❌ Ошибка при пересылке сообщения из тикета: {e}")
            return False
    
    async def handle_dm_message(self, message: discord.Message) -> bool:
        """Обработать сообщение в ЛС и переслать в тикет"""
        try:
            user_tickets = []
            for ticket_data in self.active_tickets.values():
                if ticket_data['user_id'] == message.author.id and ticket_data['status'] == 'open':
                    user_tickets.append(ticket_data)
            
            if not user_tickets:
                return False
            
            if len(user_tickets) == 1:
                ticket_data = user_tickets[0]
                return await self._send_message_to_ticket(message, ticket_data)
            else:
                # Показать меню выбора тикета
                view = TicketSelectView(self, user_tickets, message)
                
                embed = discord.Embed(
                    title="📬 Выберите тикет",
                    description="У вас открыто несколько тикетов. Выберите, в какой из них отправить сообщение:",
                    color=discord.Color.blue()
                )
                
                for ticket in user_tickets:
                    embed.add_field(
                        name=f"{TicketType.get_emoji(ticket['ticket_type'])} Тикет #{ticket['id']:04d}",
                        value=f"**Тип:** {TicketType.get_display_name(ticket['ticket_type'])}\n"
                              f"**Создан:** <t:{int(ticket['created_at'].timestamp())}:R>",
                        inline=False
                    )
                
                await message.author.send(embed=embed, view=view)
                return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке ЛС сообщения: {e}")
            return False
    
    async def _send_message_to_ticket(self, message: discord.Message, ticket_data: Dict) -> bool:
        """Отправить сообщение в конкретный тикет"""
        try:
            channel = self.bot.get_channel(ticket_data['channel_id'])
            if not channel:
                return False
            
            # Создать embed для пересылки
            embed = discord.Embed(
                description=message.content,
                color=discord.Color.blue(),
                timestamp=message.created_at
            )
            embed.set_author(
                name=f"💬 {message.author.display_name}",
                icon_url=message.author.display_avatar.url
            )
            embed.set_footer(text=f"Тикет #{ticket_data['id']:04d}")
            
            # Отправить в канал тикета
            await channel.send(embed=embed)
            
            # Сохранить в транскрипт
            self.db.execute(
                """INSERT INTO ticket_messages 
                   (ticket_id, user_id, message_content, timestamp) 
                   VALUES (?, ?, ?, datetime('now'))""",
                (ticket_data['id'], message.author.id, message.content)
            )
            
            # Отправить вложения
            for attachment in message.attachments:
                await channel.send(f"📎 Вложение: {attachment.url}")
            
            # Подтверждение пользователю
            await message.add_reaction("✅")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при отправке сообщения в тикет: {e}")
            return False
    
    async def add_user_to_ticket(self, ticket_id: int, user: discord.Member, added_by: discord.Member) -> bool:
        """Добавить участника в тикет"""
        try:
            ticket = self.db.fetch_one(
                "SELECT channel_id, user_id FROM tickets WHERE id = ?",
                (ticket_id,)
            )
            
            if not ticket:
                return False
            
            channel = self.bot.get_channel(ticket[0])
            if not channel:
                return False
            
            # Выдать права на просмотр канала
            await channel.set_permissions(
                user,
                read_messages=True,
                send_messages=True,
                reason=f"Добавлен в тикет пользователем {added_by}"
            )
            
            # Уведомить в канале
            embed = discord.Embed(
                title="👥 Участник добавлен",
                description=f"{user.mention} был добавлен в тикет пользователем {added_by.mention}",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            await channel.send(embed=embed)
            
            # Уведомить создателя тикета
            creator = channel.guild.get_member(ticket[1])
            if creator:
                try:
                    dm_embed = discord.Embed(
                        title="👥 В ваш тикет добавлен участник",
                        description=f"{user.mention} был добавлен в ваш тикет.",
                        color=discord.Color.blue()
                    )
                    await creator.send(embed=dm_embed)
                except:
                    pass
            
            logger.info(f"✅ Пользователь {user} добавлен в тикет {ticket_id}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при добавлении пользователя в тикет: {e}")
            return False


class AddUserView(discord.ui.View):
    """View с селектором для добавления участника в тикет"""
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__(timeout=180)
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
        self.add_item(AddUserSelect(ticket_service, ticket_id))


class AddUserSelect(discord.ui.UserSelect):
    """Селектор для выбора пользователя для добавления в тикет"""
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__(
            placeholder="Выберите пользователя для добавления...",
            min_values=1,
            max_values=1
        )
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
    
    async def callback(self, interaction: discord.Interaction):
        user = self.values[0]
        
        success = await self.ticket_service.add_user_to_ticket(
            self.ticket_id,
            user,
            interaction.user
        )
        
        if success:
            await interaction.response.send_message(
                f"✅ Пользователь {user.mention} добавлен в тикет!",
                ephemeral=True
            )
            self.view.stop()
        else:
            await interaction.response.send_message(
                "❌ Не удалось добавить пользователя",
                ephemeral=True
            )


class TransferTicketView(discord.ui.View):
    """View с селектором для передачи тикета другому сотруднику"""
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__(timeout=180)
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
        self.add_item(TransferTicketSelect(ticket_service, ticket_id))


class TransferTicketSelect(discord.ui.UserSelect):
    """Селектор для выбора сотрудника для передачи тикета"""
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__(
            placeholder="Выберите сотрудника для передачи тикета...",
            min_values=1,
            max_values=1
        )
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
    
    async def callback(self, interaction: discord.Interaction):
        to_staff = self.values[0]
        
        success = await self.ticket_service.transfer_ticket(
            self.ticket_id,
            interaction.user,
            to_staff
        )
        
        if success:
            await interaction.response.send_message(
                f"✅ Тикет передан сотруднику {to_staff.mention}!",
                ephemeral=True
            )
            self.view.stop()
        else:
            await interaction.response.send_message(
                "❌ Не удалось передать тикет. Возможно, вы не являетесь разборщиком этого тикета.",
                ephemeral=True
            )


class TicketControlView(discord.ui.View):
    """Кнопки управления тикетом"""
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__(timeout=None)
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
    
    @discord.ui.button(
        label="Взять на разбор",
        emoji="✋",
        style=discord.ButtonStyle.green,
        custom_id="claim_ticket"
    )
    async def claim_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        success = await self.ticket_service.claim_ticket(self.ticket_id, interaction.user)
        
        if success:
            await interaction.response.send_message(
                f"✅ Вы взяли тикет на разбор!",
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"❌ Не удалось взять тикет на разбор",
                ephemeral=True
            )
    
    @discord.ui.button(
        label="Отказаться от разбора",
        emoji="❌",
        style=discord.ButtonStyle.gray,
        custom_id="unclaim_ticket"
    )
    async def unclaim_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        success = await self.ticket_service.unclaim_ticket(self.ticket_id, interaction.user)
        
        if success:
            await interaction.response.send_message(
                f"✅ Вы отказались от разбора тикета!",
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"❌ Не удалось отказаться от разбора. Возможно, вы не являетесь разборщиком этого тикета.",
                ephemeral=True
            )
    
    @discord.ui.button(
        label="Передать тикет",
        emoji="🔄",
        style=discord.ButtonStyle.blurple,
        custom_id="transfer_ticket"
    )
    async def transfer_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = TransferTicketView(self.ticket_service, self.ticket_id)
        await interaction.response.send_message(
            view=view,
            ephemeral=True
        )
    
    @discord.ui.button(
        label="Добавить участника",
        emoji="➕",
        style=discord.ButtonStyle.blurple,
        custom_id="add_user",
        row=1
    )
    async def add_user_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = AddUserView(self.ticket_service, self.ticket_id)
        await interaction.response.send_message(
            view=view,
            ephemeral=True
        )
    
    @discord.ui.button(
        label="Сохранить транскрипт",
        emoji="📋",
        style=discord.ButtonStyle.gray,
        custom_id="save_transcript",
        row=1
    )
    async def transcript_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        try:
            transcript_text, transcript_file = await self.ticket_service._create_transcript(
                self.ticket_id,
                interaction.channel
            )
            
            await interaction.followup.send(
                content="📋 Транскрипт тикета:",
                file=transcript_file,
                ephemeral=True
            )
        except Exception as e:
            await interaction.followup.send(
                f"❌ Ошибка при создании транскрипта: {e}",
                ephemeral=True
            )
    
    @discord.ui.button(
        label="Закрыть тикет",
        emoji="🔒",
        style=discord.ButtonStyle.red,
        custom_id="close_ticket",
        row=1
    )
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = CloseTicketModal(self.ticket_service, self.ticket_id)
        await interaction.response.send_modal(modal)


class CloseTicketModal(discord.ui.Modal, title="Закрыть тикет"):
    """Модальное окно для закрытия тикета"""
    
    reason = discord.ui.TextInput(
        label="Причина закрытия",
        style=discord.TextStyle.paragraph,
        placeholder="Укажите причину закрытия тикета...",
        required=False,
        max_length=500
    )
    
    def __init__(self, ticket_service: 'TicketService', ticket_id: int):
        super().__init__()
        self.ticket_service = ticket_service
        self.ticket_id = ticket_id
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        success = await self.ticket_service.close_ticket(
            self.ticket_id,
            interaction.user,
            self.reason.value if self.reason.value else None
        )
        
        if success:
            await interaction.followup.send(
                "✅ Тикет закрыт! Транскрипт отправлен пользователю.",
                ephemeral=True
            )
        else:
            await interaction.followup.send(
                "❌ Не удалось закрыть тикет",
                ephemeral=True
            )


class TicketSelectView(discord.ui.View):
    """View для выбора тикета из нескольких открытых"""
    
    def __init__(self, ticket_service, tickets: List[Dict], original_message: discord.Message):
        super().__init__(timeout=300)
        self.ticket_service = ticket_service
        self.tickets = tickets
        self.original_message = original_message
        
        # Добавить кнопки для каждого тикета
        for ticket in tickets[:5]:  # Максимум 5 тикетов для отображения
            button = discord.ui.Button(
                label=f"Тикет #{ticket['id']:04d}",
                emoji=TicketType.get_emoji(ticket['ticket_type']),
                style=discord.ButtonStyle.primary,
                custom_id=f"select_ticket_{ticket['id']}"
            )
            button.callback = self._create_callback(ticket)
            self.add_item(button)
    
    def _create_callback(self, ticket_data: Dict):
        async def callback(interaction: discord.Interaction):
            await interaction.response.defer()
            
            # Отправить сообщение в выбранный тикет
            success = await self.ticket_service._send_message_to_ticket(
                self.original_message, 
                ticket_data
            )
            
            if success:
                embed = discord.Embed(
                    title="✅ Сообщение отправлено",
                    description=f"Ваше сообщение отправлено в тикет #{ticket_data['id']:04d}",
                    color=discord.Color.green()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось отправить сообщение в тикет",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
            
            # Удалить меню выбора
            try:
                await interaction.message.delete()
            except:
                pass
        
        return callback
