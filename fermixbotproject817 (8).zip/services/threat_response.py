"""
Automatic Threat Response Service for FermixBot
Handles automatic response to detected attacks
Автоматическое реагирование на атаки
"""
import discord
import logging
from typing import Optional
from services.database import Database
from services.security import SecurityService

logger = logging.getLogger(__name__)


class ThreatResponseService:
    """Service for automatic threat response and mitigation"""
    
    def __init__(self, db: Database, bot: discord.ext.commands.Bot = None, security_service: SecurityService = None):
        self.db = db
        self.bot = bot
        self.security_service = security_service
    
    async def handle_nuke_attempt(self, guild: discord.Guild, attacker_id: int, 
                                 action_type: str, reason: str) -> bool:
        """Handle nuke attempt by removing roles and banning bot"""
        try:
            logger.warning(f"💣 Обработка попытки нука на сервере {guild.name}...")
            
            member = guild.get_member(attacker_id)
            if not member:
                logger.warning(f"⚠️ Участник {attacker_id} не найден на сервере")
                return False
            
            # Remove all roles from attacker
            logger.info(f"🔓 Удаление всех ролей у участника {attacker_id}...")
            try:
                for role in member.roles:
                    if role != guild.default_role:
                        await member.remove_roles(role, reason="Автоматическое реагирование на нук")
                        logger.debug(f"   ✅ Роль удалена: {role.name}")
            except Exception as e:
                logger.error(f"   ❌ Ошибка удаления ролей: {e}")
            
            # Ban the attacker
            logger.info(f"🚫 Блокировка участника {attacker_id}...")
            try:
                await guild.ban(member, reason=f"Автоматическое реагирование: {reason}")
                logger.info(f"   ✅ Участник заблокирован")
            except Exception as e:
                logger.error(f"   ❌ Ошибка блокировки: {e}")
            
            # Log the action
            self.db.log_action(guild.id, attacker_id, "NUKE_BLOCKED", attacker_id, reason)
            
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке нука: {e}")
            return False
    
    async def handle_raid(self, guild: discord.Guild, reason: str) -> bool:
        """Handle raid attack by enabling high security"""
        try:
            logger.warning(f"🔨 Обработка рейда на сервере {guild.name}...")
            
            # Update guild settings to block joins temporarily
            self.db.execute(
                """UPDATE guild_settings SET raid_lockdown = 1, raid_lockdown_time = datetime('now')
                   WHERE guild_id = ?""",
                (guild.id,)
            )
            
            # Ban recent joiners (last 5 minutes)
            import time
            recent_joiners = [m for m in guild.members if m.joined_at and 
                            (time.time() - m.joined_at.timestamp()) < 300]
            
            logger.info(f"🚫 Блокировка недавних участников ({len(recent_joiners)} шт)...")
            banned_count = 0
            for member in recent_joiners:
                try:
                    if member.top_role < guild.me.top_role:
                        await guild.ban(member, reason="Автоматическое реагирование на рейд")
                        banned_count += 1
                        logger.debug(f"   ✅ Заблокирован: {member}")
                except Exception as e:
                    logger.warning(f"   ⚠️ Ошибка блокировки {member}: {e}")
            
            logger.info(f"✅ Заблокировано {banned_count} недавних участников")
            self.db.log_action(guild.id, 0, "RAID_MITIGATED", None, f"Заблокировано {banned_count} участников")
            
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке рейда: {e}")
            return False
    
    async def remove_dangerous_bots(self, guild: discord.Guild) -> int:
        """Remove bots with admin or dangerous permissions"""
        try:
            logger.info(f"🤖 Поиск опасных ботов на сервере {guild.name}...")
            
            removed = 0
            for member in guild.members:
                if not member.bot:
                    continue
                
                # Check if bot has admin or other dangerous perms
                perms = member.guild_permissions
                if perms.administrator or perms.manage_guild or perms.manage_roles:
                    try:
                        await member.ban(reason="Опасный бот - автоматическое удаление")
                        removed += 1
                        logger.info(f"   ✅ Удален опасный бот: {member}")
                        self.db.log_action(guild.id, member.id, "DANGEROUS_BOT_REMOVED", member.id, 
                                         f"Бот с правами: admin={perms.administrator}, manage_guild={perms.manage_guild}")
                    except Exception as e:
                        logger.warning(f"   ⚠️ Ошибка удаления бота {member}: {e}")
            
            logger.info(f"✅ Удалено опасных ботов: {removed}")
            return removed
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении опасных ботов: {e}")
            return 0
    
    async def remove_dangerous_roles(self, guild: discord.Guild) -> int:
        """Remove roles with dangerous permissions"""
        try:
            logger.info(f"🚩 Удаление опасных ролей на сервере {guild.name}...")
            
            removed = 0
            dangerous_roles_list = await self.security_service.get_dangerous_roles(guild.id)
            
            for role_data in dangerous_roles_list:
                role_id = role_data[0]
                role = guild.get_role(role_id)
                
                if not role:
                    continue
                
                try:
                    await role.delete(reason="Опасная роль - автоматическое удаление")
                    removed += 1
                    logger.info(f"   ✅ Удалена опасная роль: {role.name}")
                    self.db.log_action(guild.id, 0, "DANGEROUS_ROLE_REMOVED", role_id, f"Роль: {role.name}")
                except Exception as e:
                    logger.warning(f"   ⚠️ Ошибка удаления роли {role.name}: {e}")
            
            logger.info(f"✅ Удалено опасных ролей: {removed}")
            return removed
        except Exception as e:
            logger.error(f"❌ Ошибка при удалении опасных ролей: {e}")
            return 0
    
    async def initiate_server_recovery(self, guild: discord.Guild, backup_name: str) -> bool:
        """Initiate server recovery from backup after attack"""
        try:
            logger.warning(f"🔧 Начало восстановления сервера {guild.name} из {backup_name}...")
            
            # Remove dangerous bots
            await self.remove_dangerous_bots(guild)
            
            # Remove dangerous roles
            await self.remove_dangerous_roles(guild)
            
            # Clear all channels (except important ones)
            logger.info(f"🗑️ Очистка каналов на сервере {guild.name}...")
            for channel in guild.channels:
                if isinstance(channel, discord.TextChannel) and channel.name not in ["general", "общее"]:
                    try:
                        await channel.delete(reason="Очистка при восстановлении сервера")
                        logger.debug(f"   ✅ Удален канал: {channel.name}")
                    except Exception as e:
                        logger.warning(f"   ⚠️ Ошибка удаления канала: {e}")
            
            self.db.log_action(guild.id, 0, "SERVER_RECOVERY_STARTED", None, f"Восстановление из {backup_name}")
            
            logger.info(f"✅ Восстановление сервера инициировано")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при инициировании восстановления: {e}")
            return False
