"""
Сервис логирования для FermixBot
Красивое форматирование логов в стиле Discord Audit Log
"""
import discord
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from services.database import Database

logger = logging.getLogger(__name__)


class LogService:
    """Обработчик логирования и аудита с красивым форматированием"""
    
    def __init__(self, bot: discord.ext.commands.Bot, db: Database):
        self.bot = bot
        self.db = db
        self.log_channels_cache = {}
    
    async def get_log_channel(self, guild_id: int) -> Optional[discord.TextChannel]:
        """Получить канал логов для гильдии"""
        try:
            # Проверяем кэш
            if guild_id in self.log_channels_cache:
                return self.log_channels_cache[guild_id]
            
            # Получаем из БД
            channel_id = self.db.get_log_channel(guild_id)
            if not channel_id:
                return None
            
            # Получаем канал
            channel = self.bot.get_channel(channel_id)
            if channel:
                self.log_channels_cache[guild_id] = channel
                return channel
            
            return None
        except Exception as e:
            logger.error(f"Ошибка получения канала логов: {e}")
            return None
    
    async def log_message_delete(self, message: discord.Message, deleter: Optional[discord.Member] = None):
        """Логирование удаления сообщения"""
        try:
            log_channel = await self.get_log_channel(message.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🗑️ Сообщение удалено",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            # Автор сообщения
            embed.add_field(
                name="Автор сообщения",
                value=f"{message.author.mention}\n`{message.author}`",
                inline=True
            )
            
            # Кто удалил (если не автор)
            if deleter and deleter.id != message.author.id:
                embed.add_field(
                    name="Удалил",
                    value=f"{deleter.mention}\n`{deleter}`",
                    inline=True
                )
            else:
                embed.add_field(
                    name="Удалил",
                    value="Сам автор",
                    inline=True
                )
            
            # Канал
            embed.add_field(
                name="Канал",
                value=message.channel.mention if hasattr(message.channel, 'mention') else str(message.channel),
                inline=True
            )
            
            # Содержание сообщения
            content = message.content[:1000] if message.content else "*Сообщение без текста*"
            if len(message.content) > 1000:
                content += "..."
            embed.add_field(name="Содержание", value=content, inline=False)
            
            # Вложения
            if message.attachments:
                attachments_text = "\n".join([f"[{att.filename}]({att.url})" for att in message.attachments[:5]])
                embed.add_field(name="Вложения", value=attachments_text, inline=False)
            
            embed.set_footer(text=f"ID сообщения: {message.id} | ID автора: {message.author.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования удаления сообщения: {e}")
    
    async def log_message_edit(self, before: discord.Message, after: discord.Message):
        """Логирование редактирования сообщения"""
        try:
            log_channel = await self.get_log_channel(before.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="✏️ Сообщение отредактировано",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            # Автор
            embed.add_field(
                name="Автор",
                value=f"{before.author.mention}\n`{before.author}`",
                inline=True
            )
            
            # Канал
            embed.add_field(
                name="Канал",
                value=before.channel.mention if hasattr(before.channel, 'mention') else str(before.channel),
                inline=True
            )
            
            # Ссылка на сообщение
            embed.add_field(
                name="Перейти",
                value=f"[К сообщению]({after.jump_url})",
                inline=True
            )
            
            # Старое содержание
            before_content = before.content[:500] if before.content else "*Нет текста*"
            if len(before.content) > 500:
                before_content += "..."
            embed.add_field(name="Было", value=before_content, inline=False)
            
            # Новое содержание
            after_content = after.content[:500] if after.content else "*Нет текста*"
            if len(after.content) > 500:
                after_content += "..."
            embed.add_field(name="Стало", value=after_content, inline=False)
            
            embed.set_footer(text=f"ID сообщения: {after.id} | ID автора: {after.author.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования редактирования сообщения: {e}")
    
    async def log_bulk_message_delete(self, messages: List[discord.Message], channel: discord.TextChannel, deleter: Optional[discord.Member] = None):
        """Логирование массового удаления сообщений"""
        try:
            log_channel = await self.get_log_channel(channel.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🧹 Массовое удаление сообщений",
                description=f"Удалено **{len(messages)}** сообщений",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            if deleter:
                embed.add_field(
                    name="Удалил",
                    value=f"{deleter.mention}\n`{deleter}`",
                    inline=True
                )
            
            embed.add_field(
                name="Канал",
                value=channel.mention,
                inline=True
            )
            
            embed.add_field(
                name="Количество",
                value=f"{len(messages)} сообщений",
                inline=True
            )
            
            # Статистика по авторам
            authors = {}
            for msg in messages:
                author_name = str(msg.author)
                authors[author_name] = authors.get(author_name, 0) + 1
            
            if authors:
                authors_text = "\n".join([f"**{name}**: {count}" for name, count in sorted(authors.items(), key=lambda x: x[1], reverse=True)[:10]])
                embed.add_field(name="Авторы сообщений", value=authors_text, inline=False)
            
            embed.set_footer(text=f"Канал ID: {channel.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования массового удаления: {e}")
    
    async def log_member_ban(self, guild: discord.Guild, user: discord.User, moderator: Optional[discord.Member] = None, reason: Optional[str] = None):
        """Логирование бана участника"""
        try:
            log_channel = await self.get_log_channel(guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🔨 Участник забанен",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Забаненный участник",
                value=f"{user.mention}\n`{user}`\n`ID: {user.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            if reason:
                embed.add_field(name="Причина", value=reason[:1024], inline=False)
            
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"ID участника: {user.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования бана: {e}")
    
    async def log_member_unban(self, guild: discord.Guild, user: discord.User, moderator: Optional[discord.Member] = None, reason: Optional[str] = None):
        """Логирование разбана участника"""
        try:
            log_channel = await self.get_log_channel(guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🔓 Участник разбанен",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Разбаненный участник",
                value=f"{user.mention}\n`{user}`\n`ID: {user.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            if reason:
                embed.add_field(name="Причина", value=reason[:1024], inline=False)
            
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"ID участника: {user.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования разбана: {e}")
    
    async def log_member_kick(self, member: discord.Member, moderator: Optional[discord.Member] = None, reason: Optional[str] = None):
        """Логирование кика участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="👢 Участник изгнан",
                color=discord.Color.orange(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Изгнанный участник",
                value=f"{member.mention}\n`{member}`\n`ID: {member.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            if member.joined_at:
                embed.add_field(
                    name="Был на сервере",
                    value=f"<t:{int(member.joined_at.timestamp())}:R>",
                    inline=True
                )
            
            if reason:
                embed.add_field(name="Причина", value=reason[:1024], inline=False)
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования кика: {e}")
    
    async def log_member_unmute(self, member: discord.Member, moderator: Optional[discord.Member] = None, reason: Optional[str] = None):
        """Логирование размьюта участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🔊 Участник размьючен",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            if reason:
                embed.add_field(name="Причина", value=reason[:1024], inline=False)
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования размьюта: {e}")
    
    async def log_member_nick_change(self, member: discord.Member, before_nick: Optional[str], after_nick: Optional[str], moderator: Optional[discord.Member] = None):
        """Логирование изменения никнейма участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="✏️ Никнейм изменен",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`",
                inline=True
            )
            
            if moderator and moderator.id != member.id:
                embed.add_field(
                    name="Изменил",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            else:
                embed.add_field(
                    name="Изменил",
                    value="Сам участник",
                    inline=True
                )
            
            embed.add_field(
                name="Было",
                value=before_nick or "*Нет никнейма*",
                inline=False
            )
            
            embed.add_field(
                name="Стало",
                value=after_nick or "*Нет никнейма*",
                inline=False
            )
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования изменения никнейма: {e}")
    
    async def log_member_roles_update(self, member: discord.Member, added_roles: List[discord.Role] = None, removed_roles: List[discord.Role] = None, moderator: Optional[discord.Member] = None):
        """Логирование изменения ролей участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🎭 Роли участника изменены",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`",
                inline=True
            )
            
            if moderator and moderator.id != member.id:
                embed.add_field(
                    name="Изменил",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            else:
                embed.add_field(
                    name="Изменил",
                    value="Автоматически",
                    inline=True
                )
            
            if added_roles:
                roles_text = ", ".join([role.mention for role in added_roles])
                embed.add_field(name="➕ Добавлены роли", value=roles_text[:1024], inline=False)
            
            if removed_roles:
                roles_text = ", ".join([role.mention for role in removed_roles])
                embed.add_field(name="➖ Убраны роли", value=roles_text[:1024], inline=False)
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования изменения ролей: {e}")
    
    async def log_member_join(self, member: discord.Member):
        """Логирование присоединения участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="📥 Присоединился новый участник",
                description=f"{member.mention} присоединился к серверу",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`\n`ID: {member.id}`",
                inline=True
            )
            
            embed.add_field(
                name="Аккаунт создан",
                value=f"<t:{int(member.created_at.timestamp())}:R>",
                inline=True
            )
            
            embed.add_field(
                name="Участников на сервере",
                value=str(member.guild.member_count),
                inline=True
            )
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования присоединения: {e}")
    
    async def log_member_leave(self, member: discord.Member):
        """Логирование выхода участника"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="📤 Участник покинул сервер",
                description=f"{member.mention} покинул сервер",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`\n`ID: {member.id}`",
                inline=True
            )
            
            if member.joined_at:
                embed.add_field(
                    name="Был на сервере",
                    value=f"<t:{int(member.joined_at.timestamp())}:R>",
                    inline=True
                )
            
            embed.add_field(
                name="Участников на сервере",
                value=str(member.guild.member_count),
                inline=True
            )
            
            # Показать роли которые были у участника
            if member.roles[1:]:  # Исключаем @everyone
                roles_text = ", ".join([role.mention for role in member.roles[1:][:10]])
                embed.add_field(name="Роли", value=roles_text, inline=False)
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования выхода: {e}")
    
    async def log_channel_create(self, channel: discord.abc.GuildChannel, moderator: Optional[discord.Member] = None):
        """Логирование создания канала"""
        try:
            log_channel = await self.get_log_channel(channel.guild.id)
            if not log_channel:
                return
            
            channel_types = {
                discord.TextChannel: ("💬", "Текстовый канал"),
                discord.VoiceChannel: ("🔊", "Голосовой канал"),
                discord.CategoryChannel: ("📁", "Категория"),
                discord.ForumChannel: ("💭", "Форум"),
                discord.StageChannel: ("🎙️", "Трибуна")
            }
            
            emoji, type_name = channel_types.get(type(channel), ("📋", "Канал"))
            
            embed = discord.Embed(
                title=f"{emoji} Создан {type_name.lower()}",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            if moderator:
                embed.add_field(
                    name="Создал",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            embed.add_field(
                name="Канал",
                value=f"{channel.mention if hasattr(channel, 'mention') else channel.name}\n`{channel.name}`\n`ID: {channel.id}`",
                inline=True
            )
            
            if isinstance(channel, (discord.TextChannel, discord.VoiceChannel)):
                if channel.category:
                    embed.add_field(
                        name="Категория",
                        value=channel.category.name,
                        inline=True
                    )
            
            embed.set_footer(text=f"ID канала: {channel.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования создания канала: {e}")
    
    async def log_channel_delete(self, channel: discord.abc.GuildChannel, moderator: Optional[discord.Member] = None):
        """Логирование удаления канала"""
        try:
            log_channel = await self.get_log_channel(channel.guild.id)
            if not log_channel:
                return
            
            channel_types = {
                discord.TextChannel: ("💬", "Текстовый канал"),
                discord.VoiceChannel: ("🔊", "Голосовой канал"),
                discord.CategoryChannel: ("📁", "Категория"),
                discord.ForumChannel: ("💭", "Форум"),
                discord.StageChannel: ("🎙️", "Трибуна")
            }
            
            emoji, type_name = channel_types.get(type(channel), ("📋", "Канал"))
            
            embed = discord.Embed(
                title=f"🗑️ Удален {type_name.lower()}",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            if moderator:
                embed.add_field(
                    name="Удалил",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            embed.add_field(
                name="Название канала",
                value=f"**#{channel.name}**\n`ID: {channel.id}`",
                inline=True
            )
            
            embed.add_field(
                name="Тип",
                value=type_name,
                inline=True
            )
            
            embed.set_footer(text=f"ID канала: {channel.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования удаления канала: {e}")
    
    async def log_role_create(self, role: discord.Role, moderator: Optional[discord.Member] = None):
        """Логирование создания роли"""
        try:
            log_channel = await self.get_log_channel(role.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🆕 Создана роль",
                color=role.color if role.color != discord.Color.default() else discord.Color.green(),
                timestamp=datetime.now()
            )
            
            if moderator:
                embed.add_field(
                    name="Создал",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            embed.add_field(
                name="Роль",
                value=f"{role.mention}\n`{role.name}`\n`ID: {role.id}`",
                inline=True
            )
            
            embed.add_field(
                name="Цвет",
                value=f"`{role.color}`" if role.color != discord.Color.default() else "По умолчанию",
                inline=True
            )
            
            embed.add_field(
                name="Упоминаемая",
                value="Да" if role.mentionable else "Нет",
                inline=True
            )
            
            embed.add_field(
                name="Отображается отдельно",
                value="Да" if role.hoist else "Нет",
                inline=True
            )
            
            embed.set_footer(text=f"ID роли: {role.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования создания роли: {e}")
    
    async def log_role_delete(self, role: discord.Role, moderator: Optional[discord.Member] = None):
        """Логирование удаления роли"""
        try:
            log_channel = await self.get_log_channel(role.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🗑️ Роль удалена",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Роль",
                value=f"`{role.name}`\n`ID: {role.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            embed.add_field(
                name="Цвет",
                value=f"`{role.color}`",
                inline=True
            )
            
            if role.permissions.administrator:
                embed.add_field(
                    name="⚠️ Внимание",
                    value="Роль имела права администратора!",
                    inline=False
                )
            
            embed.set_footer(text=f"ID роли: {role.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования удаления роли: {e}")
    
    async def log_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel, moderator: Optional[discord.Member] = None):
        """Логирование обновления канала"""
        try:
            log_channel = await self.get_log_channel(after.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="✏️ Канал обновлён",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            channel_mention = getattr(after, 'mention', f'`{after.name}`')
            embed.add_field(
                name="Канал",
                value=f"{channel_mention}\n`{after.name}`\n`ID: {after.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            # Показать изменения
            changes = []
            if before.name != after.name:
                changes.append(f"**Имя:** `{before.name}` → `{after.name}`")
            
            if hasattr(before, 'topic') and hasattr(after, 'topic') and before.topic != after.topic:
                before_topic = before.topic[:50] if before.topic else "Нет"
                after_topic = after.topic[:50] if after.topic else "Нет"
                changes.append(f"**Тема:** `{before_topic}` → `{after_topic}`")
            
            if hasattr(before, 'slowmode_delay') and hasattr(after, 'slowmode_delay') and before.slowmode_delay != after.slowmode_delay:
                changes.append(f"**Медленный режим:** `{before.slowmode_delay}с` → `{after.slowmode_delay}с`")
            
            if hasattr(before, 'nsfw') and hasattr(after, 'nsfw') and before.nsfw != after.nsfw:
                changes.append(f"**NSFW:** `{before.nsfw}` → `{after.nsfw}`")
            
            if changes:
                embed.add_field(
                    name="Изменения",
                    value="\n".join(changes[:5]),
                    inline=False
                )
            
            embed.set_footer(text=f"ID канала: {after.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования обновления канала: {e}")
    
    async def log_role_update(self, before: discord.Role, after: discord.Role, moderator: Optional[discord.Member] = None):
        """Логирование обновления роли"""
        try:
            log_channel = await self.get_log_channel(after.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="✏️ Роль обновлена",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Роль",
                value=f"{after.mention}\n`{after.name}`\n`ID: {after.id}`",
                inline=True
            )
            
            if moderator:
                embed.add_field(
                    name="Модератор",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            # Показать изменения
            changes = []
            if before.name != after.name:
                changes.append(f"**Имя:** `{before.name}` → `{after.name}`")
            
            if before.color != after.color:
                changes.append(f"**Цвет:** `{before.color}` → `{after.color}`")
            
            if before.hoist != after.hoist:
                changes.append(f"**Отображать отдельно:** `{before.hoist}` → `{after.hoist}`")
            
            if before.mentionable != after.mentionable:
                changes.append(f"**Упоминаемая:** `{before.mentionable}` → `{after.mentionable}`")
            
            if before.permissions != after.permissions:
                changes.append("**Права:** Изменены")
                
                # Опасные изменения прав
                dangerous_perms = ['administrator', 'manage_guild', 'manage_roles', 'manage_channels', 'kick_members', 'ban_members']
                for perm in dangerous_perms:
                    before_val = getattr(before.permissions, perm, False)
                    after_val = getattr(after.permissions, perm, False)
                    if before_val != after_val:
                        status = "✅ Добавлено" if after_val else "❌ Удалено"
                        perm_name = perm.replace('_', ' ').title()
                        changes.append(f"  {status}: `{perm_name}`")
            
            if changes:
                embed.add_field(
                    name="Изменения",
                    value="\n".join(changes[:10]),
                    inline=False
                )
            
            embed.set_footer(text=f"ID роли: {after.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования обновления роли: {e}")
    
    async def log_voice_join(self, member: discord.Member, channel: discord.VoiceChannel):
        """Логирование входа в голосовой канал"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🔊 Вход в голосовой канал",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`",
                inline=True
            )
            
            embed.add_field(
                name="Канал",
                value=f"{channel.mention}\n`{channel.name}`",
                inline=True
            )
            
            embed.add_field(
                name="Участников в канале",
                value=str(len(channel.members)),
                inline=True
            )
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования входа в голосовой: {e}")
    
    async def log_voice_leave(self, member: discord.Member, channel: discord.VoiceChannel):
        """Логирование выхода из голосового канала"""
        try:
            log_channel = await self.get_log_channel(member.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🔇 Выход из голосового канала",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            
            embed.add_field(
                name="Участник",
                value=f"{member.mention}\n`{member}`",
                inline=True
            )
            
            embed.add_field(
                name="Канал",
                value=f"**{channel.name}**\n`{channel.id}`",
                inline=True
            )
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_footer(text=f"ID участника: {member.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования выхода из голосового: {e}")
    
    async def log_bot_add(self, bot: discord.Member, moderator: Optional[discord.Member] = None):
        """Логирование добавления бота"""
        try:
            log_channel = await self.get_log_channel(bot.guild.id)
            if not log_channel:
                return
            
            embed = discord.Embed(
                title="🤖 Бот добавлен на сервер",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            if moderator:
                embed.add_field(
                    name="Добавил",
                    value=f"{moderator.mention}\n`{moderator}`",
                    inline=True
                )
            
            embed.add_field(
                name="Бот",
                value=f"{bot.mention}\n`{bot}`\n`ID: {bot.id}`",
                inline=True
            )
            
            embed.add_field(
                name="Создан",
                value=f"<t:{int(bot.created_at.timestamp())}:R>",
                inline=True
            )
            
            embed.set_thumbnail(url=bot.display_avatar.url)
            embed.set_footer(text=f"ID бота: {bot.id}")
            
            await log_channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Ошибка логирования добавления бота: {e}")
    

    def _create_server_update_embed(self, guild: discord.Guild, changes: Dict[str, Any], actor: discord.Member = None) -> discord.Embed:
        """Обновление сервера"""
        embed = discord.Embed(
            title="🔧 Обновление сервера",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        for key, value in changes.items():
            embed.add_field(name=key, value=str(value)[:1024], inline=False)
        
        embed.set_footer(text=f"Сервер ID: {guild.id}")
        return embed
    
    def _create_channel_create_embed(self, channel: discord.abc.GuildChannel, actor: discord.Member = None) -> discord.Embed:
        """Создание канала"""
        channel_types = {
            discord.TextChannel: ("💬", "Текстовый канал"),
            discord.VoiceChannel: ("🔊", "Голосовой канал"),
            discord.CategoryChannel: ("📁", "Категория"),
            discord.ForumChannel: ("💭", "Форум"),
            discord.StageChannel: ("🎙️", "Трибуна")
        }
        
        emoji, type_name = channel_types.get(type(channel), ("📋", "Канал"))
        
        embed = discord.Embed(
            title=f"{emoji} Создание канала",
            description=f"**{type_name}** создан",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{channel.mention if hasattr(channel, 'mention') else channel.name}\n`{channel.id}`", inline=True)
        embed.add_field(name="Тип", value=type_name, inline=True)
        
        if isinstance(channel, discord.TextChannel):
            embed.add_field(name="Категория", value=channel.category.name if channel.category else "Нет", inline=True)
            embed.add_field(name="NSFW", value="Да" if channel.nsfw else "Нет", inline=True)
        
        embed.set_footer(text=f"Канал ID: {channel.id}")
        return embed
    
    def _create_channel_update_embed(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel, changes: Dict[str, Any], actor: discord.Member = None) -> discord.Embed:
        """Обновление канала"""
        embed = discord.Embed(
            title="✏️ Обновление канала",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{after.mention if hasattr(after, 'mention') else after.name}\n`{after.id}`", inline=True)
        
        for key, (old_val, new_val) in changes.items():
            embed.add_field(
                name=f"Изменение: {key}",
                value=f"**До:** {old_val}\n**После:** {new_val}",
                inline=False
            )
        
        embed.set_footer(text=f"Канал ID: {after.id}")
        return embed
    
    def _create_channel_delete_embed(self, channel: discord.abc.GuildChannel, actor: discord.Member = None) -> discord.Embed:
        """Удаление канала"""
        channel_types = {
            discord.TextChannel: ("💬", "Текстовый канал"),
            discord.VoiceChannel: ("🔊", "Голосовой канал"),
            discord.CategoryChannel: ("📁", "Категория"),
            discord.ForumChannel: ("💭", "Форум"),
            discord.StageChannel: ("🎙️", "Трибуна")
        }
        
        emoji, type_name = channel_types.get(type(channel), ("📋", "Канал"))
        
        embed = discord.Embed(
            title=f"🗑️ Удаление канала",
            description=f"**{type_name}** удален",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название канала", value=f"#{channel.name}\n`{channel.id}`", inline=True)
        embed.add_field(name="Тип", value=type_name, inline=True)
        
        embed.set_footer(text=f"Канал ID: {channel.id}")
        return embed
    
    def _create_channel_overwrite_create_embed(self, channel: discord.abc.GuildChannel, target, overwrite: discord.PermissionOverwrite, actor: discord.Member = None) -> discord.Embed:
        """Создание прав канала"""
        embed = discord.Embed(
            title="➕ Создание прав канала",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{channel.mention if hasattr(channel, 'mention') else channel.name}\n`{channel.id}`", inline=True)
        
        target_type = "Роль" if isinstance(target, discord.Role) else "Участник"
        target_mention = target.mention
        embed.add_field(name=f"Цель ({target_type})", value=f"{target_mention}\n`{target.id}`", inline=True)
        
        # Показать измененные права
        allowed = [perm for perm, value in overwrite if value is True]
        denied = [perm for perm, value in overwrite if value is False]
        
        if allowed:
            embed.add_field(name="✅ Разрешено", value=", ".join(allowed)[:1024], inline=False)
        if denied:
            embed.add_field(name="❌ Запрещено", value=", ".join(denied)[:1024], inline=False)
        
        embed.set_footer(text=f"Канал ID: {channel.id}")
        return embed
    
    def _create_channel_overwrite_update_embed(self, channel: discord.abc.GuildChannel, target, before: discord.PermissionOverwrite, after: discord.PermissionOverwrite, actor: discord.Member = None) -> discord.Embed:
        """Изменение прав канала"""
        embed = discord.Embed(
            title="✏️ Изменение прав канала",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{channel.mention if hasattr(channel, 'mention') else channel.name}\n`{channel.id}`", inline=True)
        
        target_type = "Роль" if isinstance(target, discord.Role) else "Участник"
        target_mention = target.mention
        embed.add_field(name=f"Цель ({target_type})", value=f"{target_mention}\n`{target.id}`", inline=True)
        
        # Показать изменения
        changes = []
        for perm, value in after:
            before_val = getattr(before, perm)
            if before_val != value:
                status = "✅" if value is True else "❌" if value is False else "⚪"
                changes.append(f"{status} {perm}")
        
        if changes:
            embed.add_field(name="Изменения", value="\n".join(changes)[:1024], inline=False)
        
        embed.set_footer(text=f"Канал ID: {after.id}")
        return embed
    
    def _create_channel_overwrite_delete_embed(self, channel: discord.abc.GuildChannel, target, actor: discord.Member = None) -> discord.Embed:
        """Удаление прав канала"""
        embed = discord.Embed(
            title="➖ Удаление прав канала",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{channel.mention if hasattr(channel, 'mention') else channel.name}\n`{channel.id}`", inline=True)
        
        target_type = "Роль" if isinstance(target, discord.Role) else "Участник"
        target_mention = target.mention if hasattr(target, 'mention') else str(target)
        embed.add_field(name=f"Цель ({target_type})", value=f"{target_mention}\n`{target.id if hasattr(target, 'id') else 'N/A'}`", inline=True)
        
        embed.set_footer(text=f"Канал ID: {channel.id}")
        return embed
    
    def _create_member_kick_embed(self, member: discord.Member, actor: discord.Member = None, reason: str = None) -> discord.Embed:
        """Удаление участника (кик)"""
        embed = discord.Embed(
            title="👢 Удаление участника",
            description=f"{member.mention} был выгнан с сервера",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{member.mention}\n`{member.name}`\n`{member.id}`", inline=True)
        
        if member.joined_at:
            embed.add_field(name="Был на сервере", value=f"<t:{int(member.joined_at.timestamp())}:R>", inline=True)
        
        if reason:
            embed.add_field(name="Причина", value=reason[:1024], inline=False)
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {member.id}")
        return embed
    
    def _create_member_prune_embed(self, count: int, days: int, actor: discord.Member = None) -> discord.Embed:
        """Чистка участников"""
        embed = discord.Embed(
            title="🧹 Чистка участников",
            description=f"Удалено **{count}** неактивных участников",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Период неактивности", value=f"{days} дней", inline=True)
        embed.add_field(name="Удалено участников", value=str(count), inline=True)
        
        embed.set_footer(text=f"Время: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
        return embed
    
    def _create_member_ban_embed(self, user: discord.User, actor: discord.Member = None, reason: str = None) -> discord.Embed:
        """Бан участника"""
        embed = discord.Embed(
            title="🔨 Бан участника",
            description=f"{user.mention} был забанен",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{user.mention}\n`{user.name}`\n`{user.id}`", inline=True)
        
        if reason:
            embed.add_field(name="Причина", value=reason[:1024], inline=False)
        
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {user.id}")
        return embed
    
    def _create_member_unban_embed(self, user: discord.User, actor: discord.Member = None, reason: str = None) -> discord.Embed:
        """Возврат участника из бана"""
        embed = discord.Embed(
            title="🔓 Возврат участника из бана",
            description=f"{user.mention} был разбанен",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{user.mention}\n`{user.name}`\n`{user.id}`", inline=True)
        
        if reason:
            embed.add_field(name="Причина", value=reason[:1024], inline=False)
        
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {user.id}")
        return embed
    
    def _create_member_update_embed(self, before: discord.Member, after: discord.Member, changes: Dict[str, Any], actor: discord.Member = None) -> discord.Embed:
        """Обновление участника"""
        embed = discord.Embed(
            title="✏️ Обновление участника",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor and actor.id != after.id:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{after.mention}\n`{after.name}`\n`{after.id}`", inline=True)
        
        for key, (old_val, new_val) in changes.items():
            embed.add_field(
                name=f"Изменение: {key}",
                value=f"**До:** {old_val}\n**После:** {new_val}",
                inline=False
            )
        
        embed.set_thumbnail(url=after.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {after.id}")
        return embed
    
    def _create_member_role_update_embed(self, member: discord.Member, added_roles: List[discord.Role] = None, removed_roles: List[discord.Role] = None, actor: discord.Member = None, reason: str = None) -> discord.Embed:
        """Изменение ролей участника"""
        embed = discord.Embed(
            title="🎭 Изменение ролей участника",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor and actor.id != member.id:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{member.mention}\n`{member.name}`\n`{member.id}`", inline=True)
        
        if added_roles:
            roles_text = ", ".join([role.mention for role in added_roles])
            embed.add_field(name="➕ Добавлены роли", value=roles_text[:1024], inline=False)
        
        if removed_roles:
            roles_text = ", ".join([role.mention for role in removed_roles])
            embed.add_field(name="➖ Убраны роли", value=roles_text[:1024], inline=False)
        
        if reason:
            embed.add_field(name="Причина", value=reason[:1024], inline=False)
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {member.id}")
        return embed
    
    def _create_member_move_embed(self, member: discord.Member, from_channel: discord.VoiceChannel, to_channel: discord.VoiceChannel, actor: discord.Member = None) -> discord.Embed:
        """Переместить участника"""
        embed = discord.Embed(
            title="🔀 Перемещение участника",
            description=f"{member.mention} был перемещен между голосовыми каналами",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor and actor.id != member.id:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{member.mention}\n`{member.id}`", inline=True)
        embed.add_field(name="Из канала", value=f"{from_channel.mention}\n`{from_channel.name}`", inline=False)
        embed.add_field(name="В канал", value=f"{to_channel.mention}\n`{to_channel.name}`", inline=False)
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {member.id}")
        return embed
    
    def _create_member_disconnect_embed(self, member: discord.Member, channel: discord.VoiceChannel, actor: discord.Member = None) -> discord.Embed:
        """Отключить участника"""
        embed = discord.Embed(
            title="🔇 Отключение участника",
            description=f"{member.mention} был отключен от голосового канала",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor and actor.id != member.id:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Участник", value=f"{member.mention}\n`{member.id}`", inline=True)
        embed.add_field(name="Канал", value=f"{channel.mention}\n`{channel.name}`", inline=True)
        
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Участник ID: {member.id}")
        return embed
    
    def _create_bot_add_embed(self, bot: discord.Member, actor: discord.Member = None) -> discord.Embed:
        """Добавить бота"""
        embed = discord.Embed(
            title="🤖 Добавление бота",
            description=f"Бот {bot.mention} был добавлен на сервер",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Добавил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Бот", value=f"{bot.mention}\n`{bot.name}`\n`{bot.id}`", inline=True)
        embed.add_field(name="Создан", value=f"<t:{int(bot.created_at.timestamp())}:R>", inline=True)
        
        embed.set_thumbnail(url=bot.display_avatar.url)
        embed.set_footer(text=f"Бот ID: {bot.id}")
        return embed
    
    def _create_role_create_embed(self, role: discord.Role, actor: discord.Member = None) -> discord.Embed:
        """Создание роли"""
        embed = discord.Embed(
            title="🆕 Создание роли",
            description=f"Роль {role.mention} была создана",
            color=role.color if role.color != discord.Color.default() else discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Роль", value=f"{role.mention}\n`{role.name}`\n`{role.id}`", inline=True)
        embed.add_field(name="Цвет", value=f"`{role.color}`", inline=True)
        embed.add_field(name="Позиция", value=str(role.position), inline=True)
        embed.add_field(name="Упоминаемая", value="Да" if role.mentionable else "Нет", inline=True)
        embed.add_field(name="Отображается отдельно", value="Да" if role.hoist else "Нет", inline=True)
        
        embed.set_footer(text=f"Роль ID: {role.id}")
        return embed
    
    def _create_role_update_embed(self, before: discord.Role, after: discord.Role, changes: Dict[str, Any], actor: discord.Member = None) -> discord.Embed:
        """Обновление роли"""
        embed = discord.Embed(
            title="✏️ Обновление роли",
            color=after.color if after.color != discord.Color.default() else discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Роль", value=f"{after.mention}\n`{after.id}`", inline=True)
        
        for key, (old_val, new_val) in changes.items():
            embed.add_field(
                name=f"Изменение: {key}",
                value=f"**До:** {old_val}\n**После:** {new_val}",
                inline=False
            )
        
        embed.set_footer(text=f"Роль ID: {after.id}")
        return embed
    
    def _create_role_delete_embed(self, role: discord.Role, actor: discord.Member = None) -> discord.Embed:
        """Удаление роли"""
        embed = discord.Embed(
            title="🗑️ Удаление роли",
            description=f"Роль **{role.name}** была удалена",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название роли", value=f"{role.name}\n`{role.id}`", inline=True)
        embed.add_field(name="Цвет", value=f"`{role.color}`", inline=True)
        
        embed.set_footer(text=f"Роль ID: {role.id}")
        return embed
    
    def _create_message_delete_embed(self, message: discord.Message, actor: discord.Member = None) -> discord.Embed:
        """Удаление сообщения"""
        embed = discord.Embed(
            title="🗑️ Удаление сообщения",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        if actor and actor.id != message.author.id:
            embed.add_field(name="Удалил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Автор", value=f"{message.author.mention}\n`{message.author.name}`\n`{message.author.id}`", inline=True)
        embed.add_field(name="Канал", value=f"{message.channel.mention}\n`{message.channel.name}`", inline=True)
        
        content = message.content[:1024] if message.content else "*[Нет текста]*"
        embed.add_field(name="Содержание", value=content, inline=False)
        
        if message.attachments:
            attachments_text = "\n".join([f"[{att.filename}]({att.url})" for att in message.attachments[:5]])
            embed.add_field(name=f"Вложения ({len(message.attachments)})", value=attachments_text[:1024], inline=False)
        
        embed.set_footer(text=f"Сообщение ID: {message.id} | Автор ID: {message.author.id}")
        return embed
    
    def _create_message_bulk_delete_embed(self, count: int, channel: discord.TextChannel, actor: discord.Member = None) -> discord.Embed:
        """Удалить несколько сообщений"""
        embed = discord.Embed(
            title="🧹 Удаление нескольких сообщений",
            description=f"Удалено **{count}** сообщений",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Канал", value=f"{channel.mention}\n`{channel.name}`", inline=True)
        embed.add_field(name="Количество", value=str(count), inline=True)
        
        embed.set_footer(text=f"Канал ID: {channel.id}")
        return embed
    
    def _create_message_pin_embed(self, message: discord.Message, actor: discord.Member = None) -> discord.Embed:
        """Закрепить сообщение"""
        embed = discord.Embed(
            title="📌 Закрепление сообщения",
            description=f"[Перейти к сообщению]({message.jump_url})",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Закрепил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Автор сообщения", value=f"{message.author.mention}\n`{message.author.id}`", inline=True)
        embed.add_field(name="Канал", value=f"{message.channel.mention}", inline=True)
        
        content = message.content[:512] if message.content else "*[Нет текста]*"
        embed.add_field(name="Содержание", value=content, inline=False)
        
        embed.set_footer(text=f"Сообщение ID: {message.id}")
        return embed
    
    def _create_message_unpin_embed(self, message: discord.Message, actor: discord.Member = None) -> discord.Embed:
        """Открепить сообщение"""
        embed = discord.Embed(
            title="📍 Открепление сообщения",
            description=f"[Перейти к сообщению]({message.jump_url})",
            color=discord.Color.greyple(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Открепил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Автор сообщения", value=f"{message.author.mention}\n`{message.author.id}`", inline=True)
        embed.add_field(name="Канал", value=f"{message.channel.mention}", inline=True)
        
        embed.set_footer(text=f"Сообщение ID: {message.id}")
        return embed
    
    def _create_emoji_create_embed(self, emoji: discord.Emoji, actor: discord.Member = None) -> discord.Embed:
        """Создание эмодзи"""
        embed = discord.Embed(
            title="😀 Создание эмодзи",
            description=f"Эмодзи {emoji} **{emoji.name}** был создан",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=f"`:{emoji.name}:`", inline=True)
        embed.add_field(name="ID", value=f"`{emoji.id}`", inline=True)
        embed.add_field(name="Анимированный", value="Да" if emoji.animated else "Нет", inline=True)
        
        embed.set_thumbnail(url=emoji.url)
        embed.set_footer(text=f"Эмодзи ID: {emoji.id}")
        return embed
    
    def _create_emoji_update_embed(self, before: discord.Emoji, after: discord.Emoji, actor: discord.Member = None) -> discord.Embed:
        """Изменение эмодзи"""
        embed = discord.Embed(
            title="✏️ Изменение эмодзи",
            description=f"Эмодзи {after} был изменен",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        if before.name != after.name:
            embed.add_field(
                name="Название",
                value=f"**До:** `:{before.name}:`\n**После:** `:{after.name}:`",
                inline=False
            )
        
        embed.set_thumbnail(url=after.url)
        embed.set_footer(text=f"Эмодзи ID: {after.id}")
        return embed
    
    def _create_emoji_delete_embed(self, emoji: discord.Emoji, actor: discord.Member = None) -> discord.Embed:
        """Удаление эмодзи"""
        embed = discord.Embed(
            title="🗑️ Удаление эмодзи",
            description=f"Эмодзи **{emoji.name}** был удален",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=f"`:{emoji.name}:`", inline=True)
        embed.add_field(name="ID", value=f"`{emoji.id}`", inline=True)
        
        embed.set_thumbnail(url=emoji.url)
        embed.set_footer(text=f"Эмодзи ID: {emoji.id}")
        return embed
    
    def _create_invite_create_embed(self, invite: discord.Invite, actor: discord.Member = None) -> discord.Embed:
        """Создание приглашения"""
        embed = discord.Embed(
            title="🔗 Создание приглашения",
            description=f"Создано приглашение: `{invite.code}`",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Создатель", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Код", value=f"`{invite.code}`", inline=True)
        embed.add_field(name="Канал", value=f"{invite.channel.mention if hasattr(invite.channel, 'mention') else invite.channel}", inline=True)
        
        if invite.max_uses:
            embed.add_field(name="Макс. использований", value=str(invite.max_uses), inline=True)
        if invite.max_age:
            embed.add_field(name="Истекает через", value=f"{invite.max_age // 3600}ч", inline=True)
        
        embed.set_footer(text=f"Код: {invite.code}")
        return embed
    
    def _create_invite_delete_embed(self, invite: discord.Invite, actor: discord.Member = None) -> discord.Embed:
        """Удаление приглашения"""
        embed = discord.Embed(
            title="🗑️ Удаление приглашения",
            description=f"Удалено приглашение: `{invite.code}`",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Удалил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Код", value=f"`{invite.code}`", inline=True)
        embed.add_field(name="Канал", value=f"{invite.channel.mention if hasattr(invite.channel, 'mention') else invite.channel}", inline=True)
        
        if invite.uses:
            embed.add_field(name="Использовано раз", value=str(invite.uses), inline=True)
        
        embed.set_footer(text=f"Код: {invite.code}")
        return embed
    
    def _create_webhook_create_embed(self, webhook: discord.Webhook, actor: discord.Member = None) -> discord.Embed:
        """Создание вебхука"""
        embed = discord.Embed(
            title="🔗 Создание вебхука",
            description=f"Вебхук **{webhook.name}** был создан",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Создатель", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=webhook.name, inline=True)
        embed.add_field(name="ID", value=f"`{webhook.id}`", inline=True)
        
        if webhook.channel:
            embed.add_field(name="Канал", value=f"{webhook.channel.mention}", inline=True)
        
        if webhook.avatar:
            embed.set_thumbnail(url=webhook.avatar.url)
        
        embed.set_footer(text=f"Вебхук ID: {webhook.id}")
        return embed
    
    def _create_webhook_update_embed(self, before: discord.Webhook, after: discord.Webhook, actor: discord.Member = None) -> discord.Embed:
        """Изменение вебхука"""
        embed = discord.Embed(
            title="✏️ Изменение вебхука",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Вебхук", value=f"{after.name}\n`{after.id}`", inline=True)
        
        if before.name != after.name:
            embed.add_field(
                name="Название",
                value=f"**До:** {before.name}\n**После:** {after.name}",
                inline=False
            )
        
        if before.channel != after.channel:
            embed.add_field(
                name="Канал",
                value=f"**До:** {before.channel.mention if before.channel else 'N/A'}\n**После:** {after.channel.mention if after.channel else 'N/A'}",
                inline=False
            )
        
        embed.set_footer(text=f"Вебхук ID: {after.id}")
        return embed
    
    def _create_webhook_delete_embed(self, webhook: discord.Webhook, actor: discord.Member = None) -> discord.Embed:
        """Удаление вебхука"""
        embed = discord.Embed(
            title="🗑️ Удаление вебхука",
            description=f"Вебхук **{webhook.name}** был удален",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Удалил", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=webhook.name, inline=True)
        embed.add_field(name="ID", value=f"`{webhook.id}`", inline=True)
        
        embed.set_footer(text=f"Вебхук ID: {webhook.id}")
        return embed
    
    def _create_stage_create_embed(self, stage: discord.StageInstance, actor: discord.Member = None) -> discord.Embed:
        """Открыть трибуну"""
        embed = discord.Embed(
            title="🎙️ Открытие трибуны",
            description=f"Трибуна **{stage.topic}** была открыта",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Тема", value=stage.topic, inline=False)
        embed.add_field(name="Канал", value=f"{stage.channel.mention}", inline=True)
        embed.add_field(name="Приватность", value="Только участники гильдии" if stage.privacy_level == discord.StagePrivacyLevel.guild_only else "Публичная", inline=True)
        
        embed.set_footer(text=f"Трибуна ID: {stage.id}")
        return embed
    
    def _create_stage_update_embed(self, before: discord.StageInstance, after: discord.StageInstance, actor: discord.Member = None) -> discord.Embed:
        """Обновить трибуну"""
        embed = discord.Embed(
            title="✏️ Обновление трибуны",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        if before.topic != after.topic:
            embed.add_field(
                name="Тема",
                value=f"**До:** {before.topic}\n**После:** {after.topic}",
                inline=False
            )
        
        embed.add_field(name="Канал", value=f"{after.channel.mention}", inline=True)
        
        embed.set_footer(text=f"Трибуна ID: {after.id}")
        return embed
    
    def _create_stage_delete_embed(self, stage: discord.StageInstance, actor: discord.Member = None) -> discord.Embed:
        """Закрыть трибуну"""
        embed = discord.Embed(
            title="🔇 Закрытие трибуны",
            description=f"Трибуна **{stage.topic}** была закрыта",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Тема", value=stage.topic, inline=False)
        embed.add_field(name="Канал", value=f"{stage.channel.mention}", inline=True)
        
        embed.set_footer(text=f"Трибуна ID: {stage.id}")
        return embed
    
    def _create_event_create_embed(self, event: discord.ScheduledEvent, actor: discord.Member = None) -> discord.Embed:
        """Создать событие"""
        embed = discord.Embed(
            title="📅 Создание события",
            description=f"Событие **{event.name}** было создано",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Создатель", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=event.name, inline=False)
        if event.description:
            embed.add_field(name="Описание", value=event.description[:512], inline=False)
        embed.add_field(name="Начало", value=f"<t:{int(event.start_time.timestamp())}:F>", inline=True)
        if event.end_time:
            embed.add_field(name="Конец", value=f"<t:{int(event.end_time.timestamp())}:F>", inline=True)
        
        if event.cover:
            embed.set_image(url=event.cover.url)
        
        embed.set_footer(text=f"Событие ID: {event.id}")
        return embed
    
    def _create_event_update_embed(self, before: discord.ScheduledEvent, after: discord.ScheduledEvent, actor: discord.Member = None) -> discord.Embed:
        """Обновить событие"""
        embed = discord.Embed(
            title="✏️ Обновление события",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Событие", value=after.name, inline=True)
        
        if before.name != after.name:
            embed.add_field(name="Название", value=f"**До:** {before.name}\n**После:** {after.name}", inline=False)
        
        if before.description != after.description:
            embed.add_field(name="Описание изменено", value="Да", inline=True)
        
        if before.start_time != after.start_time:
            embed.add_field(
                name="Начало",
                value=f"**До:** <t:{int(before.start_time.timestamp())}:F>\n**После:** <t:{int(after.start_time.timestamp())}:F>",
                inline=False
            )
        
        embed.set_footer(text=f"Событие ID: {after.id}")
        return embed
    
    def _create_event_delete_embed(self, event: discord.ScheduledEvent, actor: discord.Member = None) -> discord.Embed:
        """Отменить событие"""
        embed = discord.Embed(
            title="❌ Отмена события",
            description=f"Событие **{event.name}** было отменено",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        if actor:
            embed.add_field(name="Модератор", value=f"{actor.mention}\n`{actor.id}`", inline=True)
        
        embed.add_field(name="Название", value=event.name, inline=False)
        embed.add_field(name="Должно было начаться", value=f"<t:{int(event.start_time.timestamp())}:R>", inline=True)
        
        embed.set_footer(text=f"Событие ID: {event.id}")
        return embed
    
    async def send_log_embed(self, guild_id: int, embed: discord.Embed) -> bool:
        """Отправить красивый embed в канал логов"""
        try:
            log_channel_id = self.db.fetch_one(
                "SELECT log_channel_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if not log_channel_id or not log_channel_id[0]:
                return False
            
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return False
            
            channel = guild.get_channel(log_channel_id[0])
            if not channel:
                return False
            
            if not channel.permissions_for(guild.me).send_messages:
                return False
            
            await channel.send(embed=embed)
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при отправке лога: {e}")
            return False
    
    def _create_audit_embed(self, action_type: str, actor_id: int, target_id: Optional[int] = None, 
                           details: Dict[str, Any] = None, reason: str = None) -> discord.Embed:
        """Создать embed в стиле Discord аудита"""
        
        action_map = {
            "MUTE": ("🔇 Пользователь заглушен", discord.Color.blurple()),
            "UNMUTE": ("🔊 Пользователь разглушен", discord.Color.green()),
            "WARN": ("⚠️ Пользователю выдано предупреждение", discord.Color.yellow()),
            "KICK": ("👢 Пользователь выгнан", discord.Color.orange()),
            "BAN": ("🔨 Пользователь забанен", discord.Color.red()),
            "ROLE_ADDED": ("➕ Роль добавлена", discord.Color.blue()),
            "ROLE_REMOVED": ("➖ Роль удалена", discord.Color.purple()),
            "CHANNEL_CREATED": ("🆕 Канал создан", discord.Color.green()),
            "CHANNEL_DELETED": ("🗑️ Канал удален", discord.Color.red()),
            "ROLE_CREATED": ("🆕 Роль создана", discord.Color.green()),
            "ROLE_DELETED": ("🗑️ Роль удалена", discord.Color.red()),
            "MESSAGE_DELETED": ("🗑️ Сообщение удалено", discord.Color.orange()),
            "MESSAGE_EDITED": ("✏️ Сообщение отредактировано", discord.Color.blurple()),
            "DANGEROUS_ROLE": ("🚩 Обнаружена опасная роль", discord.Color.red()),
            "RAID_DETECTED": ("🔨 Обнаружен рейд", discord.Color.red()),
            "NUKE_DETECTED": ("💣 Обнаружена попытка нука", discord.Color.red()),
            "SPAM_DETECTED": ("📧 Обнаружен спам", discord.Color.orange()),
            "CLEANUP": ("🧹 Сообщения очищены", discord.Color.greyple()),
            "ROLE_PERMS_CHANGED": ("🔐 Права роли изменены", discord.Color.orange()),
            "MEMBER_JOIN": ("👋 Участник присоединился", discord.Color.green()),
            "MEMBER_LEAVE": ("👋 Участник покинул сервер", discord.Color.orange()),
            "MEMBER_KICKED": ("👢 Участник выгнан", discord.Color.red()),
            "VOICE_JOIN": ("🔊 Присоединился к голосовому каналу", discord.Color.blue()),
            "VOICE_LEAVE": ("🔇 Покинул голосовой канал", discord.Color.greyple()),
            "VOICE_MOVE": ("🔀 Переключился между голосовыми каналами", discord.Color.blurple()),
            "UNBAN": ("🔓 Пользователь разбанен", discord.Color.green()),
            "BOT_ADDED": ("🤖 Бот добавлен на сервер", discord.Color.green()),
            "BOT_REMOVED": ("👋 Бот покинул сервер", discord.Color.orange()),
            "NICKNAME_CHANGED": ("✏️ Никнейм изменен", discord.Color.blurple()),
            "LEVEL_UP": ("🎖️ Повышение уровня", discord.Color.gold()),
            "AUTO_ROLE_ASSIGNED": ("🎭 Автоматическая выдача ролей", discord.Color.blue()),
            "MESSAGES_PURGED": ("🧹 Массовая очистка сообщений", discord.Color.orange()),
        }
        
        action_data = action_map.get(action_type, (f"📋 {action_type}", discord.Color.blurple()))
        title, color = action_data
        
        # Создать основной embed
        embed = discord.Embed(
            title=title,
            color=color,
            timestamp=datetime.now()
        )
        
        # Добавить информацию об инициаторе (если не системное действие)
        if actor_id and actor_id != 0:
            embed.add_field(
                name="📍 Кто изменил",
                value=f"<@{actor_id}> ({actor_id})",
                inline=True
            )
        
        # Добавить цель действия если есть
        if target_id and target_id != 0:
            embed.add_field(
                name="🎯 Кого затронуло",
                value=f"<@{target_id}> ({target_id})",
                inline=True
            )
        
        # Добавить причину если есть
        if reason:
            embed.add_field(
                name="📝 Причина",
                value=reason[:1024],
                inline=False
            )
        
        # Добавить дополнительные детали
        if details:
            for key, value in details.items():
                if isinstance(value, (list, dict)):
                    value = str(value)
                
                # Обрезать длинные значения
                if len(str(value)) > 1024:
                    value = str(value)[:1020] + "..."
                
                embed.add_field(
                    name=f"📌 {key}",
                    value=value,
                    inline=False
                )
        
        # ID участника и время в подвале (как в Discord)
        embed.set_footer(
            text=f"ID участника: {target_id if target_id else 'N/A'} | {datetime.now().strftime('%d.%m.%Y %H:%M')}"
        )
        
        return embed
    
    async def log_action(self, guild_id: int, actor_id: int, action_type: str, 
                        target_id: Optional[int] = None, reason: str = None, 
                        details: Dict[str, Any] = None) -> bool:
        """Залогировать действие в БД и канал логов"""
        try:
            # Сохранить в БД
            self.db.execute(
                """INSERT INTO action_logs 
                   (guild_id, user_id, action_type, target_id, reason, created_at) 
                   VALUES (?, ?, ?, ?, ?, datetime('now'))""",
                (guild_id, actor_id, action_type, target_id, reason)
            )
            
            logger.info(f"✅ Действие залогировано: {action_type} на сервере {guild_id}")
            
            # Отправить в канал логов
            await self.log_to_channel(guild_id, action_type, actor_id, target_id, reason, details)
            
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании действия: {e}")
            return False
    
    async def log_to_channel(self, guild_id: int, action_type: str, actor_id: int,
                           target_id: Optional[int] = None, reason: str = None, 
                           details: Dict[str, Any] = None) -> bool:
        """Отправить красивый лог в канал логов"""
        try:
            # Получить ID канала логов
            log_channel_id = self.db.fetch_one(
                "SELECT log_channel_id FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            
            if not log_channel_id or not log_channel_id[0]:
                logger.debug(f"⚠️ Канал логов не установлен для сервера {guild_id}")
                return False
            
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return False
            
            channel = guild.get_channel(log_channel_id[0])
            if not channel:
                logger.error(f"❌ Канал логов {log_channel_id[0]} не найден")
                return False
            
            # Проверить права
            if not channel.permissions_for(guild.me).send_messages:
                logger.error(f"❌ Нет прав для отправки в канал логов {log_channel_id[0]}")
                return False
            
            # Создать и отправить embed
            embed = self._create_audit_embed(action_type, actor_id, target_id, details, reason)
            await channel.send(embed=embed)
            
            logger.debug(f"📤 Лог отправлен в канал {channel.name}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при отправке лога в канал: {e}")
            return False
    
    async def get_logs(self, guild_id: int, action_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Получить логи для гильдии"""
        try:
            if action_type:
                results = self.db.fetch_all(
                    """SELECT id, guild_id, user_id, action_type, target_id, reason, created_at 
                       FROM action_logs 
                       WHERE guild_id = ? AND action_type = ? 
                       ORDER BY created_at DESC LIMIT ?""",
                    (guild_id, action_type, limit)
                )
            else:
                results = self.db.fetch_all(
                    """SELECT id, guild_id, user_id, action_type, target_id, reason, created_at 
                       FROM action_logs 
                       WHERE guild_id = ? 
                       ORDER BY created_at DESC LIMIT ?""",
                    (guild_id, limit)
                )
            
            logs = []
            for r in results:
                logs.append({
                    'id': r[0],
                    'guild_id': r[1],
                    'user_id': r[2],
                    'action_type': r[3],
                    'target_id': r[4],
                    'reason': r[5],
                    'created_at': r[6]
                })
            
            return logs
        except Exception as e:
            logger.error(f"❌ Ошибка при получении логов: {e}")
            return []
    
    async def clear_logs(self, guild_id: int) -> bool:
        """Очистить все логи гильдии"""
        try:
            self.db.execute(
                "DELETE FROM action_logs WHERE guild_id = ?",
                (guild_id,)
            )
            logger.info(f"🧹 Логи очищены для сервера {guild_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Ошибка при очистке логов: {e}")
            return False

# Удаление ненужной функции setup
# async def setup(bot):
#     await bot.add_cog(EventHandlersCog(bot))
