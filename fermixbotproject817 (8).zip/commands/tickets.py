"""
Команды управления тикетами для FermixBot
Настройки тикетов перенесены в админ панель (/admin -> Система тикетов)
"""
import discord
from discord.ext import commands
from discord import app_commands
import logging
from services.tickets import TicketService, TicketType

logger = logging.getLogger(__name__)


class TicketCommands(commands.Cog):
    """Команды для системы тикетов"""
    
    def __init__(self, bot):
        self.bot = bot
        self.ticket_service = TicketService(bot, bot.db)
        bot.ticket_service = self.ticket_service
    
    
    @app_commands.command(name="ticket-panel", description="Создать панель тикетов")
    @app_commands.describe(
        channel="Канал для панели тикетов"
    )
    async def ticket_panel(
        self, 
        interaction: discord.Interaction,
        channel: discord.TextChannel = None
    ):
        """Создать панель с кнопками для создания тикетов"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Требуются права администратора!",
                ephemeral=True
            )
            return
        
        target_channel = channel if channel else interaction.channel
        
        await interaction.response.defer()
        
        embed = discord.Embed(
            title="🎫 Система поддержки",
            description="Выберите тип тикета ниже для создания запроса в поддержку.\n\n"
                       "**Доступные типы:**\n"
                       f"🔧 **Техническая поддержка** - Проблемы с работой сервера\n"
                       f"💳 **Поддержка по донатам** - Вопросы о покупках и донатах\n"
                       f"📜 **Апелляция** - Обжалование блокировки/мута\n"
                       f"🎮 **Жалоба на игру** - Нарушения правил в игре\n"
                       f"💬 **Жалоба на Discord** - Нарушения правил в Discord\n"
                       f"⚠️ **Жалоба на администрацию** - Жалобы на действия администраторов\n"
                       f"🎉 **Предложение ивента** - Предложить свой ивент\n"
                       f"💡 **Предложение улучшения** - Улучшения Discord/игровых серверов",
            color=discord.Color.blurple()
        )
        
        embed.set_footer(text="Общение происходит через ЛС с ботом")
        
        view = TicketPanelView(self.ticket_service)
        
        await target_channel.send(embed=embed, view=view)
        await interaction.followup.send(
            f"✅ Панель тикетов создана в {target_channel.mention}",
            ephemeral=True
        )
    
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Обработка сообщений для тикетов"""
        # Игнорировать ботов
        if message.author.bot:
            return
        
        # Обработка ЛС
        if isinstance(message.channel, discord.DMChannel):
            forwarded = await self.ticket_service.handle_dm_message(message)
            if forwarded:
                try:
                    await message.add_reaction("✅")
                except:
                    pass
            return
        
        # Обработка сообщений в каналах тикетов
        if hasattr(self.bot, 'ticket_service'):
            await self.ticket_service.handle_ticket_message(message)


class TicketPanelView(discord.ui.View):
    """Панель с кнопками для создания тикетов"""
    
    def __init__(self, ticket_service: TicketService):
        super().__init__(timeout=None)
        self.ticket_service = ticket_service
    
    @discord.ui.button(
        label="Техническая поддержка",
        emoji="🔧",
        style=discord.ButtonStyle.blurple,
        custom_id="ticket_tech"
    )
    async def tech_support(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = TechSupportModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Поддержка по донатам",
        emoji="💳",
        style=discord.ButtonStyle.green,
        custom_id="ticket_donation"
    )
    async def donation_support(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = DonationSupportModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Апелляция",
        emoji="📜",
        style=discord.ButtonStyle.gray,
        custom_id="ticket_appeal"
    )
    async def appeal(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = AppealModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Жалоба на игру",
        emoji="🎮",
        style=discord.ButtonStyle.red,
        custom_id="ticket_game_report"
    )
    async def game_report(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = GameReportModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Жалоба на Discord",
        emoji="💬",
        style=discord.ButtonStyle.red,
        custom_id="ticket_discord_report"
    )
    async def discord_report(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = DiscordReportModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Жалоба на администрацию",
        emoji="⚠️",
        style=discord.ButtonStyle.red,
        custom_id="ticket_admin_report",
        row=2
    )
    async def admin_report(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = AdminReportModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Предложить ивент",
        emoji="🎉",
        style=discord.ButtonStyle.green,
        custom_id="ticket_event_suggestion",
        row=3
    )
    async def event_suggestion(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = EventSuggestionModal(self.ticket_service)
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(
        label="Предложение улучшения",
        emoji="💡",
        style=discord.ButtonStyle.green,
        custom_id="ticket_general_suggestion",
        row=3
    )
    async def general_suggestion(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = GeneralSuggestionModal(self.ticket_service)
        await interaction.response.send_modal(modal)


class TechSupportModal(discord.ui.Modal, title="Техническая поддержка"):
    """Модальное окно для технической поддержки"""
    
    description = discord.ui.TextInput(
        label="Опишите проблему",
        style=discord.TextStyle.paragraph,
        placeholder="Подробно опишите техническую проблему...",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.TECH_SUPPORT,
            self.description.value,
            {}
        )
        
        await self._handle_result(interaction, result)
    
    async def _handle_result(self, interaction, result):
        if result and 'error' not in result:
            embed = discord.Embed(
                title="✅ Тикет создан",
                description=f"Ваш тикет #{result['ticket_number']:04d} был создан.\n"
                           f"Общайтесь через ЛС с ботом.",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        elif result and 'error' in result:
            await interaction.followup.send(
                f"❌ {result['error']}",
                ephemeral=True
            )
        else:
            await interaction.followup.send(
                "❌ Не удалось создать тикет. Проверьте настройки системы тикетов.",
                ephemeral=True
            )


class DonationSupportModal(discord.ui.Modal, title="Поддержка по донатам"):
    """Модальное окно для поддержки по донатам"""
    
    steam_id = discord.ui.TextInput(
        label="Steam ID64",
        style=discord.TextStyle.short,
        placeholder="765611xxxxxxxxxx",
        required=True,
        max_length=17
    )
    
    description = discord.ui.TextInput(
        label="Опишите проблему с донатом",
        style=discord.TextStyle.paragraph,
        placeholder="Что произошло? Какой донат? Сумма? Скриншоты чека?",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        ticket_data = {
            'steam_id': self.steam_id.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.DONATION_SUPPORT,
            self.description.value,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class AppealModal(discord.ui.Modal, title="Апелляция"):
    """Модальное окно для апелляции"""
    
    steam_id = discord.ui.TextInput(
        label="Steam ID64",
        style=discord.TextStyle.short,
        placeholder="765611xxxxxxxxxx",
        required=True,
        max_length=17
    )
    
    description = discord.ui.TextInput(
        label="Причина апелляции",
        style=discord.TextStyle.paragraph,
        placeholder="За что был выдан бан/мут? Почему вы считаете это несправедливым?",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        ticket_data = {
            'steam_id': self.steam_id.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.APPEAL,
            self.description.value,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class GameReportModal(discord.ui.Modal, title="Жалоба на нарушение в игре"):
    """Модальное окно для жалобы на нарушение в игре"""
    
    reported_steam_id = discord.ui.TextInput(
        label="Steam ID64 нарушителя",
        style=discord.TextStyle.short,
        placeholder="765611xxxxxxxxxx",
        required=True,
        max_length=17
    )
    
    demo_link = discord.ui.TextInput(
        label="Ссылка на демку",
        style=discord.TextStyle.short,
        placeholder="https://...",
        required=True,
        max_length=200
    )
    
    description = discord.ui.TextInput(
        label="Описание нарушения",
        style=discord.TextStyle.paragraph,
        placeholder="Что произошло? На каком сервере? Время нарушения?",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        ticket_data = {
            'steam_id': self.reported_steam_id.value,
            'demo_link': self.demo_link.value,
            'reported_user': self.reported_steam_id.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.GAME_REPORT,
            self.description.value,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class DiscordReportModal(discord.ui.Modal, title="Жалоба на нарушение в Discord"):
    """Модальное окно для жалобы на нарушение в Discord"""
    
    reported_user = discord.ui.TextInput(
        label="ID или упоминание нарушителя",
        style=discord.TextStyle.short,
        placeholder="@Пользователь или 123456789012345678",
        required=True,
        max_length=100
    )
    
    evidence = discord.ui.TextInput(
        label="Доказательства (ссылки на скриншоты)",
        style=discord.TextStyle.paragraph,
        placeholder="Ссылки на скриншоты, сообщения и т.д.",
        required=True,
        max_length=500
    )
    
    description = discord.ui.TextInput(
        label="Описание нарушения",
        style=discord.TextStyle.paragraph,
        placeholder="Что произошло? Какое правило нарушено?",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        ticket_data = {
            'reported_user': self.reported_user.value,
            'evidence': self.evidence.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.DISCORD_REPORT,
            self.description.value,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class AdminReportModal(discord.ui.Modal, title="Жалоба на администрацию"):
    """Модальное окно для жалобы на администрацию"""
    
    admin_name = discord.ui.TextInput(
        label="Имя/ID администратора",
        style=discord.TextStyle.short,
        placeholder="Никнейм или @упоминание администратора",
        required=True,
        max_length=100
    )
    
    evidence = discord.ui.TextInput(
        label="Доказательства",
        style=discord.TextStyle.paragraph,
        placeholder="Ссылки на скриншоты, видео, логи",
        required=True,
        max_length=500
    )
    
    description = discord.ui.TextInput(
        label="Описание жалобы",
        style=discord.TextStyle.paragraph,
        placeholder="Подробно опишите ситуацию. Что сделал администратор?",
        required=True,
        max_length=1000
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        ticket_data = {
            'admin_name': self.admin_name.value,
            'evidence': self.evidence.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.ADMIN_REPORT,
            self.description.value,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class EventSuggestionModal(discord.ui.Modal, title="Предложение ивента"):
    """Модальное окно для предложения ивента"""
    
    event_name = discord.ui.TextInput(
        label="Название ивента",
        style=discord.TextStyle.short,
        placeholder="Короткое и понятное название...",
        required=True,
        max_length=100
    )
    
    event_description = discord.ui.TextInput(
        label="Что происходит в ивенте",
        style=discord.TextStyle.paragraph,
        placeholder="Как провести, механика ивента, если RP - как отыгрывать, лор ивента...",
        required=True,
        max_length=1500
    )
    
    additional_info = discord.ui.TextInput(
        label="Дополнительная информация (необязательно)",
        style=discord.TextStyle.paragraph,
        placeholder="Особые требования, примечания, идеи для улучшения...",
        required=False,
        max_length=500
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        description = (
            f"**Название:** {self.event_name.value}\n\n"
            f"**Описание ивента:**\n{self.event_description.value}"
        )
        
        if self.additional_info.value:
            description += f"\n\n**Дополнительно:**\n{self.additional_info.value}"
        
        description += (
            "\n\n**📋 Требования к ивентам:**\n"
            "✅ Ивент должен быть интересным и не кринжовым\n"
            "✅ RP-ивенты должны содержать лор и быть хорошо расписаны\n\n"
            "**📝 Процесс рассмотрения:**\n"
            "1️⃣ Редактор рассмотрит предложение\n"
            "2️⃣ После доработки будет принято решение\n"
            "3️⃣ При принятии - ивент добавится в список"
        )
        
        ticket_data = {
            'event_name': self.event_name.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.EVENT_SUGGESTION,
            description,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


class GeneralSuggestionModal(discord.ui.Modal, title="Предложение по улучшению"):
    """Модальное окно для общих предложений"""
    
    suggestion_title = discord.ui.TextInput(
        label="Заголовок предложения",
        style=discord.TextStyle.short,
        placeholder="Краткое описание предложения...",
        required=True,
        max_length=100
    )
    
    server_type = discord.ui.TextInput(
        label="Тип сервера",
        style=discord.TextStyle.short,
        placeholder="Discord сервер / NR (norules) / Classic / Другое",
        required=True,
        max_length=50
    )
    
    suggestion_description = discord.ui.TextInput(
        label="Подробное описание",
        style=discord.TextStyle.paragraph,
        placeholder="Подробно опишите ваше предложение. Что улучшить? Почему это нужно? Как реализовать?",
        required=True,
        max_length=1500
    )
    
    benefits = discord.ui.TextInput(
        label="Преимущества (необязательно)",
        style=discord.TextStyle.paragraph,
        placeholder="Какие плюсы принесет это предложение для сервера и игроков?",
        required=False,
        max_length=500
    )
    
    def __init__(self, ticket_service: TicketService):
        super().__init__()
        self.ticket_service = ticket_service
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        description = (
            f"**📌 Тип сервера:** {self.server_type.value}\n\n"
            f"**📝 Описание предложения:**\n{self.suggestion_description.value}"
        )
        
        if self.benefits.value:
            description += f"\n\n**✨ Преимущества:**\n{self.benefits.value}"
        
        ticket_data = {
            'suggestion_title': self.suggestion_title.value,
            'server_type': self.server_type.value
        }
        
        result = await self.ticket_service.create_ticket(
            interaction.guild.id,
            interaction.user.id,
            TicketType.GENERAL_SUGGESTION,
            description,
            ticket_data
        )
        
        await TechSupportModal._handle_result(self, interaction, result)


async def setup(bot):
    await bot.add_cog(TicketCommands(bot))
