"""
Команды админ-панели для FermixBot
Интерактивная система конфигурации с кнопками
"""
import discord
from discord.ext import commands
from discord import app_commands, ui
import logging
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger(__name__)


class NavigableView(ui.View):
    """Базовый класс для навигируемых меню"""
    
    def __init__(self, bot, timeout=600):
        super().__init__(timeout=timeout)
        self.bot = bot
        self.message = None
    
    async def update_message(self, interaction: discord.Interaction, embed: discord.Embed, view: ui.View = None):
        """Обновляет сообщение вместо создания нового"""
        try:
            if interaction.response.is_done():
                await interaction.edit_original_response(embed=embed, view=view or self)
            else:
                await interaction.response.edit_message(embed=embed, view=view or self)
        except Exception as e:
            logger.error(f"Ошибка обновления сообщения: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, view=view or self, ephemeral=True)
            except:
                pass


class AdminConfigView(NavigableView):
    """Главное меню конфигурации сервера"""
    
    def __init__(self, bot):
        super().__init__(bot)
    
    @ui.button(label="🎖️ Система уровней", style=discord.ButtonStyle.blurple, row=0)
    async def level_system(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка системы уровней"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = LevelSystemView(self.bot, interaction.guild)
        embed = await self._get_level_settings_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="🎭 Автовыдача ролей", style=discord.ButtonStyle.green, row=0)
    async def autorole_config(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка автовыдачи ролей"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = AutoroleView(self.bot, interaction.guild)
        embed = await self._get_autorole_settings_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="🎫 Система тикетов", style=discord.ButtonStyle.blurple, row=0)
    async def ticket_config(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка системы тикетов"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = TicketConfigView(self.bot, interaction.guild)
        embed = await self._get_ticket_settings_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="🛡️ Безопасность", style=discord.ButtonStyle.red, row=0)
    async def security_config(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка системы безопасности"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = SecurityView(self.bot, interaction.guild)
        embed = await self._get_security_settings_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="⚙️ Роль мута", style=discord.ButtonStyle.gray, row=1)
    async def set_mute_role(self, interaction: discord.Interaction, button: ui.Button):
        """Выбрать роль мута"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = MuteRoleSelectView(self.bot, interaction.guild)
        embed = await self._get_mute_role_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="📝 Канал логов", style=discord.ButtonStyle.gray, row=1)
    async def set_log_channel(self, interaction: discord.Interaction, button: ui.Button):
        """Выбрать канал логов"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = LogChannelSelectView(self.bot, interaction.guild)
        embed = await self._get_log_channel_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="👮 Роли модерации", style=discord.ButtonStyle.danger, row=1)
    async def manage_mod_roles(self, interaction: discord.Interaction, button: ui.Button):
        """Управление ролями модерации"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = ModRolesView(self.bot, interaction.guild)
        embed = await self._get_mod_roles_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="💾 Резервные копии", style=discord.ButtonStyle.gray, row=2)
    async def backup_manager(self, interaction: discord.Interaction, button: ui.Button):
        """Управление резервными копиями"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = BackupView(self.bot, interaction.guild)
        embed = await self._get_backup_list_embed(interaction.guild)
        await self.update_message(interaction, embed, view)
    
    async def _get_level_settings_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройками системы уровней"""
        results = self.bot.db.fetch_all(
            "SELECT role_id, required_level FROM level_roles WHERE guild_id = ? ORDER BY required_level",
            (guild.id,)
        )
        
        embed = discord.Embed(
            title="🎖️ Настройка системы уровней",
            description="Текущие настройки и управление",
            color=discord.Color.gold()
        )
        
        if results:
            roles_text = "\n".join([
                f"**Уровень {lvl}**: <@&{rid}>"
                for rid, lvl in results
            ])
            embed.add_field(name="🎭 Роли за уровни", value=roles_text, inline=False)
        else:
            embed.add_field(name="🎭 Роли за уровни", value="❌ Не настроено", inline=False)
        
        channel_id = self.bot.db.get_level_channel(guild.id)
        if channel_id:
            embed.add_field(
                name="📢 Канал уведомлений",
                value=f"<#{channel_id}>",
                inline=False
            )
        else:
            embed.add_field(name="📢 Канал уведомлений", value="❌ Не настроено", inline=False)
        
        return embed
    
    async def _get_autorole_settings_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройками автовыдачи ролей"""
        embed = discord.Embed(
            title="🎭 Настройка автовыдачи ролей",
            description="Текущие настройки и управление",
            color=discord.Color.blue()
        )
        
        if hasattr(self.bot, 'autorole_service'):
            role_ids = await self.bot.autorole_service.get_autoroles(guild.id)
            
            if role_ids:
                roles_text = "\n".join([f"<@&{rid}>" for rid in role_ids])
                embed.add_field(name="Автовыдаваемые роли", value=roles_text, inline=False)
            else:
                embed.add_field(name="Автовыдаваемые роли", value="❌ Не настроено", inline=False)
        else:
            embed.add_field(name="Автовыдаваемые роли", value="❌ Сервис не активен", inline=False)
        
        return embed
    
    async def _get_ticket_settings_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройками тикетов"""
        settings = self.bot.db.fetch_one(
            """SELECT category_id, support_role_id, transcript_channel_id 
               FROM ticket_settings WHERE guild_id = ?""",
            (guild.id,)
        )
        
        embed = discord.Embed(
            title="🎫 Настройка системы тикетов",
            description="Текущие настройки и управление",
            color=discord.Color.blurple()
        )
        
        if settings:
            cat_id, role_id, trans_id = settings
            embed.add_field(
                name="📁 Категория",
                value=f"<#{cat_id}>" if cat_id else "❌ Не настроено",
                inline=False
            )
            embed.add_field(
                name="👥 Роль поддержки",
                value=f"<@&{role_id}>" if role_id else "❌ Не настроено",
                inline=False
            )
            embed.add_field(
                name="📄 Канал транскриптов",
                value=f"<#{trans_id}>" if trans_id else "❌ Не настроено",
                inline=False
            )
        else:
            embed.add_field(name="Статус", value="❌ Система тикетов не настроена", inline=False)
        
        return embed
    
    async def _get_security_settings_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройками безопасности"""
        embed = discord.Embed(
            title="🛡️ Настройка системы безопасности",
            description="Текущие настройки и управление",
            color=discord.Color.from_rgb(255, 165, 0)
        )
        
        if hasattr(self.bot, 'security_service'):
            # Get whitelist info
            whitelist = await self.bot.security_service.get_whitelist(guild.id)
            user_count = len(whitelist.get("users", []))
            role_count = len(whitelist.get("roles", []))
            
            embed.add_field(
                name="🛡️ Вайтлист",
                value=f"Пользователей: {user_count}\nРолей: {role_count}",
                inline=True
            )
            
            # Get dangerous roles
            dangerous = await self.bot.security_service.get_dangerous_roles(guild.id)
            embed.add_field(
                name="🚩 Опасные роли",
                value=f"Отмечено: {len(dangerous)}",
                inline=True
            )
            
            # Get stats
            stats = await self.bot.security_service.get_security_stats(guild.id)
            embed.add_field(
                name="📊 Статистика (24ч)",
                value=f"Нарушений: {stats.get('total_infractions', 0)}",
                inline=True
            )
        else:
            embed.add_field(name="Статус", value="❌ Сервис безопасности не активен", inline=False)
        
        return embed
    
    async def _get_mute_role_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройкой роли мута"""
        embed = discord.Embed(
            title="⚙️ Настройка роли мута",
            description="Текущая настройка и изменение",
            color=discord.Color.blurple()
        )
        
        mute_role_id = self.bot.db.fetch_one(
            "SELECT mute_role_id FROM guild_settings WHERE guild_id = ?",
            (guild.id,)
        )
        
        if mute_role_id and mute_role_id[0]:
            embed.add_field(
                name="Текущая роль мута",
                value=f"<@&{mute_role_id[0]}>",
                inline=False
            )
        else:
            embed.add_field(name="Текущая роль мута", value="❌ Не настроено", inline=False)
        
        embed.add_field(
            name="Выберите новую роль",
            value="Используйте меню ниже для выбора роли мута",
            inline=False
        )
        
        return embed
    
    async def _get_log_channel_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с настройкой канала логов"""
        embed = discord.Embed(
            title="📝 Настройка канала логов",
            description="Текущая настройка и изменение",
            color=discord.Color.blurple()
        )
        
        log_channel_id = self.bot.db.get_log_channel(guild.id)
        
        if log_channel_id:
            embed.add_field(
                name="Текущий канал логов",
                value=f"<#{log_channel_id}>",
                inline=False
            )
        else:
            embed.add_field(name="Текущий канал логов", value="❌ Не настроено", inline=False)
        
        embed.add_field(
            name="Выберите новый канал",
            value="Используйте меню ниже для выбора канала логов",
            inline=False
        )
        
        return embed
    
    async def _get_mod_roles_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed с ролями модерации"""
        roles = await self.bot.moderation_service.get_mod_roles(guild.id)
        
        embed = discord.Embed(
            title="👮 Управление ролями модерации",
            description="Текущие настройки и управление",
            color=discord.Color.red()
        )
        
        if roles:
            roles_text = "\n".join([f"<@&{role_id}>" for role_id in roles])
            embed.add_field(name="Роли с правами модерации", value=roles_text, inline=False)
        else:
            embed.add_field(name="Роли с правами модерации", value="❌ Не настроено", inline=False)
        
        return embed
    
    async def _get_backup_list_embed(self, guild: discord.Guild) -> discord.Embed:
        """Получить embed со списком бэкапов"""
        embed = discord.Embed(
            title="💾 Управление резервными копиями",
            description="Создание и восстановление резервных копий сервера",
            color=discord.Color.blue()
        )
        
        if hasattr(self.bot, 'backup_service'):
            backups = await self.bot.backup_service.get_backups(guild.id)
            
            if backups:
                backups_text = "\n".join([
                    f"**{backup['name']}** - {backup['created_at']}"
                    for backup in backups[:5]
                ])
                embed.add_field(
                    name=f"Резервные копии ({len(backups)})",
                    value=backups_text,
                    inline=False
                )
                if len(backups) > 5:
                    embed.set_footer(text=f"Показаны первые 5 из {len(backups)}")
            else:
                embed.add_field(name="Резервные копии", value="❌ Нет резервных копий", inline=False)
        else:
            embed.add_field(name="Статус", value="❌ Сервис недоступен", inline=False)
        
        embed.add_field(
            name="⚠️ Предупреждение",
            value="Восстановление удалит все текущие роли и каналы!",
            inline=False
        )
        
        return embed


class LevelSystemView(NavigableView):
    """Меню настройки системы уровней"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="🎭 Добавить роль за уровень", style=discord.ButtonStyle.green, row=0)
    async def configure_roles(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка ролей за уровни"""
        view = LevelRoleSelectView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="🎭 Добавление роли за уровень",
            description="Выберите роль для награды за уровень",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="📢 Изменить канал уведомлений", style=discord.ButtonStyle.blurple, row=0)
    async def configure_channel(self, interaction: discord.Interaction, button: ui.Button):
        """Настройка канала уведомлений"""
        view = LevelChannelSelectView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="📢 Канал уведомлений о повышении",
            description="Выберите канал для отправки уведомлений",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)
    
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        """Вернуться в главное меню"""
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class LevelRoleSelectView(NavigableView):
    """Выбор роли для награды за уровень"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роль...", max_values=1, row=0)
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        """Обработка выбора роли"""
        selected_role_id = self.children[0].values[0]
        selected_role = self.guild.get_role(int(selected_role_id))
        
        modal = ui.Modal(title=f"Уровень для {selected_role.name[:30]}")
        level_input = ui.TextInput(
            label="Требуемый уровень (1-50)",
            placeholder="Введите уровень...",
            min_length=1,
            max_length=2,
            required=True
        )
        modal.add_item(level_input)
        
        async def level_submit(modal_interaction: discord.Interaction):
            try:
                level = int(level_input.value)
                if level < 1 or level > 50:
                    raise ValueError()
                
                if hasattr(self.bot, 'leveling_service'):
                    self.bot.leveling_service.add_level_role(self.guild.id, selected_role.id, level)
                    
                    embed = discord.Embed(
                        title="✅ Роль добавлена",
                        description=f"{selected_role.mention} будет выдаваться за **уровень {level}**\n\nВыберите еще одну роль или вернитесь назад",
                        color=discord.Color.green()
                    )
                    await modal_interaction.response.edit_message(embed=embed, view=self)
                else:
                    embed = discord.Embed(
                        title="❌ Ошибка",
                        description="Система уровней не активна",
                        color=discord.Color.red()
                    )
                    await modal_interaction.response.edit_message(embed=embed, view=self)
            except ValueError:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Введите корректный уровень от 1 до 50",
                    color=discord.Color.red()
                )
                await modal_interaction.response.edit_message(embed=embed, view=self)
        
        modal.on_submit = level_submit
        await interaction.response.send_modal(modal)
    
    async def go_back(self, interaction: discord.Interaction):
        """Вернуться к настройкам уровней"""
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_level_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class LevelChannelSelectView(NavigableView):
    """Выбор канала для уведомлений о повышении"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        channel_select = ui.ChannelSelect(
            placeholder="Выберите канал...",
            channel_types=[discord.ChannelType.text],
            max_values=1,
            row=0
        )
        channel_select.callback = self.channel_selected
        self.add_item(channel_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def channel_selected(self, interaction: discord.Interaction):
        channel = self.children[0].values[0]
        
        if hasattr(self.bot, 'leveling_service'):
            self.bot.leveling_service.set_level_channel(self.guild.id, channel.id)
            
            embed = discord.Embed(
                title="✅ Канал установлен",
                description=f"Уведомления о повышении уровня будут отправляться в {channel.mention}",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Система уровней не активна",
                color=discord.Color.red()
            )
        
        await interaction.response.edit_message(embed=embed, view=self)
    
    async def go_back(self, interaction: discord.Interaction):
        """Вернуться к настройкам уровней"""
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_level_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class AutoroleView(NavigableView):
    """Меню настройки автовыдачи ролей"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="➕ Добавить роль", style=discord.ButtonStyle.green, row=0)
    async def add_role(self, interaction: discord.Interaction, button: ui.Button):
        """Добавить роль для автовыдачи"""
        view = AutoroleAddView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="➕ Добавление роли",
            description="Выберите роль для автоматической выдачи новым участникам",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="➖ Удалить роль", style=discord.ButtonStyle.red, row=0)
    async def remove_role(self, interaction: discord.Interaction, button: ui.Button):
        """Удалить роль из автовыдачи"""
        view = AutoroleRemoveView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="➖ Удаление роли",
            description="Выберите роль для удаления из автовыдачи",
            color=discord.Color.red()
        )
        await self.update_message(interaction, embed, view)
    
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        """Вернуться в главное меню"""
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class AutoroleAddView(NavigableView):
    """Добавление роли в автовыдачу"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роль...", max_values=1, row=0)
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        role = self.children[0].values[0]
        
        if hasattr(self.bot, 'autorole_service'):
            success = await self.bot.autorole_service.add_autorole(self.guild.id, role.id)
            
            if success:
                embed = discord.Embed(
                    title="✅ Роль добавлена",
                    description=f"{role.mention} будет автоматически выдаваться новым участникам",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось добавить роль",
                    color=discord.Color.red()
                )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис автовыдачи ролей не активен",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_autorole_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class AutoroleRemoveView(NavigableView):
    """Удаление роли из автовыдачи"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роль для удаления...", max_values=1, row=0)
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        role = self.children[0].values[0]
        
        if hasattr(self.bot, 'autorole_service'):
            success = await self.bot.autorole_service.remove_autorole(self.guild.id, role.id)
            
            if success:
                embed = discord.Embed(
                    title="✅ Роль удалена",
                    description=f"{role.mention} больше не будет выдаваться автоматически",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось удалить роль",
                    color=discord.Color.red()
                )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис автовыдачи ролей не активен",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_autorole_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class TicketConfigView(NavigableView):
    """Меню настройки системы тикетов"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="📁 Категория тикетов", style=discord.ButtonStyle.green, row=0)
    async def configure_category(self, interaction: discord.Interaction, button: ui.Button):
        view = TicketCategorySelectView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="📁 Выбор категории для тикетов",
            description="Выберите категорию, в которой будут создаваться тикеты",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="👥 Роль поддержки", style=discord.ButtonStyle.blurple, row=0)
    async def configure_support_role(self, interaction: discord.Interaction, button: ui.Button):
        view = TicketSupportRoleView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="👥 Выбор роли поддержки",
            description="Выберите роль с доступом к тикетам",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="📄 Канал транскриптов", style=discord.ButtonStyle.secondary, row=0)
    async def configure_transcript(self, interaction: discord.Interaction, button: ui.Button):
        view = TicketTranscriptChannelView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="📄 Выбор канала транскриптов",
            description="Выберите канал для сохранения транскриптов",
            color=discord.Color.light_grey()
        )
        await self.update_message(interaction, embed, view)
    
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class TicketCategorySelectView(NavigableView):
    """Выбор категории для тикетов"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        categories = [cat for cat in guild.categories][:25]
        
        if categories:
            cat_select = ui.Select(
                placeholder="Выберите категорию...",
                options=[
                    discord.SelectOption(label=cat.name[:100], value=str(cat.id))
                    for cat in categories
                ],
                row=0
            )
            cat_select.callback = self.category_selected
            self.add_item(cat_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def category_selected(self, interaction: discord.Interaction):
        category_id = int(self.children[0].values[0])
        
        existing = self.bot.db.fetch_one(
            "SELECT guild_id FROM ticket_settings WHERE guild_id = ?",
            (self.guild.id,)
        )
        
        if existing:
            self.bot.db.execute(
                "UPDATE ticket_settings SET category_id = ? WHERE guild_id = ?",
                (category_id, self.guild.id)
            )
        else:
            self.bot.db.execute(
                "INSERT INTO ticket_settings (guild_id, category_id) VALUES (?, ?)",
                (self.guild.id, category_id)
            )
        
        embed = discord.Embed(
            title="✅ Категория установлена",
            description=f"Тикеты будут создаваться в <#{category_id}>",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_ticket_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class TicketSupportRoleView(NavigableView):
    """Выбор роли поддержки для тикетов"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роль поддержки...", max_values=1, row=0)
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        role = self.children[0].values[0]
        
        existing = self.bot.db.fetch_one(
            "SELECT guild_id FROM ticket_settings WHERE guild_id = ?",
            (self.guild.id,)
        )
        
        if existing:
            self.bot.db.execute(
                "UPDATE ticket_settings SET support_role_id = ? WHERE guild_id = ?",
                (role.id, self.guild.id)
            )
        else:
            self.bot.db.execute(
                "INSERT INTO ticket_settings (guild_id, support_role_id) VALUES (?, ?)",
                (self.guild.id, role.id)
            )
        
        embed = discord.Embed(
            title="✅ Роль поддержки установлена",
            description=f"{role.mention} будет иметь доступ к тикетам",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_ticket_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class TicketTranscriptChannelView(NavigableView):
    """Выбор канала для транскриптов"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        channel_select = ui.ChannelSelect(
            placeholder="Выберите канал для транскриптов...",
            channel_types=[discord.ChannelType.text],
            max_values=1,
            row=0
        )
        channel_select.callback = self.channel_selected
        self.add_item(channel_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def channel_selected(self, interaction: discord.Interaction):
        channel = self.children[0].values[0]
        
        existing = self.bot.db.fetch_one(
            "SELECT guild_id FROM ticket_settings WHERE guild_id = ?",
            (self.guild.id,)
        )
        
        if existing:
            self.bot.db.execute(
                "UPDATE ticket_settings SET transcript_channel_id = ? WHERE guild_id = ?",
                (channel.id, self.guild.id)
            )
        else:
            self.bot.db.execute(
                "INSERT INTO ticket_settings (guild_id, transcript_channel_id) VALUES (?, ?)",
                (self.guild.id, channel.id)
            )
        
        embed = discord.Embed(
            title="✅ Канал транскриптов установлен",
            description=f"Транскрипты будут сохраняться в {channel.mention}",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_ticket_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class MuteRoleSelectView(NavigableView):
    """Выбор роли мута"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
        
        role_select = ui.RoleSelect(
            placeholder="Выберите роль мута...",
            max_values=1,
            row=0
        )
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        role = self.children[0].values[0]
        
        success = await self.bot.moderation_service.set_mute_role(self.guild.id, role.id)
        
        if success:
            embed = discord.Embed(
                title="✅ Роль мута установлена",
                description=f"Роль мута: {role.mention}",
                color=discord.Color.green()
            )
            logger.info(f"✅ Для сервера {self.guild} установлена роль мута {role.name}")
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось установить роль мута",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class LogChannelSelectView(NavigableView):
    """Выбор канала логов"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
        
        channel_select = ui.ChannelSelect(
            placeholder="Выберите канал логов...",
            channel_types=[discord.ChannelType.text],
            max_values=1,
            row=0
        )
        channel_select.callback = self.channel_selected
        self.add_item(channel_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def channel_selected(self, interaction: discord.Interaction):
        channel = self.children[0].values[0]
        
        success = await self.bot.moderation_service.set_log_channel(self.guild.id, channel.id)
        
        if success:
            embed = discord.Embed(
                title="✅ Канал логов установлен",
                description=f"Канал логов: {channel.mention}",
                color=discord.Color.green()
            )
            logger.info(f"✅ Для сервера {self.guild} установлен канал логов {channel.name}")
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось установить канал логов",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class ModRolesView(NavigableView):
    """Меню управления ролями модерации"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="➕ Добавить роли", style=discord.ButtonStyle.green, row=0)
    async def add_roles(self, interaction: discord.Interaction, button: ui.Button):
        view = ModRolesAddView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="➕ Добавление ролей модерации",
            description="Выберите роли для добавления прав модерации",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="❌ Удалить роли", style=discord.ButtonStyle.red, row=0)
    async def remove_roles(self, interaction: discord.Interaction, button: ui.Button):
        view = ModRolesRemoveView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="❌ Удаление ролей модерации",
            description="Выберите роли для удаления прав модерации",
            color=discord.Color.red()
        )
        await self.update_message(interaction, embed, view)
    
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class ModRolesAddView(NavigableView):
    """Добавление ролей модерации"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(
            placeholder="Выберите роли...",
            min_values=1,
            max_values=10,
            row=0
        )
        role_select.callback = self.roles_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def roles_selected(self, interaction: discord.Interaction):
        roles = self.children[0].values
        
        added_roles = []
        for role in roles:
            success = await self.bot.moderation_service.add_mod_role(self.guild.id, role.id)
            if success:
                added_roles.append(role.mention)
        
        if added_roles:
            embed = discord.Embed(
                title="✅ Роли добавлены",
                description=f"Добавлены роли модерации:\n" + "\n".join(added_roles),
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось добавить роли",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_mod_roles_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class ModRolesRemoveView(NavigableView):
    """Удаление ролей модерации"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(
            placeholder="Выберите роли для удаления...",
            min_values=1,
            max_values=10,
            row=0
        )
        role_select.callback = self.roles_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def roles_selected(self, interaction: discord.Interaction):
        roles = self.children[0].values
        
        removed_roles = []
        for role in roles:
            success = await self.bot.moderation_service.remove_mod_role(self.guild.id, role.id)
            if success:
                removed_roles.append(role.mention)
        
        if removed_roles:
            embed = discord.Embed(
                title="✅ Роли удалены",
                description=f"Удалены роли модерации:\n" + "\n".join(removed_roles),
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось удалить роли",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_mod_roles_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class BackupView(NavigableView):
    """Меню управления резервными копиями"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="➕ Создать копию", style=discord.ButtonStyle.green, row=0)
    async def create_backup(self, interaction: discord.Interaction, button: ui.Button):
        """Создать новую резервную копию"""
        await interaction.response.defer()
        
        if hasattr(self.bot, 'backup_service'):
            success = await self.bot.backup_service.create_backup(self.guild, None)
            
            if success:
                embed = discord.Embed(
                    title="✅ Резервная копия создана",
                    description="Сохранены: роли, каналы, разрешения, роли пользователей",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось создать резервную копию",
                    color=discord.Color.red()
                )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис резервного копирования не активен",
                color=discord.Color.red()
            )
        
        await interaction.followup.send(embed=embed, ephemeral=True)
    
    @ui.button(label="📥 Загрузить копию", style=discord.ButtonStyle.primary, row=0)
    async def restore_backup(self, interaction: discord.Interaction, button: ui.Button):
        """Выбрать резервную копию для восстановления"""
        if not hasattr(self.bot, 'backup_service'):
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Сервис резервного копирования не активен",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        backups = await self.bot.backup_service.get_backups(self.guild.id)
        
        if not backups:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Нет бэкапов",
                    description="Сначала создайте резервную копию",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = BackupSelectView(self.bot, self.guild, backups)
        embed = discord.Embed(
            title="📥 Выбор резервной копии",
            description="Выберите резервную копию для восстановления\n⚠️ **Все текущие роли и каналы будут удалены!**",
            color=discord.Color.orange()
        )
        
        backups_list = "\n".join([
            f"{i+1}. **{backup['name']}** - {backup['created_at']}"
            for i, backup in enumerate(backups[:10])
        ])
        embed.add_field(name="Доступные копии", value=backups_list, inline=False)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    @ui.button(label="📋 Обновить список", style=discord.ButtonStyle.blurple, row=0)
    async def refresh_list(self, interaction: discord.Interaction, button: ui.Button):
        """Обновить список резервных копий"""
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_backup_list_embed(self.guild)
        await self.update_message(interaction, embed, self)
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        """Вернуться в главное меню"""
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class BackupSelectView(ui.View):
    """Выбор резервной копии для восстановления"""
    
    def __init__(self, bot, guild, backups):
        super().__init__(timeout=300)
        self.bot = bot
        self.guild = guild
        self.backups = backups
        
        # Create select menu with backups
        options = [
            discord.SelectOption(
                label=backup['name'][:100],
                description=f"Создан: {backup['created_at']}"[:100],
                value=backup['name']
            )
            for backup in backups[:25]  # Discord limit
        ]
        
        select = ui.Select(
            placeholder="Выберите резервную копию...",
            options=options,
            custom_id="backup_select"
        )
        select.callback = self.backup_selected
        self.add_item(select)
    
    async def backup_selected(self, interaction: discord.Interaction):
        """Обработка выбора резервной копии"""
        backup_name = interaction.data['values'][0]
        
        # Show confirmation
        view = BackupConfirmView(self.bot, self.guild, backup_name)
        embed = discord.Embed(
            title="⚠️ Подтверждение восстановления",
            description=f"Вы уверены, что хотите восстановить сервер из копии **{backup_name}**?",
            color=discord.Color.red()
        )
        embed.add_field(
            name="❗ Будет удалено:",
            value="• Все текущие роли (кроме @everyone)\n• Все текущие каналы\n• Все разрешения каналов",
            inline=False
        )
        embed.add_field(
            name="✅ Будет создано:",
            value="• Роли из резервной копии\n• Каналы из резервной копии\n• Разрешения из резервной копии",
            inline=False
        )
        embed.set_footer(text="Это действие необратимо! Убедитесь, что у вас есть свежая копия.")
        
        await interaction.response.edit_message(embed=embed, view=view)


class BackupConfirmView(ui.View):
    """Подтверждение восстановления резервной копии"""
    
    def __init__(self, bot, guild, backup_name):
        super().__init__(timeout=60)
        self.bot = bot
        self.guild = guild
        self.backup_name = backup_name
    
    @ui.button(label="✅ Да, восстановить", style=discord.ButtonStyle.danger, row=0)
    async def confirm_restore(self, interaction: discord.Interaction, button: ui.Button):
        """Подтвердить восстановление"""
        await interaction.response.defer()
        
        embed = discord.Embed(
            title="🔄 Восстановление...",
            description="Пожалуйста, подождите. Это может занять несколько минут.",
            color=discord.Color.blue()
        )
        await interaction.followup.edit_message(message_id=interaction.message.id, embed=embed, view=None)
        
        try:
            # Delete all current roles (except @everyone and bot roles)
            logger.info(f"🗑️ Удаление текущих ролей на сервере {self.guild.name}...")
            for role in self.guild.roles:
                if role == self.guild.default_role:
                    continue
                if role.managed:  # Skip bot roles
                    continue
                try:
                    await role.delete(reason=f"Восстановление из {self.backup_name}")
                except Exception as e:
                    logger.warning(f"⚠️ Не удалось удалить роль {role.name}: {e}")
            
            # Delete all current channels
            logger.info(f"🗑️ Удаление текущих каналов на сервере {self.guild.name}...")
            for channel in self.guild.channels:
                try:
                    await channel.delete(reason=f"Восстановление из {self.backup_name}")
                except Exception as e:
                    logger.warning(f"⚠️ Не удалось удалить канал {channel.name}: {e}")
            
            # Restore from backup
            success = await self.bot.backup_service.restore_backup(self.guild, self.backup_name)
            
            if success:
                embed = discord.Embed(
                    title="✅ Восстановление завершено",
                    description=f"Сервер восстановлен из резервной копии **{self.backup_name}**",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="Восстановлено:",
                    value="• Роли\n• Каналы\n• Разрешения",
                    inline=False
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка восстановления",
                    description="Не удалось восстановить резервную копию. Проверьте логи.",
                    color=discord.Color.red()
                )
        
        except Exception as e:
            logger.error(f"❌ Ошибка при восстановлении: {e}")
            embed = discord.Embed(
                title="❌ Критическая ошибка",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.followup.edit_message(message_id=interaction.message.id, embed=embed, view=None)
    
    @ui.button(label="❌ Отмена", style=discord.ButtonStyle.secondary, row=0)
    async def cancel_restore(self, interaction: discord.Interaction, button: ui.Button):
        """Отменить восстановление"""
        embed = discord.Embed(
            title="❌ Восстановление отменено",
            description="Восстановление резервной копии было отменено",
            color=discord.Color.orange()
        )
        await interaction.response.edit_message(embed=embed, view=None)


class SecurityView(NavigableView):
    """Меню настройки системы безопасности"""
    
    def __init__(self, bot, guild):
        super().__init__(bot)
        self.guild = guild
    
    @ui.button(label="🛡️ Управление вайтлистом", style=discord.ButtonStyle.green, row=0)
    async def manage_whitelist(self, interaction: discord.Interaction, button: ui.Button):
        """Управление вайтлистом"""
        view = WhitelistManageView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="🛡️ Управление вайтлистом",
            description="Добавить или удалить пользователей/роли из вайтлиста",
            color=discord.Color.green()
        )
        
        if hasattr(self.bot, 'security_service'):
            whitelist = await self.bot.security_service.get_whitelist(self.guild.id)
            
            if whitelist["users"]:
                users_text = "\n".join([f"<@{u[0]}>" for u in whitelist["users"][:5]])
                embed.add_field(name="👥 Пользователи", value=users_text, inline=False)
                if len(whitelist["users"]) > 5:
                    embed.set_footer(text=f"Показаны первые 5 из {len(whitelist['users'])}")
            
            if whitelist["roles"]:
                roles_text = "\n".join([f"<@&{r[0]}>" for r in whitelist["roles"][:5]])
                embed.add_field(name="🎖️ Роли", value=roles_text, inline=False)
        
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="🚩 Опасные роли", style=discord.ButtonStyle.red, row=0)
    async def manage_dangerous(self, interaction: discord.Interaction, button: ui.Button):
        """Управление опасными ролями"""
        view = DangerousRolesManageView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="🚩 Управление опасными ролями",
            description="Отметить или удалить опасные роли",
            color=discord.Color.red()
        )
        
        if hasattr(self.bot, 'security_service'):
            dangerous = await self.bot.security_service.get_dangerous_roles(self.guild.id)
            
            if dangerous:
                roles_text = "\n".join([f"<@&{d[0]}>" for d in dangerous[:10]])
                embed.add_field(name="Отмеченные роли", value=roles_text, inline=False)
            else:
                embed.add_field(name="Отмеченные роли", value="❌ Нет отмеченных ролей", inline=False)
        
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="⚙️ Проверить роль", style=discord.ButtonStyle.blurple, row=0)
    async def check_role(self, interaction: discord.Interaction, button: ui.Button):
        """Проверить роль на опасные права"""
        view = RoleCheckView(self.bot, self.guild, parent_view=self)
        embed = discord.Embed(
            title="⚙️ Проверка роли",
            description="Выберите роль для проверки на опасные права",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="📊 Статистика", style=discord.ButtonStyle.secondary, row=1)
    async def view_stats(self, interaction: discord.Interaction, button: ui.Button):
        """Просмотр статистики безопасности"""
        if not hasattr(self.bot, 'security_service'):
            await interaction.response.send_message(
                "❌ Сервис безопасности не активен",
                ephemeral=True
            )
            return
        
        stats = await self.bot.security_service.get_security_stats(self.guild.id)
        
        embed = discord.Embed(
            title="📊 Статистика безопасности за 24 часа",
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        embed.add_field(name="📧 Попыток спама", value=str(stats.get('spam_incidents', 0)), inline=True)
        embed.add_field(name="🔨 Обнаружено рейдов", value=str(stats.get('raid_incidents', 0)), inline=True)
        embed.add_field(name="💣 Попыток нука", value=str(stats.get('nuke_incidents', 0)), inline=True)
        embed.add_field(name="📈 Всего нарушений", value=str(stats.get('total_infractions', 0)), inline=False)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        """Вернуться в главное меню"""
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        await self.update_message(interaction, embed, view)


class WhitelistManageView(NavigableView):
    """Управление вайтлистом"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
    
    @ui.button(label="➕ Добавить пользователей", style=discord.ButtonStyle.green, row=0)
    async def add_users(self, interaction: discord.Interaction, button: ui.Button):
        view = WhitelistUserAddView(self.bot, self.guild, self)
        embed = discord.Embed(
            title="➕ Добавление пользователей",
            description="Выберите пользователей для добавления в вайтлист",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="➕ Добавить роли", style=discord.ButtonStyle.green, row=0)
    async def add_roles(self, interaction: discord.Interaction, button: ui.Button):
        view = WhitelistRoleAddView(self.bot, self.guild, self)
        embed = discord.Embed(
            title="➕ Добавление ролей",
            description="Выберите роли для добавления в вайтлист",
            color=discord.Color.green()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class WhitelistUserAddView(NavigableView):
    """Добавление пользователей в вайтлист"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        user_select = ui.UserSelect(placeholder="Выберите пользователей...", min_values=1, max_values=10, row=0)
        user_select.callback = self.users_selected
        self.add_item(user_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def users_selected(self, interaction: discord.Interaction):
        users = self.children[0].values
        
        if hasattr(self.bot, 'security_service'):
            for user in users:
                await self.bot.security_service.add_to_whitelist(
                    self.guild.id, user.id, "user",
                    "Добавлен через админ панель",
                    interaction.user.id
                )
            
            embed = discord.Embed(
                title="✅ Пользователи добавлены",
                description=f"Добавлено пользователей: {len(users)}",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис безопасности не активен",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class WhitelistRoleAddView(NavigableView):
    """Добавление ролей в вайтлист"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роли...", min_values=1, max_values=10, row=0)
        role_select.callback = self.roles_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def roles_selected(self, interaction: discord.Interaction):
        roles = self.children[0].values
        
        if hasattr(self.bot, 'security_service'):
            for role in roles:
                await self.bot.security_service.add_to_whitelist(
                    self.guild.id, role.id, "role",
                    "Добавлена через админ панель",
                    interaction.user.id
                )
            
            embed = discord.Embed(
                title="✅ Роли добавлены",
                description=f"Добавлено ролей: {len(roles)}",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис безопасности не активен",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class DangerousRolesManageView(NavigableView):
    """Управление опасными ролями"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
    
    @ui.button(label="🚩 Отметить роли", style=discord.ButtonStyle.red, row=0)
    async def mark_roles(self, interaction: discord.Interaction, button: ui.Button):
        view = DangerousRolesMarkView(self.bot, self.guild, self)
        embed = discord.Embed(
            title="🚩 Отметить опасные роли",
            description="Выберите роли для отметки как опасные",
            color=discord.Color.red()
        )
        await self.update_message(interaction, embed, view)
    
    @ui.button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
    async def back_button(self, interaction: discord.Interaction, button: ui.Button):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class DangerousRolesMarkView(NavigableView):
    """Отметка опасных ролей"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роли...", min_values=1, max_values=10, row=0)
        role_select.callback = self.roles_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def roles_selected(self, interaction: discord.Interaction):
        roles = self.children[0].values
        
        if hasattr(self.bot, 'security_service'):
            for role in roles:
                self.bot.security_service.mark_dangerous_role(
                    self.guild.id, role.id,
                    "Отмечена через админ панель",
                    interaction.user.id
                )
            
            embed = discord.Embed(
                title="✅ Роли отмечены",
                description=f"Отмечено ролей как опасные: {len(roles)}",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис безопасности не активен",
                color=discord.Color.red()
            )
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class RoleCheckView(NavigableView):
    """Проверка роли на опасные права"""
    
    def __init__(self, bot, guild, parent_view):
        super().__init__(bot)
        self.guild = guild
        self.parent_view = parent_view
        
        role_select = ui.RoleSelect(placeholder="Выберите роль для проверки...", max_values=1, row=0)
        role_select.callback = self.role_selected
        self.add_item(role_select)
        
        back_btn = ui.Button(label="◀️ Назад", style=discord.ButtonStyle.gray, row=1)
        back_btn.callback = self.go_back
        self.add_item(back_btn)
    
    async def role_selected(self, interaction: discord.Interaction):
        role = self.children[0].values[0]
        
        if not hasattr(self.bot, 'security_service'):
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Сервис безопасности не активен",
                color=discord.Color.red()
            )
            await self.update_message(interaction, embed, self)
            return
        
        is_dangerous, reason = await self.bot.security_service.check_role_dangerous(role)
        
        embed = discord.Embed(
            title=f"🔍 Проверка роли: {role.name}",
            timestamp=datetime.now()
        )
        
        if is_dangerous:
            embed.color = discord.Color.red()
            embed.add_field(name="⚠️ Результат", value="**❌ Роль имеет опасные права!**", inline=False)
            embed.add_field(name="🔴 Обнаруженные права", value=reason, inline=False)
        else:
            embed.color = discord.Color.green()
            embed.add_field(name="✅ Результат", value="Роль безопасна и не имеет опасных прав", inline=False)
        
        await self.update_message(interaction, embed, self)
    
    async def go_back(self, interaction: discord.Interaction):
        admin_view = AdminConfigView(self.bot)
        embed = await admin_view._get_security_settings_embed(self.guild)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)


class AdminCommands(commands.Cog):
    """Административные команды"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="admin", description="Открыть админ-панель")
    async def admin_panel(self, interaction: discord.Interaction):
        """Открывает интерактивную админ-панель"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка доступа",
                    description="Требуются права администратора",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        view = AdminConfigView(self.bot)
        embed = discord.Embed(
            title="⚙️ Панель администратора",
            description="Управление настройками сервера",
            color=discord.Color.blurple()
        )
        
        await interaction.response.send_message(
            embed=embed,
            view=view,
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(AdminCommands(bot))
