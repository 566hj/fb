"""
Обработчики событий сервера для FermixBot
Полный мониторинг: присоединение/выход, голосовые каналы, роли, сообщения, каналы
"""
import discord
from discord.ext import commands
import logging
from datetime import datetime
from typing import List

logger = logging.getLogger(__name__)


class EventHandlersCog(commands.Cog):
    """Обработчики событий сервера"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Обработка присоединения нового участника"""
        try:
            logger.info(f"👋 {member} присоединился к {member.guild.name}")
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_member_join(member)
            
            # Автовыдача ролей
            if hasattr(self.bot, 'autorole_service'):
                await self.bot.autorole_service.assign_roles(member)
            
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке присоединения участника: {e}")
    
    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        """Логирование выхода/кика участника"""
        try:
            logger.info(f"👋 {member} покинул {member.guild.name}")
            
            kicked = False
            moderator = None
            reason = None
            
            try:
                async for entry in member.guild.audit_logs(limit=5, action=discord.AuditLogAction.kick):
                    if entry.target.id == member.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        kicked = True
                        moderator = entry.user
                        reason = entry.reason
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                if kicked:
                    await self.bot.log_service.log_member_kick(member, moderator, reason)
                else:
                    await self.bot.log_service.log_member_leave(member)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании выхода участника: {e}")
    
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        """Логирование изменений голосового состояния"""
        try:
            if before.channel is None and after.channel is not None:
                if hasattr(self.bot, 'log_service'):
                    await self.bot.log_service.log_voice_join(member, after.channel)
            
            elif before.channel is not None and after.channel is None:
                if hasattr(self.bot, 'log_service'):
                    await self.bot.log_service.log_voice_leave(member, before.channel)
                    
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании голосового состояния: {e}")
    
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Логирование изменений участника"""
        try:
            if before.nick != after.nick:
                moderator = None
                try:
                    async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.member_update):
                        if entry.target.id == after.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                            moderator = entry.user
                            break
                except:
                    pass
                
                if hasattr(self.bot, 'log_service'):
                    await self.bot.log_service.log_member_nick_change(after, before.nick, after.nick, moderator)
            
            if before.roles != after.roles:
                added_roles = [role for role in after.roles if role not in before.roles]
                removed_roles = [role for role in before.roles if role not in after.roles]
                
                if added_roles or removed_roles:
                    moderator = None
                    try:
                        async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
                            if entry.target.id == after.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                                moderator = entry.user
                                break
                    except:
                        pass
                    
                    if hasattr(self.bot, 'log_service'):
                        await self.bot.log_service.log_member_roles_update(after, added_roles, removed_roles, moderator)
            
            if before.timed_out_until and not after.timed_out_until:
                moderator = None
                reason = None
                try:
                    async for entry in after.guild.audit_logs(limit=5, action=discord.AuditLogAction.member_update):
                        if entry.target.id == after.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                            moderator = entry.user
                            reason = entry.reason
                            break
                except:
                    pass
                
                if hasattr(self.bot, 'log_service'):
                    await self.bot.log_service.log_member_unmute(after, moderator, reason)
                    
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании изменения участника: {e}")
    
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        """Логирование удаления сообщения"""
        try:
            if message.author.bot or not message.guild:
                return
            
            logger.info(f"🗑️ Сообщение удалено от {message.author} в {message.channel}")
            
            if hasattr(self.bot, 'log_service'):
                # Попытаться найти удалителя через audit logs
                deleter = None
                try:
                    async for entry in message.guild.audit_logs(limit=5, action=discord.AuditLogAction.message_delete):
                        if entry.target.id == message.author.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                            deleter = entry.user
                            break
                except:
                    pass
                
                await self.bot.log_service.log_message_delete(message, deleter)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании удаления сообщения: {e}")
    
    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: List[discord.Message]):
        """Логирование массового удаления сообщений"""
        try:
            if not messages or not messages[0].guild:
                return
            
            channel = messages[0].channel
            logger.info(f"🧹 Массовое удаление {len(messages)} сообщений в {channel}")
            
            if hasattr(self.bot, 'log_service'):
                # Попытаться найти кто удалил
                deleter = None
                try:
                    async for entry in messages[0].guild.audit_logs(limit=5, action=discord.AuditLogAction.message_bulk_delete):
                        if (datetime.now() - entry.created_at).total_seconds() < 5:
                            deleter = entry.user
                            break
                except:
                    pass
                
                await self.bot.log_service.log_bulk_message_delete(messages, channel, deleter)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании массового удаления: {e}")
    
    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        """Логирование редактирования сообщения"""
        try:
            if before.author.bot or not before.guild or before.content == after.content:
                return
            
            logger.info(f"✏️ Сообщение отредактировано от {before.author} в {before.channel}")
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_message_edit(before, after)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании редактирования сообщения: {e}")
    
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        """Логирование создания канала"""
        try:
            logger.info(f"📝 Канал {channel.name} создан в {channel.guild.name}")
            
            moderator = None
            try:
                async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_create):
                    if entry.target.id == channel.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_channel_create(channel, moderator)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании создания канала: {e}")
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        """Логирование удаления канала"""
        try:
            logger.info(f"🗑️ Канал {channel.name} удален из {channel.guild.name}")
            
            moderator = None
            try:
                async for entry in channel.guild.audit_logs(limit=5, action=discord.AuditLogAction.channel_delete):
                    if entry.target.id == channel.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_channel_delete(channel, moderator)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании удаления канала: {e}")
    
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Логирование бана участника"""
        try:
            logger.info(f"🔨 {user} забанен на {guild.name}")
            
            moderator = None
            reason = None
            try:
                async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.ban):
                    if entry.target.id == user.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        reason = entry.reason
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_member_ban(guild, user, moderator, reason)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании бана: {e}")
    
    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        """Логирование разбана участника"""
        try:
            logger.info(f"🔓 {user} разбанен на {guild.name}")
            
            moderator = None
            reason = None
            try:
                async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.unban):
                    if entry.target.id == user.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        reason = entry.reason
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_member_unban(guild, user, moderator, reason)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании разбана: {e}")
    
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        """Логирование создания роли"""
        try:
            logger.info(f"🆕 Роль {role.name} создана в {role.guild.name}")
            
            moderator = None
            try:
                async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_create):
                    if entry.target.id == role.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_role_create(role, moderator)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании создания роли: {e}")
    
    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        """Логирование удаления роли"""
        try:
            logger.info(f"🗑️ Роль {role.name} удалена из {role.guild.name}")
            
            moderator = None
            try:
                async for entry in role.guild.audit_logs(limit=5, action=discord.AuditLogAction.role_delete):
                    if entry.target.id == role.id and (datetime.now() - entry.created_at).total_seconds() < 5:
                        moderator = entry.user
                        break
            except:
                pass
            
            if hasattr(self.bot, 'log_service'):
                await self.bot.log_service.log_role_delete(role, moderator)
        except Exception as e:
            logger.error(f"❌ Ошибка при логировании удаления роли: {e}")
    
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        """Логирование всех событий аудит-лога Discord"""
        try:
            if not hasattr(self.bot, 'log_service'):
                return
            
            guild = entry.guild
            actor = entry.user
            target = entry.target
            action = entry.action
            reason = entry.reason
            
            # Маппинг действий Discord на русские названия и эмодзи
            action_map = {
                # Действия с сервером
                discord.AuditLogAction.guild_update: ("⚙️ Обновление сервера", "GUILD_UPDATE"),
                
                # Действия с каналами
                discord.AuditLogAction.channel_create: ("➕ Создание канала", "CHANNEL_CREATE"),
                discord.AuditLogAction.channel_update: ("✏️ Обновление канала", "CHANNEL_UPDATE"),
                discord.AuditLogAction.channel_delete: ("🗑️ Удаление канала", "CHANNEL_DELETE"),
                discord.AuditLogAction.overwrite_create: ("🔐 Создание прав канала", "CHANNEL_PERMISSION_CREATE"),
                discord.AuditLogAction.overwrite_update: ("🔓 Изменение прав канала", "CHANNEL_PERMISSION_UPDATE"),
                discord.AuditLogAction.overwrite_delete: ("❌ Удаление прав канала", "CHANNEL_PERMISSION_DELETE"),
                
                # Действия с участниками
                discord.AuditLogAction.kick: ("👢 Удаление участника", "MEMBER_KICK"),
                discord.AuditLogAction.member_prune: ("🧹 Чистка участников", "MEMBER_PRUNE"),
                discord.AuditLogAction.ban: ("🔨 Бан участника", "MEMBER_BAN"),
                discord.AuditLogAction.unban: ("🔓 Возврат участника из бана", "MEMBER_UNBAN"),
                discord.AuditLogAction.member_update: ("✏️ Обновление участника", "MEMBER_UPDATE"),
                discord.AuditLogAction.member_role_update: ("🎭 Изменение ролей участника", "MEMBER_ROLE_UPDATE"),
                discord.AuditLogAction.member_move: ("🔀 Переместить участника", "MEMBER_MOVE"),
                discord.AuditLogAction.member_disconnect: ("🔇 Отключить участника", "MEMBER_DISCONNECT"),
                discord.AuditLogAction.bot_add: ("🤖 Добавить бота", "BOT_ADD"),
                
                # Действия с ветками
                discord.AuditLogAction.thread_create: ("🧵 Создать ветку", "THREAD_CREATE"),
                discord.AuditLogAction.thread_update: ("✏️ Обновить ветку", "THREAD_UPDATE"),
                discord.AuditLogAction.thread_delete: ("🗑️ Удалить ветку", "THREAD_DELETE"),
                
                # Действия с ролями
                discord.AuditLogAction.role_create: ("➕ Создание роли", "ROLE_CREATE"),
                discord.AuditLogAction.role_update: ("✏️ Обновление роли", "ROLE_UPDATE"),
                discord.AuditLogAction.role_delete: ("🗑️ Удаление роли", "ROLE_DELETE"),
                
                # Действия с приглашениями
                discord.AuditLogAction.invite_create: ("📨 Создание приглашения", "INVITE_CREATE"),
                discord.AuditLogAction.invite_update: ("✏️ Изменение приглашения", "INVITE_UPDATE"),
                discord.AuditLogAction.invite_delete: ("🗑️ Удаление приглашения", "INVITE_DELETE"),
                
                # Действия с вебхуками
                discord.AuditLogAction.webhook_create: ("🪝 Создание вебхука", "WEBHOOK_CREATE"),
                discord.AuditLogAction.webhook_update: ("✏️ Изменение вебхука", "WEBHOOK_UPDATE"),
                discord.AuditLogAction.webhook_delete: ("🗑️ Удаление вебхука", "WEBHOOK_DELETE"),
                
                # Действия с эмодзи
                discord.AuditLogAction.emoji_create: ("😀 Создание эмодзи", "EMOJI_CREATE"),
                discord.AuditLogAction.emoji_update: ("✏️ Изменение эмодзи", "EMOJI_UPDATE"),
                discord.AuditLogAction.emoji_delete: ("🗑️ Удаление эмодзи", "EMOJI_DELETE"),
                
                # Действия с сообщениями
                discord.AuditLogAction.message_delete: ("🗑️ Удаление сообщений", "MESSAGE_DELETE"),
                discord.AuditLogAction.message_bulk_delete: ("🧹 Удалить несколько сообщений", "MESSAGE_BULK_DELETE"),
                discord.AuditLogAction.message_pin: ("📌 Закрепить сообщение", "MESSAGE_PIN"),
                discord.AuditLogAction.message_unpin: ("📌 Открепить сообщение", "MESSAGE_UNPIN"),
                
                # Действия с интеграциями
                discord.AuditLogAction.integration_create: ("🔗 Создать интеграцию", "INTEGRATION_CREATE"),
                discord.AuditLogAction.integration_update: ("✏️ Обновить интеграцию", "INTEGRATION_UPDATE"),
                discord.AuditLogAction.integration_delete: ("🗑️ Удалить интеграцию", "INTEGRATION_DELETE"),
                
                # Действия со стикерами
                discord.AuditLogAction.sticker_create: ("🎨 Создать стикер", "STICKER_CREATE"),
                discord.AuditLogAction.sticker_update: ("✏️ Обновить стикер", "STICKER_UPDATE"),
                discord.AuditLogAction.sticker_delete: ("🗑️ Удалить стикер", "STICKER_DELETE"),
                
                # Действия с трибуной
                discord.AuditLogAction.stage_instance_create: ("🎙️ Открыть трибуну", "STAGE_OPEN"),
                discord.AuditLogAction.stage_instance_update: ("✏️ Обновить трибуну", "STAGE_UPDATE"),
                discord.AuditLogAction.stage_instance_delete: ("🔚 Закрыть трибуну", "STAGE_CLOSE"),
                
                # События сервера
                discord.AuditLogAction.scheduled_event_create: ("📅 Создать событие", "EVENT_CREATE"),
                discord.AuditLogAction.scheduled_event_update: ("✏️ Обновить событие", "EVENT_UPDATE"),
                discord.AuditLogAction.scheduled_event_delete: ("🗑️ Отменить событие", "EVENT_DELETE"),
                
                # Автомодерация
                discord.AuditLogAction.automod_rule_create: ("🛡️ Создать правило Автомода", "AUTOMOD_RULE_CREATE"),
                discord.AuditLogAction.automod_rule_update: ("✏️ Обновить правило Автомода", "AUTOMOD_RULE_UPDATE"),
                discord.AuditLogAction.automod_rule_delete: ("🗑️ Отменить правило Автомода", "AUTOMOD_RULE_DELETE"),
                discord.AuditLogAction.automod_block_message: ("🛑 Блокировка сообщений Автомодом", "AUTOMOD_BLOCK"),
                
                # Другие действия
                discord.AuditLogAction.app_command_permission_update: ("⚙️ Изменение прав на использование команд", "COMMAND_PERMISSION_UPDATE"),
            }
            
            # Получить информацию о действии
            if action not in action_map:
                logger.debug(f"⚠️ Неизвестное действие аудит-лога: {action}")
                return
            
            title, action_type = action_map[action]
            
            # Создать embed для лога
            embed = discord.Embed(
                title=title,
                color=self._get_action_color(action),
                timestamp=entry.created_at
            )
            
            # Добавить информацию об актёре
            if actor:
                embed.add_field(
                    name="👤 Кто изменил",
                    value=f"{actor.mention}\n`{actor}`\n`ID: {actor.id}`",
                    inline=True
                )
            
            # Добавить информацию о цели
            if target:
                target_text = self._format_target(target)
                if target_text:
                    embed.add_field(
                        name="🎯 Что затронуто",
                        value=target_text,
                        inline=True
                    )
            
            # Добавить причину
            if reason:
                embed.add_field(
                    name="📝 Причина",
                    value=reason[:1024],
                    inline=False
                )
            
            # Добавить детали изменений
            if entry.changes:
                changes_text = self._format_changes(entry.changes, action)
                if changes_text:
                    embed.add_field(
                        name="📋 Изменения",
                        value=changes_text[:1024],
                        inline=False
                    )
            
            # Дополнительная информация в зависимости от типа действия
            extra_info = self._get_extra_info(entry, action)
            if extra_info:
                embed.add_field(
                    name="ℹ️ Дополнительно",
                    value=extra_info[:1024],
                    inline=False
                )
            
            # Футер с ID
            target_id = target.id if hasattr(target, 'id') else 'N/A'
            embed.set_footer(text=f"ID: {target_id} | Действие: {entry.id}")
            
            # Отправить лог
            log_channel = await self.bot.log_service.get_log_channel(guild.id)
            if log_channel:
                await log_channel.send(embed=embed)
                logger.info(f"✅ Залогировано действие: {action_type} на {guild.name}")
            
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке события аудит-лога: {e}", exc_info=True)
    
    def _get_action_color(self, action: discord.AuditLogAction) -> discord.Color:
        """Получить цвет для типа действия"""
        # Деструктивные действия - красный
        if action in [
            discord.AuditLogAction.ban, discord.AuditLogAction.kick,
            discord.AuditLogAction.channel_delete, discord.AuditLogAction.role_delete,
            discord.AuditLogAction.member_prune, discord.AuditLogAction.message_delete,
            discord.AuditLogAction.message_bulk_delete, discord.AuditLogAction.emoji_delete,
            discord.AuditLogAction.webhook_delete, discord.AuditLogAction.integration_delete,
            discord.AuditLogAction.sticker_delete, discord.AuditLogAction.thread_delete,
            discord.AuditLogAction.scheduled_event_delete, discord.AuditLogAction.automod_rule_delete
        ]:
            return discord.Color.red()
        
        # Создание - зелёный
        if action in [
            discord.AuditLogAction.channel_create, discord.AuditLogAction.role_create,
            discord.AuditLogAction.emoji_create, discord.AuditLogAction.webhook_create,
            discord.AuditLogAction.integration_create, discord.AuditLogAction.sticker_create,
            discord.AuditLogAction.invite_create, discord.AuditLogAction.thread_create,
            discord.AuditLogAction.stage_instance_create, discord.AuditLogAction.scheduled_event_create,
            discord.AuditLogAction.automod_rule_create, discord.AuditLogAction.bot_add,
            discord.AuditLogAction.unban
        ]:
            return discord.Color.green()
        
        # Обновление - синий
        if action in [
            discord.AuditLogAction.channel_update, discord.AuditLogAction.role_update,
            discord.AuditLogAction.guild_update, discord.AuditLogAction.member_update,
            discord.AuditLogAction.member_role_update, discord.AuditLogAction.emoji_update,
            discord.AuditLogAction.webhook_update, discord.AuditLogAction.integration_update,
            discord.AuditLogAction.sticker_update, discord.AuditLogAction.invite_update,
            discord.AuditLogAction.thread_update, discord.AuditLogAction.stage_instance_update,
            discord.AuditLogAction.scheduled_event_update, discord.AuditLogAction.automod_rule_update
        ]:
            return discord.Color.blue()
        
        # Модерация - оранжевый
        if action in [
            discord.AuditLogAction.overwrite_create, discord.AuditLogAction.overwrite_update,
            discord.AuditLogAction.overwrite_delete, discord.AuditLogAction.member_move,
            discord.AuditLogAction.member_disconnect, discord.AuditLogAction.automod_block_message,
            discord.AuditLogAction.app_command_permission_update
        ]:
            return discord.Color.orange()
        
        # Сообщения - фиолетовый
        if action in [
            discord.AuditLogAction.message_pin, discord.AuditLogAction.message_unpin
        ]:
            return discord.Color.purple()
        
        # По умолчанию - серый
        return discord.Color.greyple()
    
    def _format_target(self, target) -> str:
        """Форматировать информацию о цели действия"""
        if isinstance(target, (discord.User, discord.Member)):
            return f"{target.mention}\n`{target}`\n`ID: {target.id}`"
        elif isinstance(target, discord.Role):
            return f"{target.mention}\n`{target.name}`\n`ID: {target.id}`"
        elif isinstance(target, (discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel, discord.ForumChannel, discord.StageChannel)):
            mention = getattr(target, 'mention', f'`{target.name}`')
            return f"{mention}\n`{target.name}`\n`ID: {target.id}`"
        elif isinstance(target, discord.Invite):
            return f"Код: `{target.code}`\nКанал: {target.channel.mention if target.channel else 'Неизвестно'}"
        elif isinstance(target, discord.Emoji):
            return f"{target}\n`{target.name}`\n`ID: {target.id}`"
        elif isinstance(target, discord.Webhook):
            return f"`{target.name}`\n`ID: {target.id}`"
        elif hasattr(target, 'name') and hasattr(target, 'id'):
            return f"`{target.name}`\n`ID: {target.id}`"
        else:
            return f"`{str(target)[:100]}`"
    
    def _format_changes(self, changes, action: discord.AuditLogAction) -> str:
        """Форматировать изменения из аудит-лога"""
        lines = []
        
        for change in changes:
            key = change.key
            before = change.before
            after = change.after
            
            # Пропустить некоторые изменения для краткости
            if key in ['_avatar_decoration_data', 'avatar_decoration_data']:
                continue
            
            # Перевести ключи на русский
            key_translation = {
                'name': 'Имя',
                'nick': 'Никнейм',
                'topic': 'Тема',
                'position': 'Позиция',
                'color': 'Цвет',
                'hoist': 'Отображать отдельно',
                'mentionable': 'Упоминаемая',
                'permissions': 'Права',
                'allow': 'Разрешить',
                'deny': 'Запретить',
                'type': 'Тип',
                'nsfw': 'NSFW',
                'bitrate': 'Битрейт',
                'user_limit': 'Лимит участников',
                'slowmode': 'Медленный режим',
                'region': 'Регион',
                'afk_timeout': 'Таймаут AFK',
                'afk_channel': 'AFK канал',
                'system_channel': 'Системный канал',
                'verification_level': 'Уровень верификации',
                'default_notifications': 'Уведомления по умолчанию',
                'explicit_content_filter': 'Фильтр контента',
                'mfa_level': '2FA уровень',
                'icon': 'Иконка',
                'banner': 'Баннер',
                'splash': 'Заставка',
                'description': 'Описание',
                'preferred_locale': 'Язык',
                'premium_progress_bar_enabled': 'Прогресс буст',
                'reason': 'Причина',
                '$add': 'Добавлено',
                '$remove': 'Удалено',
                'deaf': 'Оглушён',
                'mute': 'Заглушён',
                'roles': 'Роли',
                'communication_disabled_until': 'Тайм-аут до',
            }
            
            key_name = key_translation.get(key, key)
            
            # Форматировать значения
            if before is not None and after is not None:
                before_str = self._format_value(before, key)
                after_str = self._format_value(after, key)
                lines.append(f"**{key_name}:** `{before_str}` → `{after_str}`")
            elif before is not None:
                before_str = self._format_value(before, key)
                lines.append(f"**{key_name}:** `{before_str}` → *удалено*")
            elif after is not None:
                after_str = self._format_value(after, key)
                lines.append(f"**{key_name}:** *не было* → `{after_str}`")
        
        return "\n".join(lines[:10])  # Лимит 10 строк
    
    def _format_value(self, value, key: str) -> str:
        """Форматировать значение для отображения"""
        if value is None:
            return "Нет"
        elif isinstance(value, bool):
            return "Да" if value else "Нет"
        elif isinstance(value, (discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel)):
            return f"#{value.name}"
        elif isinstance(value, discord.Role):
            return f"@{value.name}"
        elif isinstance(value, list):
            if len(value) == 0:
                return "Нет"
            if isinstance(value[0], discord.Role):
                return ", ".join([f"@{r.name}" for r in value[:5]])
            return ", ".join([str(v)[:50] for v in value[:5]])
        elif key == 'color':
            return str(value)
        elif key in ['bitrate', 'user_limit', 'slowmode', 'afk_timeout']:
            return str(value)
        elif isinstance(value, str) and len(value) > 100:
            return value[:97] + "..."
        else:
            return str(value)[:100]
    
    def _get_extra_info(self, entry: discord.AuditLogEntry, action: discord.AuditLogAction) -> str:
        """Получить дополнительную информацию о действии"""
        info = []
        
        # Количество удалённых сообщений
        if action == discord.AuditLogAction.message_bulk_delete:
            if hasattr(entry, 'extra') and hasattr(entry.extra, 'count'):
                info.append(f"Удалено сообщений: **{entry.extra.count}**")
        
        # Информация о чистке участников
        if action == discord.AuditLogAction.member_prune:
            if hasattr(entry, 'extra'):
                if hasattr(entry.extra, 'delete_member_days'):
                    info.append(f"Неактивность: **{entry.extra.delete_member_days} дней**")
                if hasattr(entry.extra, 'members_removed'):
                    info.append(f"Удалено участников: **{entry.extra.members_removed}**")
        
        # Информация о перемещении участников
        if action == discord.AuditLogAction.member_move:
            if hasattr(entry, 'extra'):
                if hasattr(entry.extra, 'count'):
                    info.append(f"Перемещено участников: **{entry.extra.count}**")
                if hasattr(entry.extra, 'channel'):
                    info.append(f"В канал: {entry.extra.channel.mention}")
        
        # Информация о отключении участников
        if action == discord.AuditLogAction.member_disconnect:
            if hasattr(entry, 'extra') and hasattr(entry.extra, 'count'):
                info.append(f"Отключено участников: **{entry.extra.count}**")
        
        # Длительность приглашения
        if action in [discord.AuditLogAction.invite_create, discord.AuditLogAction.invite_update]:
            if hasattr(entry, 'extra'):
                if hasattr(entry.extra, 'max_age'):
                    max_age = entry.extra.max_age
                    if max_age == 0:
                        info.append("Срок действия: **Бессрочно**")
                    else:
                        info.append(f"Срок действия: **{max_age // 3600} часов**")
                if hasattr(entry.extra, 'max_uses'):
                    max_uses = entry.extra.max_uses
                    if max_uses == 0:
                        info.append("Макс. использований: **Неограничено**")
                    else:
                        info.append(f"Макс. использований: **{max_uses}**")
        
        return "\n".join(info) if info else None
    
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Обработка сообщений для начисления XP и обработки ЛС для тикетов"""
        try:
            # Проверка на ЛС (для тикетов)
            if not message.guild and not message.author.bot:
                # Попытаться обработать как сообщение в тикет
                if hasattr(self.bot, 'ticket_service'):
                    handled = await self.bot.ticket_service.handle_dm_message(message)
                    if handled:
                        return
            
            # Игнорировать ботов и ЛС для системы уровней
            if message.author.bot or not message.guild:
                return
            
            # Начислить XP
            if hasattr(self.bot, 'leveling_service'):
                result = await self.bot.leveling_service.add_xp(message.author)
                
                if result:
                    old_level, new_level, new_xp = result
                    
                    # Проверить повышение уровня
                    if new_level > old_level:
                        await self.bot.leveling_service.check_level_up(message.author, old_level, new_level)
                        
                        # Логировать повышение уровня
                        if hasattr(self.bot, 'log_service'):
                            details = {
                                "Пользователь": message.author.mention,
                                "Старый уровень": str(old_level),
                                "Новый уровень": str(new_level),
                                "Опыт": str(new_xp)
                            }
                            
                            await self.bot.log_service.log_action(
                                message.guild.id,
                                message.author.id,
                                "LEVEL_UP",
                                message.author.id,
                                None,
                                details
                            )
        except Exception as e:
            logger.error(f"❌ Ошибка при обработке сообщения: {e}")


async def setup(bot):
    await bot.add_cog(EventHandlersCog(bot))
