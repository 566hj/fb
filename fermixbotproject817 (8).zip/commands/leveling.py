"""
Leveling commands for FermixBot
Команды для системы уровней
"""
import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)


class LevelingCog(commands.Cog):
    """Команды системы уровней"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="rank", description="Показать ваш уровень и прогресс")
    @app_commands.describe(member="Участник для проверки (по умолчанию: вы)")
    async def rank(self, interaction: discord.Interaction, member: discord.Member = None):
        """Показать уровень и прогресс участника"""
        if not member:
            member = interaction.user
        
        if not hasattr(self.bot, 'leveling_service'):
            await interaction.response.send_message("❌ Система уровней не активна.", ephemeral=True)
            return
        
        stats = self.bot.leveling_service.get_user_stats(interaction.guild_id, member.id)
        
        current_level, xp_in_level, xp_to_next = self.bot.leveling_service.get_xp_for_next_level(stats["xp"])
        
        # Создать прогресс бар
        progress = int((xp_in_level / xp_to_next) * 20) if xp_to_next > 0 else 20
        progress_bar = "█" * progress + "░" * (20 - progress)
        
        embed = discord.Embed(
            title=f"📊 Статистика {member.display_name}",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="🎖️ Уровень", value=f"**{current_level}**", inline=True)
        embed.add_field(name="🏆 Ранг", value=f"**#{stats['rank']}**" if stats['rank'] else "N/A", inline=True)
        embed.add_field(name="💎 Опыт", value=f"**{stats['xp']}**", inline=True)
        
        if current_level < 50:
            embed.add_field(
                name="📈 Прогресс до следующего уровня",
                value=f"{progress_bar}\n`{xp_in_level}/{xp_to_next} XP`",
                inline=False
            )
        else:
            embed.add_field(
                name="🌟 Максимальный уровень!",
                value="Вы достигли максимального уровня 50!",
                inline=False
            )
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="leaderboard", description="Показать таблицу лидеров по уровням")
    async def leaderboard(self, interaction: discord.Interaction):
        """Показать топ участников по уровням"""
        if not hasattr(self.bot, 'leveling_service'):
            await interaction.response.send_message("❌ Система уровней не активна.", ephemeral=True)
            return
        
        leaders = self.bot.leveling_service.get_leaderboard(interaction.guild_id, limit=10)
        
        if not leaders:
            await interaction.response.send_message("📊 Нет данных по уровням.", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🏆 Таблица лидеров по уровням",
            description=f"Топ {len(leaders)} участников сервера",
            color=discord.Color.gold()
        )
        
        for idx, leader in enumerate(leaders, 1):
            member = interaction.guild.get_member(leader['user_id'])
            name = member.display_name if member else f"Пользователь {leader['user_id']}"
            
            medal = ""
            if idx == 1:
                medal = "🥇"
            elif idx == 2:
                medal = "🥈"
            elif idx == 3:
                medal = "🥉"
            else:
                medal = f"`#{idx}`"
            
            embed.add_field(
                name=f"{medal} {name}",
                value=f"Уровень: **{leader['level']}** | XP: **{leader['xp']}**",
                inline=False
            )
        
        await interaction.response.send_message(embed=embed)


async def setup(bot):
    await bot.add_cog(LevelingCog(bot))
