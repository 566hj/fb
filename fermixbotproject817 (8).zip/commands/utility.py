"""
Utility commands for FermixBot
"""
import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)


class UtilityCog(commands.Cog):
    """Utility commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ping", description="Check bot latency")
    async def ping(self, interaction: discord.Interaction):
        """Check bot ping"""
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"**Latency:** {latency}ms",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="help", description="Show help message")
    async def help(self, interaction: discord.Interaction):
        """Show help"""
        embed = discord.Embed(
            title="📚 FermixBot Help",
            description="Advanced Discord moderation bot",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="Moderation Commands",
            value="/mute - Mute a user\n/unmute - Unmute a user\n/warn - Warn a user\n/warnings - Check user warnings",
            inline=False
        )
        embed.add_field(
            name="Utility Commands",
            value="/ping - Check latency\n/help - Show this message",
            inline=False
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(UtilityCog(bot))
