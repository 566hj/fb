"""
Команда помощи для FermixBot со всеми командами
Русский интерфейс, навигация через кнопки
"""
import discord
from discord.ext import commands
from discord import app_commands, ui
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class HelpView(ui.View):
    """Кнопки для навигации по разделам помощи"""
    
    def __init__(self, bot):
        super().__init__(timeout=300)
        self.bot = bot
    
    @ui.button(label="🛡️ Модерация", style=discord.ButtonStyle.primary)
    async def moderation_help(self, interaction: discord.Interaction, button: ui.Button):
        """Показать команды модерации"""
        embed = discord.Embed(
            title="🛡️ Команды модерации",
            description="Все команды для управления пользователями",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.add_field(
            name="/модерация @пользователь",
            value="Открыть интерактивную панель модерации для пользователя\n"
                  "💪 **Требуется:** Управление ролями + Управление сообщениями",
            inline=False
        )
        embed.add_field(
            name="/очистить",
            value="Удалить последние сообщения из канала (1-100)\n"
                  "💪 **Требуется:** Управление сообщениями",
            inline=False
        )
        embed.add_field(
            name="📋 Действия в панели модерации:",
            value="🔇 **Мут** - Добавить пользователя в мут на определенное время\n"
                  "🔊 **Размут** - Снять мут с пользователя\n"
                  "⚠️ **Предупреждение** - Выдать предупреждение пользователю\n"
                  "📋 **История** - Просмотреть историю предупреждений",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @ui.button(label="⚙️ Админ-панель", style=discord.ButtonStyle.success)
    async def admin_help(self, interaction: discord.Interaction, button: ui.Button):
        """Показать команды админ-панели"""
        embed = discord.Embed(
            title="⚙️ Команды администратора",
            description="Все команды для конфигурации сервера",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(
            name="/админ",
            value="Открыть главную админ-панель с двумя разделами\n"
                  "💪 **Требуется:** Администратор",
            inline=False
        )
        embed.add_field(
            name="📋 Конфигурация:",
            value="⚙️ **Установить роль мута** - Выбрать роль для мутов\n"
                  "📝 **Установить канал логов** - Выбрать канал для логирования действий\n"
                  "👮 **Роли модерации** - Выбрать роли с доступом к модерации\n"
                  "🔧 **Создать роль мута** - Автоматически создать и настроить роль",
            inline=False
        )
        embed.add_field(
            name="📊 Мониторинг:",
            value="📊 **Статистика** - Просмотреть статистику сервера\n"
                  "⚠️ **Нарушения пользователя** - Проверить историю нарушений\n"
                  "📋 **Недавние действия** - Просмотреть лог модерации\n"
                  "🟢 **Статус бота** - Проверить здоровье и статус бота",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @ui.button(label="🛡️ Безопасность", style=discord.ButtonStyle.danger)
    async def security_help(self, interaction: discord.Interaction, button: ui.Button):
        """Показать команды безопасности"""
        embed = discord.Embed(
            title="🛡️ Команды безопасности",
            description="Все команды для защиты сервера",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        embed.add_field(
            name="/безопасность",
            value="Открыть центр управления безопасностью\n"
                  "💪 **Требуется:** Администратор",
            inline=False
        )
        embed.add_field(
            name="📋 Возможности:",
            value="⚙️ **Настройка** - Изменить пороги обнаружения спама/рейда/нука\n"
                  "🚩 **Опасные роли** - Отметить роли с опасными правами через выбор\n"
                  "🛡️ **Вайтлист** - Защитить пользователей и роли от проверок\n"
                  "📊 **Статистика** - Просмотреть инциденты за последние 24 часа",
            inline=False
        )
        embed.add_field(
            name="/проверить_роль @роль",
            value="Проверить роль на опасные права (администратор, управление сервером и т.д.)\n"
                  "💪 **Требуется:** Администратор",
            inline=False
        )
        embed.add_field(
            name="🛡️ Что отслеживает система:",
            value="🔴 **Администратор** - Полный доступ к серверу\n"
                  "🔴 **Управление сервером** - Изменение названия, иконки, региона\n"
                  "🔴 **Управление ролями** - Создание/удаление/изменение ролей\n"
                  "🔴 **Управление каналами** - Создание/удаление/изменение каналов\n"
                  "🔴 **Кик участников** - Исключение членов сервера\n"
                  "🔴 **Бан участников** - Перманентное исключение\n"
                  "🔴 **Отслеживание аудита** - Просмотр логов сервера\n"
                  "⚠️ **Спам** - Более 5 сообщений в секунду\n"
                  "⚠️ **Рейд** - Более 5 присоединений в минуту\n"
                  "⚠️ **Нук** - Более 3 созданий/удалений ролей или каналов",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @ui.button(label="❓ Общее", style=discord.ButtonStyle.secondary)
    async def general_help(self, interaction: discord.Interaction, button: ui.Button):
        """Показать общую информацию"""
        embed = discord.Embed(
            title="❓ Общая информация",
            description="FermixBot - продвинутый Discord бот для модерации и безопасности",
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        embed.add_field(
            name="📋 Что может делать FermixBot?",
            value="✅ Управление мутами с автоматическим размутом\n"
                  "✅ Система предупреждений для пользователей\n"
                  "✅ Автоматическое логирование всех действий\n"
                  "✅ Защита от спама, рейдов и нуков\n"
                  "✅ Отслеживание опасных ролей и прав\n"
                  "✅ Вайтлист для защиты важных пользователей и ролей",
            inline=False
        )
        embed.add_field(
            name="🔧 Требования для использования",
            value="🤖 Бот должен быть выше по иерархии ролей, чем целевой пользователь\n"
                  "📝 Канал логов должен быть выбран в админ-панели\n"
                  "🎖️ Роль мута должна быть установлена для функции мутов\n"
                  "👮 Роли модерации должны быть назначены для доступа",
            inline=False
        )
        embed.add_field(
            name="🚀 Быстрый старт",
            value="1️⃣ Введите `/админ` и откройте конфигурацию\n"
                  "2️⃣ Установите роль мута и канал логов\n"
                  "3️⃣ Назначьте роли модерации нужным администраторам\n"
                  "4️⃣ Откройте `/безопасность` для защиты сервера\n"
                  "5️⃣ Используйте `/модерация` для управления пользователями",
            inline=False
        )
        embed.add_field(
            name="💬 Поддержка",
            value="При возникновении ошибок проверьте:\n"
                  "• Установлены ли роль мута и канал логов\n"
                  "• Есть ли у бота необходимые права на сервере\n"
                  "• Находится ли целевой пользователь ниже бота по иерархии",
            inline=False
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url if self.bot.user else None)
        
        await interaction.response.send_message(embed=embed, view=self, ephemeral=True)
    
    @ui.button(label="🎫 Тикеты", style=discord.ButtonStyle.success, row=1)
    async def tickets_help(self, interaction: discord.Interaction, button: ui.Button):
        """Показать команды тикетов"""
        embed = discord.Embed(
            title="🎫 Система тикетов поддержки",
            description="Полная система поддержки с общением через ЛС",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(
            name="/ticket-setup",
            value="Настроить систему тикетов: категория, роль поддержки, канал транскриптов\n"
                  "💪 **Требуется:** Администратор",
            inline=False
        )
        embed.add_field(
            name="/ticket-panel",
            value="Создать панель с кнопками для открытия тикетов\n"
                  "💪 **Требуется:** Администратор",
            inline=False
        )
        embed.add_field(
            name="📋 Типы тикетов:",
            value="🔧 **Техническая поддержка** - Проблемы с сервером\n"
                  "💳 **Поддержка по донатам** - Вопросы о покупках\n"
                  "📜 **Апелляция** - Обжалование блокировки\n"
                  "🎮 **Жалоба на игру** - Нарушения в игре\n"
                  "💬 **Жалоба на Discord** - Нарушения в Discord\n"
                  "⚠️ **Жалоба на администрацию** - Жалобы на админов",
            inline=False
        )
        embed.add_field(
            name="🎛️ Управление тикетами:",
            value="✋ **Взять на разбор** - Взять тикет в работу\n"
                  "❌ **Отказаться от разбора** - Вернуть тикет в очередь\n"
                  "🔄 **Передать тикет** - Передать другому сотруднику\n"
                  "➕ **Добавить участника** - Добавить кого-то в тикет\n"
                  "📋 **Сохранить транскрипт** - Скачать диалог до закрытия\n"
                  "🔒 **Закрыть тикет** - Завершить разбор",
            inline=False
        )
        embed.add_field(
            name="💬 Общение:",
            value="Все общение происходит через ЛС с ботом.\n"
                  "Пользователь не имеет доступа к каналу тикета.\n"
                  "Сообщения автоматически пересылаются в обе стороны.\n"
                  "Транскрипт сохраняется в отдельный канал и отправляется пользователю.",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)


class HelpCog(commands.Cog):
    """Команда помощи"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="помощь", description="Справка по командам FermixBot")
    async def help_command(self, interaction: discord.Interaction):
        """Показать справку по всем командам"""
        
        embed = discord.Embed(
            title="📚 Справка по FermixBot",
            description="Выберите раздел для получения информации о командах",
            color=discord.Color.blurple(),
            timestamp=datetime.now()
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url if self.bot.user else None)
        embed.add_field(
            name="📋 Разделы:",
            value="🛡️ **Модерация** - Команды управления пользователями\n"
                  "⚙️ **Админ-панель** - Команды конфигурации сервера\n"
                  "🛡️ **Безопасность** - Команды защиты от атак\n"
                  "❓ **Общее** - Информация о боте и быстрый старт\n"
                  "🎫 **Тикеты** - Система поддержки с общением через ЛС",
            inline=False
        )
        
        view = HelpView(self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        logger.info(f"📚 Справка открыта пользователем {interaction.user} на сервере {interaction.guild}")


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
