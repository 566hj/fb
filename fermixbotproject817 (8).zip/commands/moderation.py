"""
Команды модерации для FermixBot
Интерактивная система с кнопками и модальными окнами
"""
import discord
from discord.ext import commands
from discord import app_commands, ui
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class PurgeModal(ui.Modal):
    """Модальное окно для ввода количества сообщений"""
    count = ui.TextInput(
        label="Количество сообщений",
        placeholder="10",
        default="10",
        min_length=1,
        max_length=4
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        try:
            count = int(self.count.value)
            if count < 1 or count > 100:
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="❌ Ошибка",
                        description="Количество должно быть от 1 до 100",
                        color=discord.Color.red()
                    ),
                    ephemeral=True
                )
                return
            
            # Delete messages
            deleted = 0
            async for message in interaction.channel.history(limit=count):
                try:
                    await message.delete()
                    deleted += 1
                except discord.Forbidden:
                    break
                except discord.HTTPException:
                    continue
            
            await interaction.client.log_service.log_action(
                interaction.guild.id,
                interaction.user.id,
                "CLEANUP",
                None,
                f"Удалено {deleted} сообщений в {interaction.channel.mention}",
                {
                    "Канал": interaction.channel.mention,
                    "Сообщений удалено": str(deleted)
                }
            )
            
            logger.info(f"🧹 Удалено {deleted} сообщений в {interaction.channel} на сервере {interaction.guild}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="🗑️ Сообщения удалены",
                    description=f"Удалено сообщений: {deleted}",
                    color=discord.Color.orange(),
                    timestamp=datetime.now()
                )
            )
            
        except ValueError:
            await interaction.followup.send(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Введите корректное число",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"❌ Ошибка при очистке: {e}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description=f"Произошла ошибка: {e}",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )


class MuteModal(ui.Modal):
    """Модальное окно для ввода деталей мута"""
    duration = ui.TextInput(
        label="Длительность (в минутах)",
        placeholder="0 = постоянный мут",
        default="10",
        min_length=1,
        max_length=5
    )
    reason = ui.TextInput(
        label="Причина",
        placeholder="Причина мута...",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=200
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        target_user = self.target_user
        bot = self.bot
        guild = interaction.guild
        
        try:
            duration = int(self.duration.value)
            reason = self.reason.value or "Причина не указана"
            
            # Check if user is already muted
            active_mute = await bot.mute_service.get_active_mute(target_user.id, guild.id)
            if active_mute:
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="❌ Ошибка",
                        description=f"{target_user.mention} уже в муте",
                        color=discord.Color.red()
                    ),
                    ephemeral=True
                )
                return
            
            # Mute user
            success = await bot.mute_service.mute_user(
                target_user.id, guild.id, duration, reason, interaction.user.id
            )
            
            if success:
                duration_text = f"{duration} минут" if duration > 0 else "постоянный"
                
                await interaction.client.log_service.log_action(
                    guild.id,
                    interaction.user.id,
                    "MUTE",
                    target_user.id,
                    reason,
                    {
                        "Длительность": duration_text,
                        "Модератор": interaction.user.mention
                    }
                )
                
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="🔇 Пользователь добавлен в мут",
                        description=f"{target_user.mention} добавлен в мут на {duration_text}",
                        color=discord.Color.orange(),
                        timestamp=datetime.now()
                    ).add_field(name="📝 Причина", value=reason, inline=False)
                )
                logger.info(f"✅ Пользователь {target_user} добавлен в мут на {duration_text}")
            else:
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="❌ Ошибка",
                        description="Не удалось добавить пользователя в мут",
                        color=discord.Color.red()
                    ),
                    ephemeral=True
                )
        except ValueError:
            await interaction.followup.send(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Длительность должна быть числом",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"❌ Ошибка при муте: {e}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description=f"Произошла ошибка: {e}",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )


class WarnModal(ui.Modal):
    """Модальное окно для ввода причины предупреждения"""
    reason = ui.TextInput(
        label="Причина предупреждения",
        placeholder="Причина...",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=200
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        target_user = self.target_user
        bot = self.bot
        guild = interaction.guild
        reason = self.reason.value or "Причина не указана"
        
        try:
            success = await bot.moderation_service.warn_user(
                target_user.id, guild.id, reason, interaction.user.id
            )
            
            if success:
                await interaction.client.log_service.log_action(
                    guild.id,
                    interaction.user.id,
                    "WARN",
                    target_user.id,
                    reason,
                    {
                        "Модератор": interaction.user.mention,
                        "Статус": "Предупреждение выдано"
                    }
                )
                
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="⚠️ Пользователь получил предупреждение",
                        description=f"{target_user.mention} получил предупреждение",
                        color=discord.Color.yellow(),
                        timestamp=datetime.now()
                    ).add_field(name="📝 Причина", value=reason, inline=False)
                )
                logger.info(f"✅ Пользователю {target_user} дано предупреждение")
            else:
                await interaction.followup.send(
                    embed=discord.Embed(
                        title="❌ Ошибка",
                        description="Не удалось выдать предупреждение",
                        color=discord.Color.red()
                    ),
                    ephemeral=True
                )
        except Exception as e:
            logger.error(f"❌ Ошибка при выдаче предупреждения: {e}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description=f"Произошла ошибка: {e}",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )


class ModerationView(ui.View):
    """Кнопки для модерации пользователя"""
    
    def __init__(self, target_user: discord.Member, bot):
        super().__init__(timeout=300)
        self.target_user = target_user
        self.bot = bot
    
    @ui.button(label="🔇 Мут", style=discord.ButtonStyle.danger)
    async def mute_button(self, interaction: discord.Interaction, button: ui.Button):
        """Кнопка для открытия окна мута"""
        if not interaction.user.guild_permissions.manage_roles:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="У вас нет прав для использования этой команды",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        modal = MuteModal(title="Добавить в мут")
        modal.target_user = self.target_user
        modal.bot = self.bot
        await interaction.response.send_modal(modal)
    
    @ui.button(label="🔊 Размут", style=discord.ButtonStyle.success)
    async def unmute_button(self, interaction: discord.Interaction, button: ui.Button):
        """Кнопка для размута"""
        if not interaction.user.guild_permissions.manage_roles:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="У вас нет прав для использования этой команды",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        active_mute = await self.bot.mute_service.get_active_mute(self.target_user.id, interaction.guild.id)
        if not active_mute:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description=f"{self.target_user.mention} не в муте",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        success = await self.bot.mute_service.unmute_user(self.target_user.id, interaction.guild.id)
        
        if success:
            await self.bot.log_service.log_action(
                interaction.guild.id,
                interaction.user.id,
                "UNMUTE",
                self.target_user.id,
                "Мут снят модератором",
                {
                    "Модератор": interaction.user.mention,
                    "Статус": "Мут успешно снят"
                }
            )
            
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="🔊 Мут снят",
                    description=f"{self.target_user.mention} удален из мута",
                    color=discord.Color.green(),
                    timestamp=datetime.now()
                )
            )
            logger.info(f"✅ С пользователя {self.target_user} снят мут")
        else:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось снять мут",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
    
    @ui.button(label="⚠️ Предупреждение", style=discord.ButtonStyle.primary)
    async def warn_button(self, interaction: discord.Interaction, button: ui.Button):
        """Кнопка для открытия окна предупреждения"""
        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="У вас нет прав для использования этой команды",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        modal = WarnModal(title="Выдать предупреждение")
        modal.target_user = self.target_user
        modal.bot = self.bot
        await interaction.response.send_modal(modal)
    
    @ui.button(label="📋 История", style=discord.ButtonStyle.blurple)
    async def history_button(self, interaction: discord.Interaction, button: ui.Button):
        """Кнопка для просмотра истории"""
        if not interaction.user.guild_permissions.manage_messages:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="У вас нет прав для использования этой команды",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        warnings = await self.bot.moderation_service.get_warnings(self.target_user.id, interaction.guild.id)
        
        embed = discord.Embed(
            title=f"⚠️ Предупреждения для {self.target_user.display_name}",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        
        if warnings:
            for i, warn in enumerate(warnings[:10], 1):
                embed.add_field(
                    name=f"#{i}",
                    value=f"**Причина:** {warn['reason']}\n**Дата:** {warn['created_at']}",
                    inline=False
                )
            embed.set_footer(text=f"Всего: {len(warnings)} предупреждений")
        else:
            embed.description = "✅ Нет предупреждений"
        
        await interaction.response.send_message(embed=embed, ephemeral=True)


class ModerationCog(commands.Cog):
    """Команды модерации"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="модерация", description="Открыть панель модерации для пользователя")
    @app_commands.describe(user="Пользователь для модерации")
    @app_commands.checks.has_permissions(manage_roles=True, manage_messages=True)
    async def moderation_panel(self, interaction: discord.Interaction, user: discord.Member):
        """Открыть интерактивную панель модерации"""
        
        if user == interaction.user:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Вы не можете модерировать себя!",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        if user.bot:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Ошибка",
                    description="Вы не можете модерировать бота!",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title=f"🛡️ Панель модерации",
            description=f"Выберите действие для {user.mention}",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.add_field(name="👤 Пользователь", value=user.mention, inline=True)
        embed.add_field(name="🆔 ID", value=user.id, inline=True)
        embed.add_field(name="📅 На сервере с", value=discord.utils.format_dt(user.joined_at, style='R'), inline=False)
        
        view = ModerationView(user, self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
        logger.info(f"🛡️ Открыта панель модерации для {user}")
    
    @app_commands.command(name="очистить", description="Удалить последние сообщения из канала")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction):
        """Открыть окно для ввода количества сообщений для удаления"""
        
        modal = PurgeModal(title="🗑️ Очистить канал")
        await interaction.response.send_modal(modal)
        logger.info(f"🗑️ Команда очистить использована на {interaction.channel} на сервере {interaction.guild}")


async def setup(bot):
    await bot.add_cog(ModerationCog(bot))
