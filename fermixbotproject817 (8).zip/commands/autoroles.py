"""
Auto-role commands for FermixBot
Команды для автоматической выдачи ролей
"""
import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)


class AutoRoleCog(commands.Cog):
    """Команды автовыдачи ролей"""
    
    def __init__(self, bot):
        self.bot = bot
    


async def setup(bot):
    await bot.add_cog(AutoRoleCog(bot))
