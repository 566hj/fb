"""
FermixBot - Advanced Discord Moderation Bot
Main entry point for the bot with complete module loading
"""
import discord
from discord.ext import commands
import os
import logging
import asyncio
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.StreamHandler(),  # Console handler
        logging.FileHandler('data/bot.log', encoding='utf-8', mode='a')  # File handler
    ]
)
logger = logging.getLogger(__name__)

logging.getLogger('discord').setLevel(logging.WARNING)
logging.getLogger('discord.http').setLevel(logging.WARNING)
logging.getLogger('discord.gateway').setLevel(logging.INFO)

# Import core services
from services.database import Database
from services.moderation import ModerationService
from services.mute import MuteService
from services.extended import ExtendedService
from services.logging import LogService
from services.access import AccessService
from services.security import SecurityService
from services.backup import BackupService
from services.threat_response import ThreatResponseService
# Import новых сервисов
from services.leveling import LevelingService
from services.autorole import AutoRoleService
from services.tickets import TicketService


class FermixBot(commands.Bot):
    """Main bot class with all services initialized"""
    
    def __init__(self):
        intents = discord.Intents.all()
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        
        # Initialize services
        self.db = Database()
        self.moderation_service = ModerationService(self.db)
        self.mute_service = MuteService(self.db, self)
        self.extended_service = ExtendedService(self.db)
        self.log_service = LogService(self, self.db)
        self.access_service = AccessService(self.db)
        self.security_service = SecurityService(self.db, self)
        
        self.backup_service = BackupService(self.db, self)
        self.threat_response_service = ThreatResponseService(self.db, self, self.security_service)
        
        # Initialize новых сервисов
        self.leveling_service = LevelingService(self.db, self)
        self.autorole_service = AutoRoleService(self.db, self)
        self.ticket_service = TicketService(self.db, self)
        
        # Track loaded cogs
        self.loaded_cogs = []
    
    async def setup_hook(self):
        """Load all cogs and modules on startup"""
        try:
            logger.info("=" * 60)
            logger.info("🚀 Начало инициализации FermixBot")
            logger.info("=" * 60)
            
            modules_to_load = [
                ("commands.moderation", "moderation", "Команды модерации"),
                ("commands.utility", "utility", "Утилиты"),
                ("commands.security", "security", "Функции безопасности"),
                ("commands.admin", "admin", "Админ-панель"),
                ("commands.events", "events", "Обработчики событий"),
                ("commands.tickets", "tickets", "Система тикетов"),
                ("commands.leveling", "leveling", "Система уровней"),
                ("commands.autoroles", "autoroles", "Система автовыдачи ролей"),
                ("commands.backup", "backup", "Система резервного копирования"),
            ]
            
            for extension, cog_name, display_name in modules_to_load:
                try:
                    await self.load_extension(extension)
                    self.loaded_cogs.append(cog_name)
                    logger.info(f"✅ {display_name} загружены")
                except Exception as e:
                    logger.error(f"❌ Ошибка загрузки {display_name}: {e}", exc_info=True)
            
            logger.info("📂 Загрузка дополнительных модулей...")
            commands_path = Path("commands")
            if commands_path.exists():
                loaded_modules = {name for _, name, _ in modules_to_load}
                for module_file in commands_path.glob("*.py"):
                    module_name = module_file.stem
                    if module_name in loaded_modules or module_name == "__init__":
                        continue
                    
                    try:
                        await self.load_extension(f"commands.{module_name}")
                        self.loaded_cogs.append(module_name)
                        logger.info(f"✅ Загружен модуль: {module_name}")
                    except Exception as e:
                        logger.warning(f"⚠️ Ошибка загрузки commands.{module_name}: {e}")
            
            logger.info("🔄 Синхронизация команд с Discord...")
            try:
                synced = await self.tree.sync()
                logger.info(f"✅ Синхронизировано {len(synced)} команд")
                
                if len(synced) > 0:
                    for cmd in synced[:10]:
                        logger.info(f"   - /{cmd.name}")
                    if len(synced) > 10:
                        logger.info(f"   ... и еще {len(synced) - 10}")
            except Exception as e:
                logger.error(f"❌ Ошибка синхронизации команд: {e}", exc_info=True)
            
            try:
                await self.mute_service.restore_active_mutes()
                logger.info("✅ Активные муты восстановлены из БД")
            except Exception as e:
                logger.error(f"⚠️ Ошибка восстановления мутов: {e}", exc_info=True)
            
            logger.info("=" * 60)
            logger.info("✅ Инициализация завершена")
            logger.info(f"📚 Сервисов: 11")
            logger.info(f"🎯 Модулей загружено: {len(self.loaded_cogs)}")
            logger.info(f"   → {', '.join(self.loaded_cogs)}")
            logger.info("=" * 60)
            
        except Exception as e:
            logger.error(f"💥 КРИТИЧЕСКАЯ ОШИБКА при инициализации: {e}", exc_info=True)
            raise
    
    async def on_ready(self):
        """Called when bot is ready"""
        logger.info("=" * 60)
        logger.info(f"🟢 Бот готов: {self.user} (ID: {self.user.id})")
        logger.info(f"📊 Серверов: {len(self.guilds)}")
        logger.info(f"👥 Пользователей: {sum(g.member_count or 0 for g in self.guilds)}")
        
        if self.guilds:
            logger.info("   Серверы:")
            for guild in self.guilds[:5]:
                logger.info(f"   - {guild.name} ({guild.id}) - {guild.member_count} участников")
            if len(self.guilds) > 5:
                logger.info(f"   ... и еще {len(self.guilds) - 5}")
        
        logger.info("=" * 60)
    
    async def on_command_error(self, ctx, error):
        """Global command error handler"""
        if isinstance(error, commands.CommandNotFound):
            return
        elif isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ У вас недостаточно прав для выполнения этой команды.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Отсутствует обязательный аргумент: `{error.param.name}`")
        elif isinstance(error, commands.BadArgument):
            await ctx.send(f"❌ Неверный аргумент: {error}")
        else:
            logger.error(f"Ошибка команды {ctx.command}: {error}", exc_info=error)
            await ctx.send(f"❌ Произошла ошибка при выполнении команды: {error}")


async def main():
    """Main entry point"""
    Path("data").mkdir(exist_ok=True)
    
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.error("=" * 60)
        logger.error("❌ DISCORD_TOKEN не найден в файле .env!")
        logger.error("Пожалуйста, создайте .env файл с:")
        logger.error("DISCORD_TOKEN=ваш_токен_здесь")
        logger.error("=" * 60)
        return
    
    logger.info("🚀 Инициализация FermixBot...")
    bot = FermixBot()
    
    async with bot:
        try:
            await bot.start(token)
        except discord.errors.LoginFailure:
            logger.error("=" * 60)
            logger.error("❌ Неверный токен Discord!")
            logger.error("Проверьте правильность DISCORD_TOKEN в .env файле")
            logger.error("=" * 60)
        except KeyboardInterrupt:
            logger.info("🛑 Получен сигнал остановки, завершение работы...")
        except Exception as e:
            logger.error("=" * 60)
            logger.error(f"❌ Критическая ошибка бота: {e}", exc_info=True)
            logger.error("=" * 60)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Бот остановлен")
